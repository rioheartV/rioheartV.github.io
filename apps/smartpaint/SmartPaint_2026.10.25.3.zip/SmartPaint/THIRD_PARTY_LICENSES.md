# 使用しているソフトウェアとライセンス

SmartPaint は以下のオープンソースソフトウェアを利用しています。
どれも配布を許すライセンス（MIT・BSD・Apache-2.0・PSF など）です。

**各部品の著作権表示とライセンスの全文は、同じフォルダの `licenses\` にあります。**
部品・版・ライセンスの一覧は `licenses\一覧.md` を見てください。
配布版を作るたびに、入っている部品の文面を自動で集めています。

主な部品は次のとおりです。

| ライブラリ | 用途 | ライセンス |
|---|---|---|
| [Python](https://www.python.org/) | 実行環境（OpenSSL・libffi・zlib などを含む） | PSF License 2.0 |
| [aiohttp](https://github.com/aio-libs/aiohttp) とその関連部品 | Web サーバ・WebSocket | Apache License 2.0 ほか |
| [psd-tools](https://github.com/psd-tools/psd-tools) | PSD の読み書き | MIT License |
| [Pillow](https://python-pillow.org/) | 画像処理（FreeType・libjpeg・libpng・libwebp などを含む） | MIT-CMU License (HPND) ほか |
| [NumPy](https://numpy.org/) | 数値計算（OpenBLAS などを含む） | BSD 3-Clause License ほか |
| [qrcode](https://github.com/lincolnloop/python-qrcode) | QR コード生成 | BSD License |
| [pywebview](https://pywebview.flowrl.com/) と pythonnet | デスクトップの窓 | BSD 3-Clause License・MIT License |

Portions of this software are copyright © The FreeType Project (www.freetype.org). All rights reserved.

Microsoft Edge WebView2 ランタイムは同梱していません（Windows に入っている物を使います）。

## SmartPaint 自身について

- 画面のアイコン、ブラシのチップ、素材（きらきら・♡・髪プリセット）、デッサン人形は
  **すべてプログラムがその場で描いています**。第三者が作った画像素材は一切含みません。
- 書体はシステムにインストールされているフォントを名前で指定しているだけで、
  フォントファイルは同梱していません。
