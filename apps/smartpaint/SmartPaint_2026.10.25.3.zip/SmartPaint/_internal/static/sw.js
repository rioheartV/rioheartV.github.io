



const CACHE = "smartpaint-v4";
const ASSETS = [
  "/", "/static/app.js", "/static/filters.js", "/static/style.css",
  "/static/icon64.png", "/static/icon192.png", "/static/icon512.png",
  "/static/manifest.json",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) =>
    Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
  ).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET") return;
  if (url.pathname.startsWith("/api/") || url.pathname === "/ws" ||
      url.pathname === "/qr.png") return;




  e.respondWith(
    fetch(e.request, { cache: "no-store" }).then((res) => {
      if (res.ok && ASSETS.includes(url.pathname)) {
        const clone = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, clone));
      }
      return res;
    }).catch(() => caches.match(e.request).then((r) => r || caches.match("/")))
  );
});
