








"use strict";


const $ = (id) => document.getElementById(id);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const uid = () => "o" + Math.random().toString(36).slice(2, 10) +
                  Math.random().toString(36).slice(2, 6);
function hashSeed(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function hsvToRgb(h, s, v) {
  const f = (n) => {
    const k = (n + h / 60) % 6;
    return v - v * s * Math.max(0, Math.min(k, 4 - k, 1));
  };
  return [f(5) * 255, f(3) * 255, f(1) * 255].map(Math.round);
}
function rgbToHsv(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0;
  if (d) {
    if (mx === r) h = ((g - b) / d) % 6;
    else if (mx === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h *= 60; if (h < 0) h += 360;
  }
  return [h, mx ? d / mx : 0, mx];
}
const rgbHex = (r, g, b) =>
  "#" + [r, g, b].map((v) => clamp(Math.round(v), 0, 255).toString(16).padStart(2, "0")).join("");
function hexRgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}


const TOOLS = {
  brush:   { icon: "🖌️", name: "ブラシ" },
  eraser:  { icon: "🧽", name: "消しゴム" },
  grab:    { icon: "🤚", name: "つかむ" },
  blur:    { icon: "💨", name: "ぼかし" },
  smudge:  { icon: "👆", name: "指先" },
  fill:    { icon: "🪣", name: "塗りつぶし" },
  enclose: { icon: "🎯", name: "囲って塗る" },
  gapfill: { icon: "🩹", name: "塗り残しに塗る" },
  vecedit: { icon: "🔧", name: "線を編集" },
  gradient:{ icon: "🌈", name: "グラデ" },
  line:    { icon: "📏", name: "直線" },
  rect:    { icon: "▢", name: "四角" },
  ellipse: { icon: "⚪", name: "楕円" },
  text:    { icon: "🅣", name: "テキスト" },
  stamp:   { icon: "✨", name: "素材を置く" },
  doll:    { icon: "🧍", name: "人形を動かす" },
  balloon: { icon: "💬", name: "フキダシ" },
  transform:{icon: "⤢", name: "変形" },
  move:    { icon: "↔️", name: "移動" },
  picker:  { icon: "💧", name: "スポイト" },
  selrect: { icon: "🔲", name: "矩形選択" },
  lasso:   { icon: "➰", name: "投げ縄" },
  wand:    { icon: "🪄", name: "自動選択" },
  hand:    { icon: "✋", name: "パン" },
};

const MOUSE_DEFAULT = { left: "tool", middle: "hand", right: "eraser", back: "undo", forward: "redo",
                        penBarrel: "tool", penEraser: "eraser" };
const WHEEL_ROLES = { zoom: "🔍 拡大・縮小", size: "🖌️ ブラシの太さ", opacity: "◐ 不透明度",
                      rotate: "🔄 画面を回す", panV: "↕️ 画面を上下に", panH: "↔️ 画面を左右に", none: "何もしない" };
const WHEEL_DEFAULT = { plain: "zoom", ctrl: "zoom", shift: "zoom", alt: "zoom" };








const PRESET_CATS = { line: "✒️ 線画", pencil: "✏️ 鉛筆・ラフ", paint: "🖌️ 塗り",
                      air: "💨 エアブラシ・ぼかし", fx: "✨ 質感・仕上げ" };
const PRESETS = {

  pen:    { cat: "line", name: "ペン",       hard: 0.95, opacity: 1.0,  pSize: true,  pOp: false, scatter: 0, spacing: 0.12 },
  gpen:   { cat: "line", name: "Gペン",      hard: 0.90, opacity: 1.0,  pSize: true,  pOp: false, scatter: 0, spacing: 0.07,
            taperIn: 10, taperOut: 28 },
  mapen:  { cat: "line", name: "丸ペン",     hard: 0.96, opacity: 1.0,  pSize: true,  pOp: false, scatter: 0, spacing: 0.06,
            taperIn: 6, taperOut: 16 },
  kabura: { cat: "line", name: "カブラペン", hard: 0.95, opacity: 1.0,  pSize: true,  pOp: false, scatter: 0, spacing: 0.06,
            pcSize: 2.2, taperIn: 4, taperOut: 8 },
  milli:  { cat: "line", name: "ミリペン",   hard: 0.97, opacity: 1.0,  pSize: false, pOp: false, scatter: 0, spacing: 0.05 },
  smooth: { cat: "line", name: "なめらかペン", hard: 0.88, opacity: 1.0, pSize: true,  pOp: false, scatter: 0, spacing: 0.05,
            pcSize: 1.3, taperIn: 8, taperOut: 20 },
  fude:   { cat: "line", name: "筆ペン",     hard: 0.85, opacity: 1.0,  pSize: true,  pOp: false, scatter: 0, spacing: 0.04,
            pcSize: 0.65, taperIn: 15, taperOut: 45 },
  hairpen:{ cat: "line", name: "髪の毛ペン", hard: 0.92, opacity: 1.0,  pSize: true,  pOp: false, scatter: 0, spacing: 0.04,
            pcSize: 0.8, taperIn: 22, taperOut: 60 },
  calli:  { cat: "line", name: "カリグラフィ", hard: 0.95, opacity: 1.0, pSize: false, pOp: false, scatter: 0, spacing: 0.04,
            aspect: 0.2, angle: 45 },
  kasure: { cat: "line", name: "かすれ筆",   hard: 0.80, opacity: 0.95, pSize: true,  pOp: false, scatter: 0, spacing: 0.05,
            brushShape: "texture", grain: 60, jOpacity: 20, taperIn: 10, taperOut: 35 },

  pencil: { cat: "pencil", name: "鉛筆",     hard: 0.45, opacity: 0.85, pSize: true,  pOp: true,  scatter: 0, spacing: 0.06,
            grain: 70, jSize: 15, jOpacity: 25 },
  pencilD:{ cat: "pencil", name: "濃い鉛筆", hard: 0.70, opacity: 1.0,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.05,
            pcOp: 0.6, grain: 45, jSize: 8 },
  pencil6:{ cat: "pencil", name: "6B鉛筆",   hard: 0.35, opacity: 0.9,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.06,
            grain: 85, jSize: 12, jOpacity: 20 },
  sharp:  { cat: "pencil", name: "シャーペン", hard: 0.85, opacity: 0.9, pSize: true,  pOp: true,  scatter: 0, spacing: 0.05,
            pcSize: 2.0, grain: 25 },
  colorp: { cat: "pencil", name: "色鉛筆",   hard: 0.50, opacity: 0.7,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.06,
            grain: 80, jOpacity: 15 },
  charcoal:{ cat: "pencil", name: "木炭",    hard: 0.25, opacity: 0.85, pSize: true,  pOp: true,  scatter: 0.15, spacing: 0.08,
            brushShape: "texture", aspect: 0.45, angle: 30, grain: 95, jSize: 30, jOpacity: 30 },
  crayon: { cat: "pencil", name: "クレヨン", hard: 0.60, opacity: 0.95, pSize: false, pOp: true,  scatter: 0, spacing: 0.07,
            brushShape: "texture", pcOp: 0.7, grain: 85, jSize: 10 },
  chalk:  { cat: "pencil", name: "チョーク", hard: 0.30, opacity: 0.8,  pSize: true,  pOp: true,  scatter: 0.2, spacing: 0.10,
            grain: 90, jSize: 25 },
  pastel: { cat: "pencil", name: "パステル", hard: 0.20, opacity: 0.6,  pSize: false, pOp: true,  scatter: 0.1, spacing: 0.08,
            grain: 75 },

  anime:  { cat: "paint", name: "ベタ塗りペン", hard: 0.98, opacity: 1.0, pSize: false, pOp: false, scatter: 0, spacing: 0.05 },
  roundH: { cat: "paint", name: "丸ブラシ(硬)", hard: 0.90, opacity: 1.0, pSize: false, pOp: true,  scatter: 0, spacing: 0.05 },
  roundS: { cat: "paint", name: "丸ブラシ(柔)", hard: 0.30, opacity: 0.9, pSize: false, pOp: true,  scatter: 0, spacing: 0.05 },
  brush:  { cat: "paint", name: "水彩筆",     hard: 0.55, opacity: 0.8,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.10, mix: 55 },
  wash:   { cat: "paint", name: "にじみ水彩", hard: 0.15, opacity: 0.45, pSize: true,  pOp: true,  scatter: 0, spacing: 0.06, mix: 75 },
  flatW:  { cat: "paint", name: "水彩平筆",   hard: 0.50, opacity: 0.6,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.04,
            aspect: 0.3, follow: true, mix: 50 },
  opaque: { cat: "paint", name: "不透明水彩", hard: 0.60, opacity: 0.95, pSize: true,  pOp: true,  scatter: 0, spacing: 0.08,
            mix: 25, grain: 20 },
  gouache:{ cat: "paint", name: "ガッシュ",   hard: 0.80, opacity: 1.0,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.05,
            aspect: 0.7, follow: true, pcOp: 0.6, mix: 35, grain: 30 },
  thick:  { cat: "paint", name: "厚塗り丸筆", hard: 0.70, opacity: 1.0,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.05,
            pcSize: 0.6, mix: 45 },
  flat:   { cat: "paint", name: "平筆(油彩)", hard: 0.75, opacity: 0.9,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.05,
            aspect: 0.22, angle: 40, grain: 25 },
  knife:  { cat: "paint", name: "ペインティングナイフ", hard: 0.95, opacity: 1.0, pSize: false, pOp: false, scatter: 0, spacing: 0.03,
            aspect: 0.12, follow: true, mix: 60, grain: 15 },
  marker: { cat: "paint", name: "マーカー",   hard: 0.9,  opacity: 0.5,  pSize: false, pOp: false, scatter: 0, spacing: 0.08,
            aspect: 0.55, angle: 45 },
  alcohol:{ cat: "paint", name: "アルコールマーカー", hard: 0.80, opacity: 0.35, pSize: false, pOp: false, scatter: 0, spacing: 0.06,
            aspect: 0.6, angle: 60, mix: 15 },

  air:    { cat: "air", name: "エアブラシ",   hard: 0.03, opacity: 0.35, pSize: false, pOp: true,  scatter: 0, spacing: 0.06 },
  airH:   { cat: "air", name: "エアブラシ(強)", hard: 0.25, opacity: 0.6, pSize: false, pOp: true,  scatter: 0, spacing: 0.05 },
  airN:   { cat: "air", name: "ざらざらエアブラシ", hard: 0.05, opacity: 0.5, pSize: false, pOp: true, scatter: 0.3, spacing: 0.08,
            brushShape: "texture", grain: 60 },
  blend:  { cat: "air", name: "色まぜ筆",     hard: 0.30, opacity: 0.5,  pSize: false, pOp: true,  scatter: 0, spacing: 0.05, mix: 100 },

  dry:    { cat: "fx", name: "ドライブラシ",  hard: 0.70, opacity: 0.9,  pSize: true,  pOp: true,  scatter: 0, spacing: 0.05,
            brushShape: "texture", aspect: 0.5, follow: true, mix: 20, grain: 55, jOpacity: 25 },
  stipple:{ cat: "fx", name: "点描",          hard: 0.90, opacity: 0.9,  pSize: true,  pOp: false, scatter: 0.6, spacing: 0.35,
            jSize: 30 },
  dots:   { cat: "fx", name: "散布",          hard: 0.7,  opacity: 0.9,  pSize: true,  pOp: false, scatter: 1.6, spacing: 0.5,
            jSize: 40, jAngle: 100 },
  glitter:{ cat: "fx", name: "きらめき散布",  hard: 0.50, opacity: 0.9,  pSize: true,  pOp: false, scatter: 3.0, spacing: 0.9,
            jSize: 90, jOpacity: 40 },
  square: { cat: "fx", name: "四角ブラシ",    hard: 0.95, opacity: 1.0,  pSize: false, pOp: true,  scatter: 0, spacing: 0.06,
            brushShape: "square", follow: true },
};

const PRESET_KEYS = ["hard", "opacity", "pSize", "pOp", "scatter", "spacing", "mix",
                     "aspect", "angle", "follow", "grain", "jSize", "jAngle", "jOpacity",
                     "taperIn", "taperOut", "pcSize", "pcOp", "brushShape", "wash", "flow",
                     "pMinSize", "pMinOp", "speedSize", "speedOp",
                     "taperUnit", "taperTip", "taperShape", "taperOp"];
const PRESET_DEFAULTS = { hard: 0.7, opacity: 1, pSize: true, pOp: false, scatter: 0,
                          spacing: 0.12, mix: 0, aspect: 1, angle: 0, follow: false,
                          grain: 0, jSize: 0, jAngle: 0, jOpacity: 0,
                          taperIn: 0, taperOut: 0, pcSize: 1, pcOp: 1, brushShape: "round",
                          wash: false, flow: 100, pMinSize: 15, pMinOp: 0, speedSize: 0, speedOp: 0,
                          taperUnit: "pct", taperTip: 8, taperShape: 0, taperOp: false };





function pcurve(p, g) {
  if (!g || g === 1) return p;
  return Math.pow(clamp(p, 0, 1), clamp(g, 0.25, 4));
}

const BLEND_NAMES = {
  normal: "通常", darken: "比較(暗)", multiply: "乗算", burn: "焼き込み",
  lighten: "比較(明)", screen: "スクリーン", dodge: "覆い焼き", add: "加算(発光)",
  overlay: "オーバーレイ", soft: "ソフトライト", hard: "ハードライト",
  difference: "差の絶対値", exclusion: "除外",
  hue: "色相", saturation: "彩度", color: "カラー", luminosity: "輝度",
};
const BLEND_GCO = {
  normal: "source-over", darken: "darken", multiply: "multiply", burn: "color-burn",
  lighten: "lighten", screen: "screen", dodge: "color-dodge", add: "lighter",
  overlay: "overlay", soft: "soft-light", hard: "hard-light",
  difference: "difference", exclusion: "exclusion",
  hue: "hue", saturation: "saturation", color: "color", luminosity: "luminosity",
};
const SHAPES = { round: "丸", square: "四角", texture: "ざらつき" };
const FONTS = {
  gothic: '"Yu Gothic UI","Hiragino Sans","Noto Sans JP",sans-serif',
  mincho: '"Yu Mincho","Hiragino Mincho ProN","Noto Serif JP",serif',
  round: '"Rounded Mplus 1c","Hiragino Maru Gothic ProN","Yu Gothic UI",sans-serif',
  mono: '"Consolas","Osaka-Mono",monospace',
};

const GENERATORS = {
  speed:   { name: "集中線", params: [
               { k: "count", label: "本数", min: 20, max: 600, def: 180 },
               { k: "inner", label: "中心の空き%", min: 0, max: 90, def: 22 },
               { k: "width", label: "太さ", min: 1, max: 60, def: 14 },
               { k: "jitter", label: "ばらつき%", min: 0, max: 100, def: 55 }] },
  outline: { name: "縁取り(レイヤー)", params: [
               { k: "width", label: "太さ", min: 1, max: 40, def: 6 }] },
  frame:   { name: "枠線", params: [
               { k: "margin", label: "余白", min: 0, max: 300, def: 40 },
               { k: "width", label: "太さ", min: 1, max: 60, def: 10 }] },
};
const FILTERS = {
  hsv:      { name: "色相・彩度・明度", params: [
                { k: "h", label: "色相", min: -180, max: 180, def: 0 },
                { k: "s", label: "彩度", min: -100, max: 100, def: 0 },
                { k: "v", label: "明度", min: -100, max: 100, def: 0 }] },
  bc:       { name: "明るさ・コントラスト", params: [
                { k: "b", label: "明るさ", min: -100, max: 100, def: 0 },
                { k: "c", label: "コントラスト", min: -100, max: 100, def: 0 }] },
  levels:   { name: "レベル補正", params: [
                { k: "inLo", label: "入力 黒", min: 0, max: 254, def: 0 },
                { k: "inHi", label: "入力 白", min: 1, max: 255, def: 255 },
                { k: "gamma", label: "ガンマ×100", min: 10, max: 300, def: 100 },
                { k: "outLo", label: "出力 黒", min: 0, max: 255, def: 0 },
                { k: "outHi", label: "出力 白", min: 0, max: 255, def: 255 }] },
  blur:     { name: "ガウスぼかし", params: [
                { k: "r", label: "半径", min: 1, max: 100, def: 8 }] },
  sharpen:  { name: "シャープ", params: [
                { k: "amount", label: "強さ", min: 0, max: 300, def: 100 },
                { k: "r", label: "半径", min: 1, max: 20, def: 2 }] },
  lum2alpha:{ name: "線画抽出(輝度を透明度に)", params: [
                { k: "keep", label: "元の色を残す(0/1)", min: 0, max: 1, def: 0 }] },
  lineart:  { name: "線画化", params: [
                { k: "mode", label: "0=濃い所を線に / 1=輪郭を検出", min: 0, max: 1, def: 0 },
                { k: "t", label: "しきい値", min: 0, max: 255, def: 140 },
                { k: "soft", label: "やわらかさ", min: 0, max: 100, def: 25 },
                { k: "denoise", label: "ノイズ除去", min: 0, max: 5, def: 1 },
                { k: "thick", label: "線を太らせる", min: 0, max: 5, def: 0 }] },
  binarize: { name: "2値化", params: [
                { k: "t", label: "しきい値", min: 0, max: 255, def: 128 }] },
  gray:     { name: "白黒", params: [] },
  invert:   { name: "色を反転", params: [] },
  noise:    { name: "ノイズ", params: [
                { k: "amount", label: "量", min: 1, max: 100, def: 20 },
                { k: "mono", label: "モノクロ(0/1)", min: 0, max: 1, def: 1 }] },
  mosaic:   { name: "モザイク", params: [
                { k: "size", label: "サイズ", min: 2, max: 200, def: 20 }] },
  gradmap:  { name: "グラデーションマップ", params: [] },
  curve:    { name: "トーンカーブ", params: [], curve: true },
  halftone: { name: "網点トーン(漫画)", params: [
                { k: "pitch", label: "網の間隔", min: 3, max: 40, def: 8 },
                { k: "angle", label: "角度", min: 0, max: 90, def: 45 }] },
};
const RULERS = { none: "なし", line: "直線", h: "水平", v: "垂直",
                 radial: "集中線", circle: "同心円" };
const SYMS = { none: "なし", v: "左右対称", h: "上下対称", vh: "上下左右",
               r4: "回転4分割", r6: "回転6分割", r8: "回転8分割" };


const S = {
  doc: { name: "untitled", w: 1536, h: 2048, rev: 0 },
  layers: [],
  active: 0,
  tool: "brush",

  mouseBtn: { left: "tool", middle: "hand", right: "eraser", back: "undo", forward: "redo",
              penBarrel: "tool", penEraser: "eraser" },
  keys: {},
  wheel: { plain: "zoom", ctrl: "zoom", shift: "zoom", alt: "zoom" },
  unsel: false, unselId: null,

  soloOn: null, soloRect: null,
  quickOn: null,
  spread: false,
  clipAll: false,
  layerSwing: true,
  color: "#202020", sub: "#ffffff",
  size: 18, opacity: 1, hard: 0.7, stab: 2, spacing: 0.12, scatter: 0,
  brushShape: "round", mix: 0, selFeather: 0, selGrow: 0, vecErase: "inter",
  selModeUI: "new", selMode: "new",

  material: "sparkle", matSize: 60, hairStyle: "straight",
  aspect: 1, angle: 0, follow: false, grain: 0,
  jSize: 0, jAngle: 0, jOpacity: 0, tilt: true, brushPreset: "pen",
  taperIn: 0, taperOut: 0, post: 0,

  taperUnit: "pct", taperTip: 8, taperShape: 0, taperOp: false,

  taperUnitBy: {},
  wash: false, flow: 100,
  pMinSize: 15, pMinOp: 0,
  speedSize: 0, speedOp: 0,
  pSmooth: 0,
  flick: 0,
  stabSpeed: false,
  dynSpacing: true,
  gapClose: 0, fillRef: "layer",
  pSize: true, pOp: false, pcSize: 1, pcOp: 1, fingerDraw: true,
  textSize: 72, textFont: "gothic", textAlign: "left",


  deviceName: "", me: null, peers: [], followPeer: false, zen: false,
  autosaveOn: true, dirty: 0,
  fillTol: 32, fillGrow: 1,
  gradType: "linear", gradMode: "fg2trans",
  ruler: "none", sym: "none",
  maskEdit: false,
  view: { x: 0, y: 0, scale: 0.3, rot: 0, flip: false },
  composeVersion: 1, composedAt: 0,
  persp: { on: false, mode: "2", vps: [[-600, 900], [2100, 900], [768, 3200]], drag: null },
  textVertical: false,
  textTrack: 0, textLineH: 100, textOutline: 0, textOutlineColor: "#ffffff",
  importFitCanvas: true,
  sel: null, selDraft: null,
  moving: null, shape: null, grad: null, xform: null,
  history: [], histBytes: 0,
  MAXHIST: 80, MAXBYTES: 384 * 1024 * 1024,
  ws: null, wsOpen: false,
  stroke: null, remote: new Map(),
  saving: false, hover: null, fxSession: null,
};



let view = $("view"), vctx = view.getContext("2d");
const mainView = view;
let dpr = window.devicePixelRatio || 1;

const SOLO = { box: $("soloBox"), el: $("soloView"), ctx: $("soloView").getContext("2d"),
               view: { x: 0, y: 0, scale: 1, rot: 0, flip: false },
               layerId: null, c: null, cctx: null, at: -1, atLayer: null, force: false };
let inSolo = false;
function withSolo(fn) {
  if (inSolo) return fn();
  const pv = view, pc = vctx, mv = S.view, pd = dpr;
  view = SOLO.el; vctx = SOLO.ctx; S.view = SOLO.view; inSolo = true;
  if (SOLO.win && !SOLO.win.closed) dpr = SOLO.win.devicePixelRatio || pd;
  try { return fn(); }
  finally { SOLO.view = S.view; view = pv; vctx = pc; S.view = mv; dpr = pd; inSolo = false; }
}

function onView(type, fn, opts) {
  mainView.addEventListener(type, fn, opts);
  SOLO.el.addEventListener(type, (e) => withSolo(() => fn(e)), opts);
}
function soloLayer() {
  if ((!S.soloOn && !SOLO.win) || S.unsel) return null;
  const lay = S.layers[S.active];
  return (lay && isRaster(lay) && lay.canvas) ? lay : null;
}
function soloFit(lay) {
  const r = SOLO.el.getBoundingClientRect();
  if (r.width < 4 || r.height < 4) return;
  let b = null;
  try { b = contentBBox(lay.ctx || lay.canvas.getContext("2d")); } catch (err) {}
  if (!b) b = { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
  const bw = Math.max(8, b.x1 - b.x0), bh = Math.max(8, b.y1 - b.y0);
  const sc = clamp(Math.min(r.width / bw, r.height / bh) * 0.9, 0.02, 32);
  SOLO.view = { x: r.width / 2 - (b.x0 + bw / 2) * sc, y: r.height / 2 - (b.y0 + bh / 2) * sc,
                scale: sc, rot: 0, flip: false };
}

function soloSync() {
  if (SOLO.win && SOLO.win.closed) soloDock();
  const popped = !!SOLO.win;
  const lay = soloLayer();
  SOLO.box.classList.toggle("hidden", !lay || popped);
  const titleEl = popped ? SOLO.popTitle : $("soloTitle"), zoomEl = popped ? SOLO.popZoom : $("soloZoom");
  if (!lay) {
    if (popped && SOLO.layerId !== "none") {
      SOLO.layerId = "none";
      SOLO.ctx.setTransform(1, 0, 0, 1, 0, 0);
      SOLO.ctx.clearRect(0, 0, SOLO.el.width, SOLO.el.height);
      titleEl.textContent = "レイヤーを 1 つ選んでください"; zoomEl.textContent = "";
    } else if (!popped) SOLO.layerId = null;
    return null;
  }
  if (!popped) {

    const W = window.innerWidth, H = window.innerHeight;
    if (!S.soloRect) {
      const cw = $("canvasWrap").getBoundingClientRect();
      const w = Math.round(clamp(cw.width * 0.42, 220, 560)), h = Math.round(clamp(cw.height * 0.6, 200, 720));
      S.soloRect = { x: Math.round(cw.right - w - 10), y: Math.round(cw.top + 10), w, h };
    }
    const q = S.soloRect;
    q.w = Math.round(clamp(q.w, 180, Math.max(180, W - 8)));
    q.h = Math.round(clamp(q.h, 160, Math.max(160, H - 8)));
    q.x = Math.round(clamp(q.x, 60 - q.w, W - 60));
    q.y = Math.round(clamp(q.y, 0, H - 30));
    const st = SOLO.box.style;
    st.left = q.x + "px"; st.top = q.y + "px"; st.width = q.w + "px"; st.height = q.h + "px";
  }
  const r = SOLO.el.getBoundingClientRect();
  const pr = popped ? (SOLO.win.devicePixelRatio || 1) : dpr;
  const w = Math.max(1, Math.round(r.width * pr)), h = Math.max(1, Math.round(r.height * pr));
  const resized = SOLO.el.width !== w || SOLO.el.height !== h;
  if (resized) { SOLO.el.width = w; SOLO.el.height = h; }
  if (SOLO.layerId !== lay.id || SOLO.refit) {
    titleEl.textContent = "🔲 " + (lay.name || "パーツ");
    if (r.width > 8 && r.height > 8) { SOLO.layerId = lay.id; SOLO.refit = false; soloFit(lay); }
    else SOLO.refit = true;
  }
  zoomEl.textContent = Math.round(SOLO.view.scale * 100) + "%";
  return lay;
}


function soloPopout(at) {
  if (SOLO.win && !SOLO.win.closed) { try { SOLO.win.focus(); } catch (e) {} return; }
  let w = null;
  const q = S.soloRect || { w: 560, h: 760 };
  const feat = at ? `popup=yes,left=${at.left},top=${at.top},width=${at.width},height=${at.height}`
                  : `popup=yes,width=${Math.max(320, q.w)},height=${Math.max(320, q.h)}`;
  try { w = window.open("about:blank", "sp_solo", feat); } catch (e) {}
  if (!w || !w.document) { toast("別のウィンドウを開けませんでした（アプリを開き直してから試してください）"); return; }
  const d = w.document;
  d.title = "SmartPaint — パーツ単体";
  d.body.style.cssText = "margin:0;height:100vh;display:flex;flex-direction:column;overflow:hidden;" +
                         "background:#17181c;color:#ddd;font:12px system-ui,sans-serif";
  const head = d.createElement("div");
  head.style.cssText = "display:flex;align-items:center;gap:6px;padding:4px 8px;background:#262830;flex:none;user-select:none";
  const title = d.createElement("b");
  title.style.cssText = "flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap";
  const zoom = d.createElement("span");
  zoom.style.cssText = "color:#8b90a0;font-size:11px";
  const mk = (txt, tip, fn) => {
    const b = d.createElement("button");
    b.textContent = txt; b.title = tip;
    b.style.cssText = "height:26px;min-width:30px;background:#3a3d47;color:#eee;border:1px solid #4a4d57;border-radius:6px;cursor:pointer";
    b.onclick = fn;
    return b;
  };
  head.append(title, zoom,
    mk("⤢", "このパーツ全体が入る倍率にします", () => { const l = soloLayer(); if (l) { soloFit(l); requestRender(); } }),
    mk("⇲ 戻す", "アプリの中の枠へ戻します", () => soloDock()));
  d.body.appendChild(head);
  SOLO.el.style.cssText = "flex:1;min-height:0;width:100%;display:block;touch-action:none;cursor:crosshair";
  d.body.appendChild(SOLO.el);
  SOLO.win = w; SOLO.popTitle = title; SOLO.popZoom = zoom;
  SOLO.layerId = null; SOLO.refit = true;
  w.addEventListener("resize", () => requestRender());
  w.addEventListener("pagehide", () => { if (SOLO.win === w) soloDock(true); });

  for (const type of ["keydown", "keyup"])
    w.addEventListener(type, (e) => {
      const ev = new KeyboardEvent(type, { key: e.key, code: e.code, ctrlKey: e.ctrlKey, shiftKey: e.shiftKey,
                                           altKey: e.altKey, metaKey: e.metaKey, bubbles: true, cancelable: true });
      if (!document.body.dispatchEvent(ev)) e.preventDefault();
    });
  syncSoloUI();
  requestRender();
  setTimeout(requestRender, 150);
  setTimeout(requestRender, 600);

  const above = () => {
    try {
      if (window.pywebview && pywebview.api && pywebview.api.keep_popup_above && SOLO.win === w)
        pywebview.api.keep_popup_above(d.title);
    } catch (e) {}
  };
  setTimeout(above, 400); setTimeout(above, 1500);
}
function soloDock(closing) {
  const w = SOLO.win;
  if (!w) return;
  SOLO.win = null; SOLO.popTitle = null; SOLO.popZoom = null;
  SOLO.el.style.cssText = "";
  SOLO.box.insertBefore(SOLO.el, $("soloGrip"));
  SOLO.layerId = null;
  if (!closing) { try { w.close(); } catch (e) {} }
  syncSoloUI();
  requestRender();
}
window.addEventListener("beforeunload", () => { if (SOLO.win) { try { SOLO.win.close(); } catch (e) {} } });

function soloComposite(lay) {
  if (!SOLO.c) { SOLO.c = makeCanvas(); SOLO.cctx = SOLO.c.getContext("2d"); }
  if (SOLO.c.width !== S.doc.w || SOLO.c.height !== S.doc.h) {
    SOLO.c.width = S.doc.w; SOLO.c.height = S.doc.h; SOLO.at = -1;
  }
  const live = livePreviewActive();
  if (SOLO.at === S.composeVersion && SOLO.atLayer === lay.id && !live && !SOLO.force) return SOLO.c;
  SOLO.force = live; SOLO.at = S.composeVersion; SOLO.atLayer = lay.id;
  const x = SOLO.cctx;
  x.setTransform(1, 0, 0, 1, 0, 0);
  x.globalCompositeOperation = "source-over"; x.globalAlpha = 1;
  x.clearRect(0, 0, S.doc.w, S.doc.h);
  drawMember(x, lay, "source-over", 1, true);
  x.globalCompositeOperation = "source-over"; x.globalAlpha = 1;
  return SOLO.c;
}
let strokeCanvas = null, strokeCtx = null;
let scratch = null, scratchCtx = null;
let scratch2 = null, scratch2Ctx = null;
let scratch3 = null, scratch3Ctx = null;
let docC = null, docCtx = null;
let replayC = null;
let checker = null;



const tempPool = new Map();
function tempAt(level) {
  let t = tempPool.get(level);
  if (!t) {
    const c = makeCanvas();
    t = { c, ctx: c.getContext("2d", { willReadFrequently: true }) };
    tempPool.set(level, t);
  }
  if (t.c.width !== S.doc.w || t.c.height !== S.doc.h) {
    t.c.width = S.doc.w; t.c.height = S.doc.h;
  }
  t.ctx.setTransform(1, 0, 0, 1, 0, 0);
  t.ctx.globalCompositeOperation = "source-over";
  t.ctx.globalAlpha = 1;
  t.ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  return t;
}
function touch() { S.composeVersion++; }






const BB_MUT = ["clearRect", "fillRect", "strokeRect", "fill", "stroke", "drawImage",
                "putImageData", "fillText", "strokeText", "reset"];
function watchLayerCtx(l) {
  const x = l.ctx;
  for (const m of BB_MUT) {
    const f = x[m];
    if (typeof f !== "function") continue;
    x[m] = function () { l._bb = undefined; queueBB(l); return f.apply(this, arguments); };
  }
}
const bbQueue = new Set();
let bbTimer = null;
function queueBB(l) {
  bbQueue.add(l);
  if (!bbTimer) bbTimer = setTimeout(runBB, 300);
}
function runBB() {
  bbTimer = null;
  if (S.stroke) { bbTimer = setTimeout(runBB, 300); return; }
  const t0 = performance.now();
  for (const l of bbQueue) {
    bbQueue.delete(l);
    if (l.canvas && l._bb === undefined && S.layers.includes(l)) scanBB(l);
    if (performance.now() - t0 > 12) break;
  }
  if (bbQueue.size) bbTimer = setTimeout(runBB, 16);
}
function scanBB(l) {
  const c = l.canvas, w = c.width, h = c.height;
  let d;
  try { d = new Uint32Array(l.ctx.getImageData(0, 0, w, h).data.buffer); } catch (e) { return; }
  let y0 = -1, y1 = -1, x0 = w, x1 = -1;
  for (let y = 0; y < h && y0 < 0; y++) { const o = y * w; for (let x = 0; x < w; x++) if (d[o + x] >>> 24) { y0 = y; break; } }
  if (y0 >= 0) {
    for (let y = h - 1; y >= y0 && y1 < 0; y--) { const o = y * w; for (let x = 0; x < w; x++) if (d[o + x] >>> 24) { y1 = y; break; } }
    for (let y = y0; y <= y1; y++) {
      const o = y * w;
      for (let x = 0; x < x0; x++) if (d[o + x] >>> 24) { x0 = x; break; }
      for (let x = w - 1; x > x1; x--) if (d[o + x] >>> 24) { x1 = x; break; }
    }
  }
  l._bb = y0 < 0 ? null : [x0, y0, x1 - x0 + 1, y1 - y0 + 1];
  l._bbC = c; l._bbW = w; l._bbH = h;
}
function knownBB(l) {
  const c = l.canvas;
  if (!c || l._bb === undefined || l._bbC !== c || l._bbW !== c.width || l._bbH !== c.height) return undefined;
  return l._bb;
}


const smallPool = new Map();
function tempSmall(level, R) {
  let t = smallPool.get(level);
  if (!t) {
    const c = document.createElement("canvas");
    t = { c, ctx: c.getContext("2d", { willReadFrequently: true }) };
    smallPool.set(level, t);
  }
  if (t.c.width !== R[2] || t.c.height !== R[3]) { t.c.width = R[2]; t.c.height = R[3]; }
  t.ctx.setTransform(1, 0, 0, 1, 0, 0);
  t.ctx.globalCompositeOperation = "source-over";
  t.ctx.globalAlpha = 1;
  t.ctx.clearRect(0, 0, R[2], R[3]);
  t.ctx.setTransform(1, 0, 0, 1, -R[0], -R[1]);
  return t;
}

function subtreeBox(start, end) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, any = false;
  for (let k = start; k < end; k++) {
    const e = S.layers[k];
    if (!e.visible) { k = skipSubtree(k) - 1; continue; }
    if (e.type === "adjust") return undefined;
    if (!e.canvas) continue;
    const b = knownBB(e);
    if (b === undefined) return undefined;
    if (!b) continue;
    any = true;
    x0 = Math.min(x0, b[0]); y0 = Math.min(y0, b[1]);
    x1 = Math.max(x1, b[0] + b[2]); y1 = Math.max(y1, b[1] + b[3]);
  }
  return any ? [x0, y0, x1 - x0, y1 - y0] : null;
}


function viewMatOf(v) {
  const c = Math.cos(v.rot), s = Math.sin(v.rot), fx = v.flip ? -1 : 1;
  return { a: fx * v.scale * c, b: fx * v.scale * s,
           c: -v.scale * s, d: v.scale * c, e: v.x, f: v.y };
}
function docToScreen(x, y, v = S.view) {
  const m = viewMatOf(v);
  return [m.a * x + m.c * y + m.e, m.b * x + m.d * y + m.f];
}
function screenToDoc(sx, sy, v = S.view) {
  const m = viewMatOf(v);
  const det = m.a * m.d - m.b * m.c;
  const dx = sx - m.e, dy = sy - m.f;
  return [(m.d * dx - m.c * dy) / det, (-m.b * dx + m.a * dy) / det];
}
function anchorAt(p, sx, sy) {
  const q = docToScreen(p[0], p[1]);
  S.view.x += sx - q[0];
  S.view.y += sy - q[1];
}
function zoomAt(cx, cy, k) {
  const r = view.getBoundingClientRect();
  const sx = cx - r.left, sy = cy - r.top;
  const p = screenToDoc(sx, sy);
  S.view.scale = clamp(S.view.scale * k, 0.02, 32);
  anchorAt(p, sx, sy);
  requestRender();
}
function viewCenterOp(fn) {
  const r = view.getBoundingClientRect();
  const cx = r.width / 2, cy = r.height / 2;
  const p = screenToDoc(cx, cy);
  fn();
  anchorAt(p, cx, cy);
  requestRender();
  updateViewPanel();
}


function makeCanvas(w = S.doc.w, h = S.doc.h) {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return c;
}



function wrapLayer(lm) {
  const type = lm.type || "raster";
  const l = { clip: false, alphaLock: false, hasMask: false, depth: 0, open: true,
              type, ...lm, canvas: null, ctx: null, mask: null };
  if (type === "raster" || type === "vector" || type === "text" || type === "doll") {
    l.canvas = makeCanvas();
    l.ctx = l.canvas.getContext("2d", { willReadFrequently: true });
    watchLayerCtx(l);
    l._bb = null; l._bbC = l.canvas; l._bbW = l.canvas.width; l._bbH = l.canvas.height;
    if (type === "vector") l.strokes = (lm.strokes || []).map((s) => ({ ...s }));
    if (type === "text") l.text = { ...(lm.text || {}) };
    if (type === "doll") l.doll = lm.doll ? JSON.parse(JSON.stringify(lm.doll)) : null;
    if (l.hasMask) attachMask(l);
  }
  return l;
}



function isRaster(l) {
  return l && (l.type === "raster" || l.type === "vector" ||
               l.type === "text" || l.type === "doll");
}
function isVector(l) { return l && l.type === "vector"; }





function rebuildVector(lay) {
  if (!isVector(lay)) return;
  lay.ctx.setTransform(1, 0, 0, 1, 0, 0);
  lay.ctx.globalCompositeOperation = "source-over";
  lay.ctx.globalAlpha = 1;
  lay.ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  for (const op of lay.strokes) drawVecStroke(lay, op);
  touch();
}
function drawVecStroke(lay, op) {
  const o = { ...op, mix: 0 };
  const st = newStrokeState(o, replayC || makeCanvas());
  st.total = ptsLength(o.pts);
  strokeAddPoints(st, o.pts, true);
  applyGrain(st);
  lay.ctx.save();
  lay.ctx.globalAlpha = o.opacity;
  lay.ctx.globalCompositeOperation = o.tool === "eraser" ? "destination-out" : "source-over";
  lay.ctx.drawImage(st.canvas, 0, 0);
  lay.ctx.restore();
  clearStrokeCanvas(st);
}
function distToSeg(px, py, a, b) {
  const vx = b[0] - a[0], vy = b[1] - a[1];
  const wx = px - a[0], wy = py - a[1];
  const L2 = vx * vx + vy * vy;
  let t = L2 ? (wx * vx + wy * vy) / L2 : 0;
  t = t < 0 ? 0 : t > 1 ? 1 : t;
  return { d: Math.hypot(px - (a[0] + vx * t), py - (a[1] + vy * t)), t };
}

function vecHit(lay, x, y, tol) {
  let best = null;
  for (let si = lay.strokes.length - 1; si >= 0; si--) {
    const s = lay.strokes[si];
    const r = Math.max(tol, s.size / 2 + 2);
    for (let i = 1; i < s.pts.length; i++) {
      const { d, t } = distToSeg(x, y, s.pts[i - 1], s.pts[i]);
      if (d <= r && (!best || d < best.d)) best = { d, si, param: i - 1 + t };
    }
  }
  return best;
}
function segCross(p1, p2, p3, p4) {
  const d1x = p2[0] - p1[0], d1y = p2[1] - p1[1];
  const d2x = p4[0] - p3[0], d2y = p4[1] - p3[1];
  const den = d1x * d2y - d1y * d2x;
  if (Math.abs(den) < 1e-9) return null;
  const t = ((p3[0] - p1[0]) * d2y - (p3[1] - p1[1]) * d2x) / den;
  const u = ((p3[0] - p1[0]) * d1y - (p3[1] - p1[1]) * d1x) / den;
  if (t < 0 || t > 1 || u < 0 || u > 1) return null;
  return t;
}

function vecIntersections(lay, si) {
  const s = lay.strokes[si];
  const out = [];
  for (let i = 1; i < s.pts.length; i++) {
    for (let oi = 0; oi < lay.strokes.length; oi++) {
      const o = lay.strokes[oi];
      for (let j = 1; j < o.pts.length; j++) {
        if (oi === si && Math.abs(i - j) < 4) continue;
        const t = segCross(s.pts[i - 1], s.pts[i], o.pts[j - 1], o.pts[j]);
        if (t !== null) out.push(i - 1 + t);
      }
    }
  }
  return out.sort((a, b) => a - b);
}
function ptAt(pts, param) {
  const i = Math.max(0, Math.min(pts.length - 2, Math.floor(param)));
  const t = param - i;
  const a = pts[i], b = pts[i + 1];
  return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t,
          (a[2] ?? 1) + ((b[2] ?? 1) - (a[2] ?? 1)) * t];
}
function subPts(pts, from, to) {
  if (to - from < 0.02) return null;
  const out = [ptAt(pts, from)];
  for (let i = Math.ceil(from); i < to; i++) out.push(pts[i]);
  out.push(ptAt(pts, to));
  return out.length >= 2 ? out : null;
}

function skipSubtree(i) {
  const e = S.layers[i];
  if (!e) return i + 1;
  if (e.type !== "folder") return i + 1;
  let j = i + 1;
  while (j < S.layers.length && S.layers[j].depth > e.depth) j++;
  return j;
}

function activeRaster() {
  const l = S.layers[S.active];
  if (isRaster(l)) return l;
  return null;
}
function firstRasterIndex() {
  for (let i = S.layers.length - 1; i >= 0; i--) if (isRaster(S.layers[i])) return i;
  return 0;
}
function attachMask(l) {
  if (l.mask) return;
  l.mask = makeCanvas();
  l.maskCtx = l.mask.getContext("2d", { willReadFrequently: true });
  l.maskCtx.fillStyle = "#fff";
  l.maskCtx.fillRect(0, 0, S.doc.w, S.doc.h);
  l.hasMask = true;
}

async function buildDoc(meta, oplog, steps) {

  const prev = S.doc;
  const sameView = !!prev && prev.rev > 0 && prev.name === meta.name && prev.w === meta.w && prev.h === meta.h;
  S.doc = { name: meta.name, src: meta.src || null, w: meta.w, h: meta.h, rev: meta.rev };
  S.layers = [];
  S.history = []; S.histBytes = 0;


  S.pastSteps = (steps || []).map((s) => s.label || opLabel(s));
  S.remote.clear();
  S.stroke = null; S.sel = null; S.selDraft = null;
  S.moving = null; S.shape = null; S.grad = null; S.xform = null; S.fxSession = null;
  S.balloon = null; S.stampDrag = null;
  for (const lm of meta.layers) S.layers.push(wrapLayer(lm));
  strokeCanvas = makeCanvas(); strokeCtx = strokeCanvas.getContext("2d");
  scratch = makeCanvas(); scratchCtx = scratch.getContext("2d", { willReadFrequently: true });
  scratch2 = makeCanvas(); scratch2Ctx = scratch2.getContext("2d");
  scratch3 = makeCanvas(); scratch3Ctx = scratch3.getContext("2d", { willReadFrequently: true });
  docC = makeCanvas(); docCtx = docC.getContext("2d", { willReadFrequently: true });
  replayC = makeCanvas();
  tempPool.clear();
  touch();
  await Promise.all(S.layers.map(async (l) => {
    if (!l.ctx) return;


    if (l.hasMask) {
      try {
        const r = await fetch(`/api/layer/${l.id}/mask.png?rev=${meta.rev}`);
        const bmp = await createImageBitmap(await r.blob());


        l.maskCtx.globalCompositeOperation = "copy";
        l.maskCtx.drawImage(bmp, 0, 0);
        l.maskCtx.globalCompositeOperation = "source-over";
        bmp.close && bmp.close();
      } catch (e) { console.warn("mask load fail", l.id, e); }
    }
    if (isVector(l) && l.strokes.length) { rebuildVector(l); return; }
    if (isText(l)) { rebuildText(l); return; }
    if (isDoll(l)) { rebuildDoll(l); return; }
    try {
      const r = await fetch(`/api/layer/${l.id}.png?rev=${meta.rev}`);
      const bmp = await createImageBitmap(await r.blob());
      l.ctx.drawImage(bmp, 0, 0);
      bmp.close && bmp.close();
    } catch (e) { console.warn("layer load fail", l.id, e); }
  }));
  S.active = Math.max(0, S.layers.length - 1);
  for (const op of oplog || []) applyOp(op, true);
  if (!sameView) fitView();
  rebuildLayerList();
  requestRender();
  toast(`${S.doc.name} (${S.doc.w}×${S.doc.h}, ${S.layers.length}レイヤー)`);
}
function layerById(id) { return S.layers.find((l) => l.id === id); }
function layerIndex(id) { return S.layers.findIndex((l) => l.id === id); }
function targetCtxOf(layer, target) {
  if (!isRaster(layer)) return null;
  if (target === "mask") { attachMask(layer); return layer.maskCtx; }

  if (isText(layer) || isDoll(layer)) return null;
  return layer.ctx;
}
function activeTarget() { return (S.maskEdit && S.layers[S.active]?.hasMask) ? "mask" : "layer"; }


function selPath(ctx, sel) {
  if (sel.type === "combo") {
    ctx.beginPath();
    if (sel.invert) ctx.rect(0, 0, S.doc.w, S.doc.h);
    for (const it of sel.items) addShapeToPath(ctx, it.s);
    return;
  }
  ctx.beginPath();
  if (sel.invert) ctx.rect(0, 0, S.doc.w, S.doc.h);
  if (sel.type === "rect") {
    ctx.rect(Math.min(sel.x0, sel.x1), Math.min(sel.y0, sel.y1),
             Math.abs(sel.x1 - sel.x0), Math.abs(sel.y1 - sel.y0));
  } else if (sel.type === "poly") {
    ctx.moveTo(sel.pts[0][0], sel.pts[0][1]);
    for (let i = 1; i < sel.pts.length; i++) ctx.lineTo(sel.pts[i][0], sel.pts[i][1]);
    ctx.closePath();
  } else if (sel.type === "polys") {
    for (const poly of sel.polys) {
      if (poly.length < 3) continue;
      ctx.moveTo(poly[0][0], poly[0][1]);
      for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0], poly[i][1]);
      ctx.closePath();
    }
  }
}

function addShapeToPath(ctx, s) {
  if (s.type === "rect") {
    ctx.rect(Math.min(s.x0, s.x1), Math.min(s.y0, s.y1),
             Math.abs(s.x1 - s.x0), Math.abs(s.y1 - s.y0));
  } else if (s.type === "poly") {
    ctx.moveTo(s.pts[0][0], s.pts[0][1]);
    for (let i = 1; i < s.pts.length; i++) ctx.lineTo(s.pts[i][0], s.pts[i][1]);
    ctx.closePath();
  } else if (s.type === "polys") {
    for (const poly of s.polys) {
      if (poly.length < 3) continue;
      ctx.moveTo(poly[0][0], poly[0][1]);
      for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i][0], poly[i][1]);
      ctx.closePath();
    }
  }
}

function combineSel(prev, shape, mode) {
  if (mode === "new" || !prev) return shape;
  const items = prev.type === "combo" ? prev.items.slice() : [{ s: prev, op: "add" }];
  items.push({ s: shape, op: mode });
  return { type: "combo", items, invert: prev.invert || false };
}
function clipSel(ctx, sel) {
  if (!sel) return;
  if (sel.type === "combo") return;
  selPath(ctx, sel);
  ctx.clip("evenodd");
}


let selMaskCache = { key: null, canvas: null };
function selNeedsMask(sel) {
  return !!(sel && (sel.feather > 0 || sel.grow || sel.type === "combo"));
}
function buildSelMask(sel) {
  const key = JSON.stringify(sel);
  if (selMaskCache.key === key && selMaskCache.canvas &&
      selMaskCache.canvas.width === S.doc.w) return selMaskCache.canvas;
  const c = makeCanvas(), x = c.getContext("2d", { willReadFrequently: true });
  x.fillStyle = "#fff";
  if (sel.type === "combo") {

    for (const it of sel.items) {
      x.globalCompositeOperation = it.op === "sub" ? "destination-out" : "source-over";
      x.beginPath();
      addShapeToPath(x, it.s);
      x.fill("evenodd");
    }
    x.globalCompositeOperation = "source-over";
    if (sel.invert) {
      const t = tempAt(SEL_LEVEL + 3);
      t.ctx.fillStyle = "#fff";
      t.ctx.fillRect(0, 0, S.doc.w, S.doc.h);
      t.ctx.globalCompositeOperation = "destination-out";
      t.ctx.drawImage(c, 0, 0);
      t.ctx.globalCompositeOperation = "source-over";
      x.globalCompositeOperation = "copy";
      x.drawImage(t.c, 0, 0);
      x.globalCompositeOperation = "source-over";
    }
  } else {
    selPath(x, sel);
    x.fill("evenodd");
  }
  const feather = sel.feather || 0, grow = sel.grow || 0;


  const R = Math.max(1, feather * 0.9 + Math.abs(grow));
  const img = x.getImageData(0, 0, S.doc.w, S.doc.h);
  FX.blur(img.data, S.doc.w, S.doc.h, R);

  const t = 128 - grow * (255 / (2 * R));
  const ramp = feather > 0 ? Math.max(4, feather * (255 / R) * 0.9) : 3;
  const d = img.data;
  for (let i = 3; i < d.length; i += 4) {
    const v = (d[i] - t) / ramp + 0.5;
    d[i] = v <= 0 ? 0 : v >= 1 ? 255 : Math.round(v * 255);
    d[i - 3] = d[i - 2] = d[i - 1] = 255;
  }
  x.putImageData(img, 0, 0);
  selMaskCache = { key, canvas: c };
  return c;
}

const SEL_LEVEL = 12;
function paintThrough(ctx, sel, mode, alpha, drawFn) {
  if (!selNeedsMask(sel)) {
    ctx.save();
    clipSel(ctx, sel);
    ctx.globalCompositeOperation = mode;
    ctx.globalAlpha = alpha;
    drawFn(ctx);
    ctx.restore();
    return;
  }
  const t = tempAt(SEL_LEVEL);
  drawFn(t.ctx);
  t.ctx.globalCompositeOperation = "destination-in";
  t.ctx.globalAlpha = 1;
  t.ctx.drawImage(buildSelMask(sel), 0, 0);
  t.ctx.globalCompositeOperation = "source-over";
  ctx.save();
  ctx.globalCompositeOperation = mode;
  ctx.globalAlpha = alpha;
  ctx.drawImage(t.c, 0, 0);
  ctx.restore();
}
function selBBox(sel) {
  if (!sel || sel.invert) return { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  const acc = (x, y) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y);
                          x1 = Math.max(x1, x); y1 = Math.max(y1, y); };
  const accShape = (s) => {
    if (s.type === "rect") { acc(s.x0, s.y0); acc(s.x1, s.y1); }
    else if (s.type === "poly") for (const p of s.pts) acc(p[0], p[1]);
    else if (s.type === "polys") for (const poly of s.polys) for (const p of poly) acc(p[0], p[1]);
  };
  if (sel.type === "combo") {
    for (const it of sel.items) if (it.op !== "sub") accShape(it.s);
  }
  else if (sel.type === "rect") { acc(sel.x0, sel.y0); acc(sel.x1, sel.y1); }
  else if (sel.type === "poly") for (const p of sel.pts) acc(p[0], p[1]);
  else if (sel.type === "polys") for (const poly of sel.polys) for (const p of poly) acc(p[0], p[1]);
  if (!isFinite(x0)) return { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
  return { x0: clamp(Math.floor(x0) - 1, 0, S.doc.w), y0: clamp(Math.floor(y0) - 1, 0, S.doc.h),
           x1: clamp(Math.ceil(x1) + 1, 0, S.doc.w), y1: clamp(Math.ceil(y1) + 1, 0, S.doc.h) };
}
function setSel(sel) {
  if (sel) { sel.feather = S.selFeather; sel.grow = S.selGrow; }
  S.sel = sel;
  $("btnDesel").classList.toggle("hidden", !sel);
  requestRender();
}
function refreshSelEdge() {
  if (!S.sel) return;
  S.sel = { ...S.sel, feather: S.selFeather, grow: S.selGrow };
  requestRender();
}


const tipCache = new Map();
function getTip(size, color, hard, white, shape) {
  shape = shape || "round";
  const key = `${size | 0}|${color}|${hard}|${white ? 1 : 0}|${shape}`;
  let tip = tipCache.get(key);
  if (tip) return tip;
  const d = Math.max(2, Math.ceil(size)) + 2;
  tip = makeCanvas(d, d);
  const c = tip.getContext("2d");
  const r = d / 2;
  const col = white ? "255,255,255" : hexRgb(color).join(",");
  if (shape === "square") {
    const inset = (1 - hard) * r * 0.5;
    const g = c.createLinearGradient(0, 0, 0, d);
    c.fillStyle = `rgba(${col},1)`;
    c.fillRect(inset, inset, d - inset * 2, d - inset * 2);
    if (hard < 0.98) {
      c.globalCompositeOperation = "destination-in";
      const rg = c.createRadialGradient(r, r, r * hard, r, r, r * 1.25);
      rg.addColorStop(0, "rgba(0,0,0,1)");
      rg.addColorStop(1, "rgba(0,0,0,0)");
      c.fillStyle = rg; c.fillRect(0, 0, d, d);
      c.globalCompositeOperation = "source-over";
    }
  } else {
    const g = c.createRadialGradient(r, r, Math.max(0.5, r * hard * 0.92), r, r, r - 0.5);
    g.addColorStop(0, `rgba(${col},1)`);
    g.addColorStop(1, `rgba(${col},0)`);
    c.fillStyle = g;
    c.fillRect(0, 0, d, d);
    if (shape === "texture") {

      const img = c.getImageData(0, 0, d, d);
      const rnd = FX.rng(hashSeed(key));
      for (let i = 0; i < img.data.length; i += 4)
        img.data[i + 3] *= 0.35 + 0.65 * rnd();
      c.putImageData(img, 0, 0);
    }
  }
  if (tipCache.size > 64) tipCache.clear();
  tipCache.set(key, tip);
  return tip;
}

function symTransforms(sym) {
  const cx = S.doc.w / 2, cy = S.doc.h / 2;
  const id = (x, y) => [x, y];
  if (!sym || sym === "none") return [id];
  if (sym === "v") return [id, (x, y) => [2 * cx - x, y]];
  if (sym === "h") return [id, (x, y) => [x, 2 * cy - y]];
  if (sym === "vh") return [id, (x, y) => [2 * cx - x, y],
                            (x, y) => [x, 2 * cy - y], (x, y) => [2 * cx - x, 2 * cy - y]];
  const n = sym === "r4" ? 4 : sym === "r6" ? 6 : 8;
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = i * 2 * Math.PI / n, co = Math.cos(a), si = Math.sin(a);
    out.push((x, y) => {
      const dx = x - cx, dy = y - cy;
      return [cx + dx * co - dy * si, cy + dx * si + dy * co];
    });
  }
  return out;
}
function newStrokeState(op, canvas) {
  const st = { op, canvas, ctx: canvas.getContext("2d"), last: null, rest: 0,
               bbox: null, smooth: null, syms: symTransforms(op.sym),
               rand: FX.rng(hashSeed(op.id || "x")), stamps: [],
               mixColor: op.color, under: null };

  st.wash = !!op.wash && (op.tool === "brush" || op.tool === "eraser") && !(op.mix > 0 && op.tool === "brush");


  if (op.mix > 0 && op.tool === "brush") {
    const lay = layerById(op.layer);
    const lctx = lay ? targetCtxOf(lay, op.target) : null;
    if (lctx) {
      try { st.under = lctx.getImageData(0, 0, S.doc.w, S.doc.h).data; } catch (e) {}
    }
  }
  return st;
}
const quant = (v) => Math.min(255, Math.max(0, Math.round(v / 8) * 8));
function pickUnder(st, x, y) {
  const d = st.under;
  if (!d) return null;
  const px = Math.round(x), py = Math.round(y);
  if (px < 0 || py < 0 || px >= S.doc.w || py >= S.doc.h) return null;
  const i = (py * S.doc.w + px) * 4;
  if (d[i + 3] < 8) return null;
  return [d[i], d[i + 1], d[i + 2]];
}
function growBbox(st, x, y, r) {
  const b = st.bbox || { x0: x - r, y0: y - r, x1: x + r, y1: y + r };
  b.x0 = Math.min(b.x0, x - r); b.y0 = Math.min(b.y0, y - r);
  b.x1 = Math.max(b.x1, x + r); b.y1 = Math.max(b.y1, y + r);
  st.bbox = b;

  const f = st.frameBox;
  st.frameBox = f ? { x0: Math.min(f.x0, x - r), y0: Math.min(f.y0, y - r), x1: Math.max(f.x1, x + r), y1: Math.max(f.y1, y + r) }
                  : { x0: x - r, y0: y - r, x1: x + r, y1: y + r };
}






function taperT(st, dist) {
  const op = st.op;
  if (!(op.taperIn > 0) && !(op.taperOut > 0)) return 1;
  const total = st.total;
  let Lin, Lout;
  if (op.taperUnit === "px") {
    Lin = op.taperIn || 0; Lout = op.taperOut || 0;
    if (total && Lin + Lout > total) { const s = total / (Lin + Lout); Lin *= s; Lout *= s; }
    Lin = Lin > 0 ? Math.max(1, Lin) : 0; Lout = Lout > 0 ? Math.max(1, Lout) : 0;
  } else {
    const inP = (op.taperIn || 0) / 100, outP = (op.taperOut || 0) / 100;
    Lin = inP > 0 ? Math.max(1, (total ? total : 400) * inP) : 0;
    Lout = outP > 0 && total ? Math.max(1, total * outP) : 0;
  }
  let t = 1;
  if (Lin > 0 && dist < Lin) t = Math.min(t, dist / Lin);
  if (Lout > 0 && total) { const rest = total - dist; if (rest < Lout) t = Math.min(t, rest / Lout); }
  return t;
}
function taperScale(st, dist) {
  const t = taperT(st, dist);
  if (t >= 1) return 1;
  const op = st.op;
  const f = op.taperShape ? Math.pow(Math.max(0, t), Math.pow(2, op.taperShape / 50)) : t;
  if (op.taperTip == null) return 0.08 + 0.92 * f;
  const tip = clamp(op.taperTip / 100, 0, 1);
  return tip + (1 - tip) * f;
}
function stampAt(st, x, y, p, dir) {
  const op = st.op;
  const base = op.size;
  const rnd = st.rand;

  const pS = pcurve(p, op.pcSize), pO = pcurve(p, op.pcOp);

  const mS = clamp((op.pMinSize ?? 15) / 100, 0, 1), mO = clamp((op.pMinOp ?? 0) / 100, 0, 1);
  const tk = taperScale(st, st.dist || 0);
  let sz = Math.max(0.6, base * (op.pSize ? (mS + (1 - mS) * pS) : 1) * tk);
  let alpha = op.pOp ? clamp(mO + (1 - mO) * pO * 1.15, 0.04, 1) : 1;

  if (op.taperOp) alpha *= tk;

  if (op.speedSize) { const k = op.speedSize / 100, v = st.speedNow || 0; sz *= Math.max(0.1, k > 0 ? 1 - k * v : 1 + k * (1 - v)); }
  if (op.speedOp) { const k = op.speedOp / 100, v = st.speedNow || 0; alpha *= Math.max(0.05, k > 0 ? 1 - k * v : 1 + k * (1 - v)); }

  const tl = op.tilt ? (st.tiltNow || 0) : 0;
  if (tl) { sz *= 1 + tl * 0.8; alpha *= 1 - tl * 0.45; }

  if (op.jSize) sz *= Math.max(0.2, 1 + (rnd() - 0.5) * 1.2 * (op.jSize / 100));
  if (op.jOpacity) alpha *= 1 - rnd() * (op.jOpacity / 100);
  alpha = clamp(alpha, 0.02, 1);



  if (op.dsp && !(op.scatter > 0) && (op.spacing || 0.12) <= 0.3) {
    const ratio = op.spacing || 0.12, ref = Math.max(0.8, base * ratio);
    const sp = clamp(sz * ratio, 0.5, ref);
    st.spNext = sp;
    if (alpha < 1 && !st.wash) alpha = 1 - Math.pow(1 - alpha, sp / ref);
  }
  const white = op.tool !== "brush";
  if (st.under) {



    const u = pickUnder(st, x, y);
    if (u) {
      const m = op.mix / 100;
      const base = hexRgb(op.color);
      const cur = hexRgb(st.mixColor);
      const k = 0.14;
      st.mixColor = rgbHex(
        quant(cur[0] + ((base[0] + (u[0] - base[0]) * m) - cur[0]) * k),
        quant(cur[1] + ((base[1] + (u[1] - base[1]) * m) - cur[1]) * k),
        quant(cur[2] + ((base[2] + (u[2] - base[2]) * m) - cur[2]) * k));
    }
  }
  const tip = getTip(base, st.mixColor, op.hard ?? 0.7, white || op.target === "mask",
                     op.brushShape);
  const sc = op.scatter || 0;

  const asp = clamp(op.aspect ?? 1, 0.08, 1);
  let rot = (op.angle || 0) * Math.PI / 180;
  if (op.follow && dir !== undefined) rot += dir;
  if (op.jAngle) rot += (rnd() - 0.5) * 2 * Math.PI * (op.jAngle / 100);
  const shaped = asp !== 1 || rot !== 0;
  if (st.wash) {
    for (const t of st.syms) {
      let [tx, ty] = t(x, y);
      if (sc) { tx += (rnd() - 0.5) * base * sc; ty += (rnd() - 0.5) * base * sc; }
      washDab(st, tip, tx, ty, sz, asp, rot, alpha);
      growBbox(st, tx, ty, sz / 2 + 2);
    }
    return;
  }
  for (const t of st.syms) {
    let [tx, ty] = t(x, y);
    if (sc) {
      tx += (rnd() - 0.5) * base * sc;
      ty += (rnd() - 0.5) * base * sc;
    }
    st.ctx.globalAlpha = alpha;
    if (shaped) {
      st.ctx.save();
      st.ctx.translate(tx, ty);
      st.ctx.rotate(rot);
      st.ctx.drawImage(tip, -sz / 2, -sz * asp / 2, sz, sz * asp);
      st.ctx.restore();
    } else {
      st.ctx.drawImage(tip, tx - sz / 2, ty - sz / 2, sz, sz);
    }
    growBbox(st, tx, ty, sz / 2 + 2);
  }
}





function walkStroke(st, pts, spacing, cb) {
  if (!st.op.curve) { walkLinear(st, pts, spacing, cb); return; }
  const buf = st.cr || (st.cr = []);
  for (const q of pts) {
    const prev = buf[buf.length - 1];
    if (prev && prev[0] === q[0] && prev[1] === q[1]) { buf[buf.length - 1] = q; continue; }
    buf.push(q);
    if (buf.length === 1) walkLinear(st, [q], spacing, cb);
    else if (buf.length >= 3) {
      const n = buf.length;
      walkLinear(st, crSegment(buf[n - 4] || buf[n - 3], buf[n - 3], buf[n - 2], buf[n - 1]), spacing, cb);
      if (buf.length > 4) buf.shift();
    }
  }
}
function strokeFinish(st, spacing, cb) {
  const buf = st.cr;
  if (!st.op.curve || !buf || buf.length < 2) return;
  const n = buf.length;
  walkLinear(st, crSegment(buf[n - 3] || buf[n - 2], buf[n - 2], buf[n - 1], buf[n - 1]), spacing, cb);
  st.cr = null;
}


function crSegment(p0, p1, p2, p3) {
  const d01 = Math.max(1e-4, Math.sqrt(Math.hypot(p1[0] - p0[0], p1[1] - p0[1])));
  const d12 = Math.max(1e-4, Math.sqrt(Math.hypot(p2[0] - p1[0], p2[1] - p1[1])));
  const d23 = Math.max(1e-4, Math.sqrt(Math.hypot(p3[0] - p2[0], p3[1] - p2[1])));
  const chord = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]);
  const steps = Math.max(1, Math.min(64, Math.ceil(chord / 2)));

  const tan = (a, b, c, da, db) => [
    (b[0] - a[0]) / da - (c[0] - a[0]) / (da + db) + (c[0] - b[0]) / db,
    (b[1] - a[1]) / da - (c[1] - a[1]) / (da + db) + (c[1] - b[1]) / db];
  let m1 = p0 === p1 ? [p2[0] - p1[0], p2[1] - p1[1]] : tan(p0, p1, p2, d01, d12).map((v) => v * d12);
  let m2 = p2 === p3 ? [p2[0] - p1[0], p2[1] - p1[1]] : tan(p1, p2, p3, d12, d23).map((v) => v * d12);
  const out = [];
  for (let k = 1; k <= steps; k++) {
    const t = k / steps, t2 = t * t, t3 = t2 * t;
    const h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
    const q = [h00 * p1[0] + h10 * m1[0] + h01 * p2[0] + h11 * m2[0],
               h00 * p1[1] + h10 * m1[1] + h01 * p2[1] + h11 * m2[1],
               p1[2] + (p2[2] - p1[2]) * t];
    if (p1.length > 3 || p2.length > 3) q.push((p1[3] || 0) + ((p2[3] || 0) - (p1[3] || 0)) * t);
    if (p1.length > 4 || p2.length > 4) q.push((p1[4] || 0) + ((p2[4] || 0) - (p1[4] || 0)) * t);
    out.push(q);
  }
  return out;
}
function walkLinear(st, pts, spacing, cb) {
  if (st.dist === undefined) st.dist = 0;

  for (const [x, y, p, tl, sv] of pts) {
    st.tiltNow = tl || 0;
    st.speedNow = sv || 0;
    if (!st.last) { cb(x, y, p, st.dirAngle); st.last = { x, y, p }; st.rest = 0; continue; }
    const dx = x - st.last.x, dy = y - st.last.y;
    const dist = Math.hypot(dx, dy);
    if (dist === 0) { st.last.p = p; continue; }



    st.dirAngle = Math.atan2(dy, dx);

    const sp0 = (st.op.dsp && st.spNext) || spacing;
    if (st.rest + dist < sp0) {
      st.rest += dist; st.dist += dist; st.last = { x, y, p }; continue;
    }
    let t = (sp0 - st.rest) / dist, lastT = 0;
    while (t <= 1) {
      st.dist += dist * (t - lastT);
      cb(st.last.x + dx * t, st.last.y + dy * t, st.last.p + (p - st.last.p) * t, st.dirAngle);
      lastT = t;
      t += ((st.op.dsp && st.spNext) || spacing) / dist;
    }
    st.dist += dist * (1 - lastT);
    st.rest = dist * (1 - lastT);
    st.last = { x, y, p };
  }
}
function ptsLength(pts) {
  let L = 0;
  for (let i = 1; i < pts.length; i++)
    L += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
  return L;
}


function smoothPts(pts, strength) {
  if (pts.length < 5 || strength <= 0) return pts;
  const passes = Math.min(6, Math.round(strength / 18) + 1);
  let cur = pts.map((p) => p.slice());
  for (let k = 0; k < passes; k++) {
    const next = cur.map((p) => p.slice());
    for (let i = 1; i < cur.length - 1; i++) {
      next[i][0] = (cur[i - 1][0] + cur[i][0] * 2 + cur[i + 1][0]) / 4;
      next[i][1] = (cur[i - 1][1] + cur[i][1] * 2 + cur[i + 1][1]) / 4;
    }
    cur = next;
  }

  return cur.map((p) => {
    const q = [Math.round(p[0] * 100) / 100, Math.round(p[1] * 100) / 100, p[2]];
    if (p.length > 3) q.push(...p.slice(3));
    return q;
  });
}






function washBuf(st) {
  const c = st.canvas, n = S.doc.w * S.doc.h;
  if (!c._wash || c._wash.length !== n) { c._wash = new Float32Array(n); c._washBox = null; }
  return c._wash;
}
function tipAlphaOf(tip) {
  if (tip._a) return tip._a;
  const d = tip.getContext("2d").getImageData(0, 0, tip.width, tip.height).data;
  const a = new Float32Array(tip.width * tip.height);
  for (let i = 0; i < a.length; i++) a[i] = d[i * 4 + 3] / 255;
  tip._a = a;
  return a;
}
function washDab(st, tip, cx, cy, sz, asp, rot, cap) {
  const buf = washBuf(st), W = S.doc.w, H = S.doc.h;
  const ta = tipAlphaOf(tip), tw = tip.width, th = tip.height;
  const hw = sz / 2, hh = sz * asp / 2;
  const co = Math.cos(rot), si = Math.sin(rot);
  const ex = Math.abs(hw * co) + Math.abs(hh * si), ey = Math.abs(hw * si) + Math.abs(hh * co);
  const x0 = Math.max(0, Math.floor(cx - ex)), x1 = Math.min(W - 1, Math.ceil(cx + ex));
  const y0 = Math.max(0, Math.floor(cy - ey)), y1 = Math.min(H - 1, Math.ceil(cy + ey));
  if (x1 < x0 || y1 < y0) return;
  const flow = clamp((st.op.flow ?? 100) / 100, 0.01, 1);
  const sx = tw / (2 * hw), sy = th / (2 * hh);
  for (let y = y0; y <= y1; y++) {
    const dy = y + 0.5 - cy;
    for (let x = x0; x <= x1; x++) {
      const dx = x + 0.5 - cx;

      const u = (dx * co + dy * si) * sx + tw / 2 - 0.5;
      const v = (-dx * si + dy * co) * sy + th / 2 - 0.5;
      if (u < 0 || v < 0 || u > tw - 1 || v > th - 1) continue;
      const iu = u | 0, iv = v | 0, fu = u - iu, fv = v - iv;
      const k = iv * tw + iu;
      const iu1 = iu + 1 < tw ? 1 : 0, iv1 = iv + 1 < th ? tw : 0;
      const m = (ta[k] * (1 - fu) + ta[k + iu1] * fu) * (1 - fv) +
                (ta[k + iv1] * (1 - fu) + ta[k + iv1 + iu1] * fu) * fv;
      if (m <= 0) continue;
      const i = y * W + x, d = buf[i];
      if (d < cap) buf[i] = d + (cap - d) * flow * m;
    }
  }
  const b = st.canvas._washBox, nb = st.washDirty;
  st.canvas._washBox = b ? { x0: Math.min(b.x0, x0), y0: Math.min(b.y0, y0), x1: Math.max(b.x1, x1), y1: Math.max(b.y1, y1) }
                         : { x0, y0, x1, y1 };
  st.washDirty = nb ? { x0: Math.min(nb.x0, x0), y0: Math.min(nb.y0, y0), x1: Math.max(nb.x1, x1), y1: Math.max(nb.y1, y1) }
                    : { x0, y0, x1, y1 };
}

function washFlush(st) {
  const r = st.washDirty;
  if (!r) return;
  st.washDirty = null;
  const buf = washBuf(st), W = S.doc.w;
  const w = r.x1 - r.x0 + 1, h = r.y1 - r.y0 + 1;
  const img = st.ctx.createImageData(w, h), d = img.data;
  const white = st.op.tool !== "brush" || st.op.target === "mask";
  const [cr, cg, cb] = white ? [255, 255, 255] : hexRgb(st.op.color);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const gx = x + r.x0, gy = y + r.y0;
      const a = buf[gy * W + gx];
      if (a <= 0) continue;
      const dith = (((gx * 73856093) ^ (gy * 19349663)) & 255) / 255 - 0.5;
      const o = (y * w + x) * 4;
      d[o] = cr; d[o + 1] = cg; d[o + 2] = cb;
      d[o + 3] = clamp(Math.round(a * 255 + dith), 0, 255);
    }
  }
  st.ctx.save();
  st.ctx.setTransform(1, 0, 0, 1, 0, 0);
  st.ctx.putImageData(img, r.x0, r.y0);
  st.ctx.restore();
}
function washClear(canvas) {
  const b = canvas._washBox, buf = canvas._wash;
  if (!b || !buf) return;
  const W = S.doc.w;
  for (let y = b.y0; y <= b.y1; y++) buf.fill(0, y * W + b.x0, y * W + b.x1 + 1);
  canvas._washBox = null;
}
function strokeAddPoints(st, pts, finish) {
  const spacing = Math.max(0.8, st.op.size * (st.op.spacing || 0.12));
  const cb = (x, y, p, dir) => {
    stampAt(st, x, y, p, dir);
    if (st.op.tool === "smudge" || st.op.tool === "blur") st.stamps.push([x, y, p]);
  };
  walkStroke(st, pts, spacing, cb);
  if (finish) strokeFinish(st, spacing, cb);
  if (st.wash) washFlush(st);
}






let paperTile = null;
const grainPatterns = new Map();
function paperTileCanvas() {
  if (paperTile) return paperTile;
  const N = 256;
  const small = makeCanvas(64, 64);
  const sx = small.getContext("2d");
  const img = sx.createImageData(64, 64);
  const rnd = FX.rng(20260727);
  for (let i = 0; i < 64 * 64; i++) {
    const v = Math.round(rnd() * 255);
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = v;
    img.data[i * 4 + 3] = 255;
  }
  sx.putImageData(img, 0, 0);
  paperTile = makeCanvas(N, N);
  const cx = paperTile.getContext("2d");
  cx.imageSmoothingEnabled = true;
  cx.drawImage(small, 0, 0, N, N);
  cx.globalAlpha = 0.45;
  cx.drawImage(small, 0, 0, N / 3, N / 3);
  cx.drawImage(small, N / 3, 0, N / 3, N / 3);
  cx.globalAlpha = 1;
  return paperTile;
}

function grainPattern(g) {
  const key = Math.round(g * 10);
  if (grainPatterns.has(key)) return grainPatterns.get(key);
  const src = paperTileCanvas();
  const N = src.width;
  const c = makeCanvas(N, N), cx = c.getContext("2d");
  cx.drawImage(src, 0, 0);
  const img = cx.getImageData(0, 0, N, N);


  const gg = Math.pow(key / 10, 1.6);
  for (let i = 0; i < N * N; i++) {
    const n = img.data[i * 4] / 255;
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = 255;
    img.data[i * 4 + 3] = Math.round(255 * (1 - gg * (1 - n)));
  }
  cx.putImageData(img, 0, 0);
  const pat = strokeCtx.createPattern(c, "repeat");
  grainPatterns.set(key, pat);
  return pat;
}
function applyGrain(st) {
  const g = (st.op.grain || 0) / 100;
  if (!g || st.op.target === "mask") return;
  const ctx = st.ctx;
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "destination-in";
  ctx.fillStyle = grainPattern(g);
  ctx.fillRect(0, 0, st.canvas.width, st.canvas.height);
  ctx.restore();
}
function clearStrokeCanvas(st) {
  st.ctx.setTransform(1, 0, 0, 1, 0, 0);
  st.ctx.clearRect(0, 0, st.canvas.width, st.canvas.height);
  st.bbox = null; st.last = null; st.rest = 0; st.stamps = []; st.cr = null; st.spNext = undefined;
  washClear(st.canvas); st.washDirty = null;
}
function bboxOf(st) {
  const b = st.bbox;
  if (!b) return null;
  const x0 = clamp(Math.floor(b.x0), 0, S.doc.w), y0 = clamp(Math.floor(b.y0), 0, S.doc.h);
  const x1 = clamp(Math.ceil(b.x1), 0, S.doc.w), y1 = clamp(Math.ceil(b.y1), 0, S.doc.h);
  return (x1 > x0 && y1 > y0) ? { x0, y0, x1, y1 } : null;
}









let spreadC = null, spreadPrevC = null;
function effVisible(i) {
  const e = S.layers[i];
  if (!e || !e.visible) return false;
  let d = e.depth;
  for (let j = i - 1; j >= 0 && d > 0; j--) {
    const f = S.layers[j];
    if (f.depth < d) { if (!f.visible) return false; d = f.depth; }
  }
  return true;
}
function finalizeSpread(st, record) {
  const op = st.op, box = bboxOf(st);
  if (!box) { clearStrokeCanvas(st); return; }
  applyGrain(st);
  const w = box.x1 - box.x0, h = box.y1 - box.y0, n = w * h;

  if (!spreadC) spreadC = makeCanvas();
  if (spreadC.width !== S.doc.w || spreadC.height !== S.doc.h) { spreadC.width = S.doc.w; spreadC.height = S.doc.h; }
  const sx = spreadC.getContext("2d", { willReadFrequently: true });
  sx.setTransform(1, 0, 0, 1, 0, 0);
  sx.globalCompositeOperation = "source-over"; sx.globalAlpha = 1;
  sx.clearRect(0, 0, S.doc.w, S.doc.h);
  paintThrough(sx, op.sel, "source-over", 1, (t) => t.drawImage(st.canvas, 0, 0));
  const sd = sx.getImageData(box.x0, box.y0, w, h).data;
  clearStrokeCanvas(st);
  const EPS = 1 / 510, erase = op.tool === "eraser", opa = op.opacity ?? 1;
  const rem = new Float32Array(n);
  let left = 0;
  for (let i = 0; i < n; i++) { const r = sd[i * 4 + 3] / 255 * opa; rem[i] = r; if (r > EPS) left++; }
  const snaps = [];
  let bytes = 0;
  const region = (c) => c.getImageData(box.x0, box.y0, w, h);
  for (let li = S.layers.length - 1; li >= 0 && left > 0; li--) {
    const L = S.layers[li];
    if (L.type === "folder" || L.type === "adjust" || !L.ctx || !effVisible(li)) continue;
    const img = region(L.ctx), d = img.data;
    let bd = null, md = null;
    if (L.clip) {
      for (let j = li - 1; j >= 0; j--) {
        const e = S.layers[j];
        if (e.depth < L.depth) break;
        if (e.depth === L.depth && !e.clip) { if (e.ctx) bd = region(e.ctx).data; break; }
      }
    }
    if (L.hasMask && L.mask) md = region(L.mask.getContext("2d", { willReadFrequently: true })).data;
    const paintable = (L.type || "raster") === "raster" && !isText(L) && !isDoll(L) && !isVector(L);
    const lop = L.opacity ?? 1;
    let before = null;
    for (let i = 0, p = 0; i < n; i++, p += 4) {
      const r = rem[i];
      if (r <= EPS || d[p + 3] === 0) continue;
      let cov = d[p + 3] / 255 * lop;
      if (bd) cov *= bd[p + 3] / 255;
      if (md) cov *= md[p + 3] / 255;
      if (cov <= 0) continue;
      if (paintable) {
        if (!before) before = new Uint8ClampedArray(d);
        if (erase) d[p + 3] = Math.round(d[p + 3] * (1 - r));
        else {
          d[p] = Math.round(d[p] + (sd[p] - d[p]) * r);
          d[p + 1] = Math.round(d[p + 1] + (sd[p + 1] - d[p + 1]) * r);
          d[p + 2] = Math.round(d[p + 2] + (sd[p + 2] - d[p + 2]) * r);
        }
      }
      const nr = r * (1 - cov);
      rem[i] = nr;
      if (nr <= EPS) left--;
    }
    if (before) {
      L.ctx.putImageData(img, box.x0, box.y0);
      if (record) { snaps.push({ ctx: L.ctx, img: new ImageData(before, w, h), x: box.x0, y: box.y0 }); bytes += before.length; }
    }
  }
  if (record && snaps.length)
    pushHistory(op.id, opLabel(op) + "(全体・" + snaps.length + " 枚)", () => {
      for (const s of snaps) s.ctx.putImageData(s.img, s.x, s.y);
      rebuildLayerList(); touch();
    }, bytes);

  if (record && snaps.length) rebuildLayerList(); else updateThumb();
  touch();
  requestRender();
}






const silCs = {};
let liveClipC = null;


function silhouetteNow(fromDisplay) {
  const key = fromDisplay ? "local" : "replay";
  if (!silCs[key]) silCs[key] = makeCanvas();
  const silC = silCs[key];
  if (silC.width !== S.doc.w || silC.height !== S.doc.h) { silC.width = S.doc.w; silC.height = S.doc.h; }
  const x = silC.getContext("2d");

  if (fromDisplay && docC && S.composedAt === S.composeVersion && !S.forceCompose && !livePreviewActive()) {
    x.setTransform(1, 0, 0, 1, 0, 0);
    x.globalAlpha = 1; x.globalCompositeOperation = "copy";
    x.drawImage(docC, 0, 0);
    x.globalCompositeOperation = "source-over";
  } else compositeInto(x);
  return silC;
}

function beginLocalStroke(op) {
  const sil = op.clipAll ? silhouetteNow(true) : null;
  const st = newStrokeState(op, strokeCanvas);
  st.sil = sil;
  return st;
}

function liveStrokeImage() {
  const st = S.stroke;
  if (!st || !st.sil) return strokeCanvas;
  if (!liveClipC) liveClipC = makeCanvas();
  const c = liveClipC;
  if (c.width !== S.doc.w || c.height !== S.doc.h) { c.width = S.doc.w; c.height = S.doc.h; }
  const x = c.getContext("2d");
  x.setTransform(1, 0, 0, 1, 0, 0);
  x.globalAlpha = 1; x.globalCompositeOperation = "copy";
  x.drawImage(strokeCanvas, 0, 0);
  x.globalCompositeOperation = "destination-in";
  x.drawImage(st.sil, 0, 0);
  x.globalCompositeOperation = "source-over";
  return c;
}

function finalizeStroke(st, record) {
  if (st.op.spread) { finalizeSpread(st, record); return; }
  const layer = layerById(st.op.layer);
  const box = bboxOf(st);
  if (!layer || !box) { clearStrokeCanvas(st); return; }
  const ctx = targetCtxOf(layer, st.op.target);
  if (!ctx) { clearStrokeCanvas(st); return; }
  if (st.op.clipAll) {
    const sil = st.sil || silhouetteNow(false);
    st.ctx.save();
    st.ctx.setTransform(1, 0, 0, 1, 0, 0);
    st.ctx.globalAlpha = 1; st.ctx.globalCompositeOperation = "destination-in";
    st.ctx.drawImage(sil, 0, 0);
    st.ctx.restore();
  }
  const snap = record ? grabSnap(ctx, box) : null;
  if (st.op.tool === "gapfill") {
    applyGapFill(st, ctx, box);
  } else if (st.op.tool === "blur" || st.op.tool === "smudge") {
    applyPixelBrush(st, ctx, box);
  } else {
    applyGrain(st);
    const mode = st.op.tool === "eraser" ? "destination-out"
      : (st.op.target !== "mask" && layer.alphaLock) ? "source-atop" : "source-over";
    paintThrough(ctx, st.op.sel, mode, st.op.opacity,
                 (t) => t.drawImage(st.canvas, 0, 0));
  }
  clearStrokeCanvas(st);
  if (snap) pushHistory(st.op.id, opLabel(st.op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
  requestRender();
}



function applyGapFill(st, ctx, box) {
  const w = box.x1 - box.x0, h = box.y1 - box.y0;
  const img = ctx.getImageData(box.x0, box.y0, w, h);
  const mask = st.ctx.getImageData(box.x0, box.y0, w, h).data;
  const refFull = refImageData(st.op.ref || "ref", ctx);
  const [cr, cg, cb] = hexRgb(st.op.color);
  const W = S.doc.w;
  const d = img.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (mask[i + 3] < 20) continue;
      if (d[i + 3] > 200) continue;
      const j = ((y + box.y0) * W + (x + box.x0)) * 4;
      if (refFull.data[j + 3] > 120) continue;
      d[i] = cr; d[i + 1] = cg; d[i + 2] = cb; d[i + 3] = 255;
    }
  }
  if (st.op.sel) {
    scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
    scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
    scratch3Ctx.putImageData(img, box.x0, box.y0);
    ctx.save();
    clipSel(ctx, st.op.sel);
    ctx.clearRect(box.x0, box.y0, w, h);
    ctx.drawImage(scratch3, 0, 0);
    ctx.restore();
  } else ctx.putImageData(img, box.x0, box.y0);
}

function applyPixelBrush(st, ctx, box) {
  const w = box.x1 - box.x0, h = box.y1 - box.y0;
  const img = ctx.getImageData(box.x0, box.y0, w, h);
  const mask = st.ctx.getImageData(box.x0, box.y0, w, h).data;
  const strength = st.op.opacity;
  if (st.op.tool === "blur") {
    const blurred = new Uint8ClampedArray(img.data);
    FX.blur(blurred, w, h, Math.max(1, st.op.size / 6));
    for (let i = 0; i < img.data.length; i += 4) {
      const m = mask[i + 3] / 255 * strength;
      if (m <= 0) continue;
      for (let c = 0; c < 4; c++)
        img.data[i + c] = img.data[i + c] * (1 - m) + blurred[i + c] * m;
    }
  } else {

    const d = img.data;
    const rad = Math.max(1, st.op.size / 2);
    let prev = null;
    for (const [sx, sy] of st.stamps) {
      if (!prev) { prev = [sx, sy]; continue; }
      const ox = prev[0] - sx, oy = prev[1] - sy;
      const cx = sx - box.x0, cy = sy - box.y0;
      const r = Math.ceil(rad);
      for (let y = -r; y <= r; y++) {
        for (let x = -r; x <= r; x++) {
          const dist = Math.hypot(x, y);
          if (dist > rad) continue;
          const px = Math.round(cx + x), py = Math.round(cy + y);
          if (px < 0 || py < 0 || px >= w || py >= h) continue;
          const sxp = Math.round(px + ox), syp = Math.round(py + oy);
          if (sxp < 0 || syp < 0 || sxp >= w || syp >= h) continue;
          const fall = (1 - dist / rad) * strength * 0.7;
          const i = (py * w + px) * 4, j = (syp * w + sxp) * 4;
          for (let c = 0; c < 4; c++) d[i + c] = d[i + c] * (1 - fall) + d[j + c] * fall;
        }
      }
      prev = [sx, sy];
    }
  }

  if (st.op.sel) {
    scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
    scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
    scratch3Ctx.putImageData(img, box.x0, box.y0);
    ctx.save();
    clipSel(ctx, st.op.sel);
    ctx.clearRect(box.x0, box.y0, w, h);
    ctx.drawImage(scratch3, 0, 0);
    ctx.restore();
  } else ctx.putImageData(img, box.x0, box.y0);
}


function shapePts(kind, a, b, size) {
  const sp = Math.max(1, size * 0.12);
  const pts = [];
  const seg = (p, q) => {
    const n = Math.max(1, Math.ceil(Math.hypot(q[0] - p[0], q[1] - p[1]) / sp));
    for (let i = 0; i <= n; i++)
      pts.push([p[0] + (q[0] - p[0]) * i / n, p[1] + (q[1] - p[1]) * i / n, 1]);
  };
  if (kind === "line") seg(a, b);
  else if (kind === "rect") {
    const c = [b[0], a[1]], d = [a[0], b[1]];
    seg(a, c); seg(c, b); seg(b, d); seg(d, a);
  } else if (kind === "ellipse") {
    const cx = (a[0] + b[0]) / 2, cy = (a[1] + b[1]) / 2;
    const rx = Math.abs(b[0] - a[0]) / 2, ry = Math.abs(b[1] - a[1]) / 2;
    const n = Math.max(16, Math.ceil(2 * Math.PI * Math.max(rx, ry) / sp));
    for (let i = 0; i <= n; i++) {
      const t = i / n * 2 * Math.PI;
      pts.push([cx + rx * Math.cos(t), cy + ry * Math.sin(t), 1]);
    }
  }
  return pts.map((p) => [Math.round(p[0] * 100) / 100, Math.round(p[1] * 100) / 100, p[2]]);
}


function grabSnap(ctx, box) {
  const img = ctx.getImageData(box.x0, box.y0, box.x1 - box.x0, box.y1 - box.y0);
  return { img, x: box.x0, y: box.y0, bytes: img.data.length };
}
function putSnap(ctx, snap) { ctx.putImageData(snap.img, snap.x, snap.y); }
function pushHistory(opId, label, restore, bytes = 0) {
  S.history.push({ opId, label, restore, bytes });
  S.histBytes += bytes;
  while (S.history.length > S.MAXHIST ||
         (S.histBytes > S.MAXBYTES && S.history.length > 3)) {
    const g = S.history.shift();
    S.histBytes -= g.bytes || 0;
    (S.pastSteps ||= []).push(g.label);
  }
  updateHistoryPanel();
}
function opLabel(op) {
  const t = { brush: "ブラシ", eraser: "消しゴム", blur: "ぼかし", smudge: "指先" }[op.tool];
  switch (op.kind) {
    case "stroke": return (op.shape ? { line: "直線", rect: "四角", ellipse: "楕円" }[op.shape] : t || "描画")
                        + (op.target === "mask" ? "(マスク)" : "");
    case "fill": return "塗りつぶし";
    case "gradient": return "グラデーション";
    case "filter": return FILTERS[op.filter]?.name || "フィルタ";
    case "text": return "テキスト";
    case "setText": return op.first ? "テキスト作成" : "文字の編集";
    case "setDoll": return "ポーズ変更";
    case "rasterizeText": return "文字を絵に変換";
    case "balloon": return "フキダシ";
    case "gen": return GENERATORS[op.gen]?.name || "生成";
    case "vecErase": return { inter: "交点まで消去", touch: "部分消去", whole: "線を消去" }[op.mode];
    case "vecWidth": return "線幅の変更";
    case "vecEdit": return "線の形を変更";
    case "vecStyle": return "線の色・太さ変更";
    case "vecDelete": return "線を削除";
    case "transform": return "変形";
    case "stamp": return MATERIALS[op.mat]?.name || "素材";
    case "hairSet": return "髪プリセット";
    case "autoColor": return "自動で下塗り";
    case "addLayer": return "レイヤー追加";
    case "addFolder": return "フォルダ追加";
    case "groupLayer": return "フォルダにまとめる";
    case "setDepth": return "フォルダ出し入れ";
    case "addAdjust": return "調整レイヤー追加";
    case "setAdjust": return "調整レイヤー設定";
    case "delLayer": return "レイヤー削除";
    case "dupLayer": return "レイヤー複製";
    case "mergeDown": return "下と結合";
    case "clearLayer": return "消去";
    case "flipLayer": return op.axis === "h" ? "左右反転" : "上下反転";
    case "offsetLayer": return "レイヤー移動";
    case "moveLayer": return "重ね順変更";
    case "setMask": return op.on ? "マスク追加" : "マスク削除";
    case "setLayer": return "レイヤー設定";
    default: return op.kind;
  }
}


function applyStrokeOp(op, record) {
  S.remote.delete(op.id);
  const vlay = layerById(op.layer);
  if (isVector(vlay) && op.target !== "mask") {

    vlay.strokes.push({ ...op });
    drawVecStroke(vlay, op);
    if (record) pushHistory(op.id, opLabel(op), () => {
      const i = vlay.strokes.findIndex((s) => s.id === op.id);
      if (i >= 0) vlay.strokes.splice(i, 1);
      rebuildVector(vlay); updateThumb();
    });
    updateThumb();
    touch();
    return;
  }


  const st = newStrokeState(op, replayC || makeCanvas());
  st.total = ptsLength(op.pts);
  strokeAddPoints(st, op.pts, true);
  finalizeStroke(st, record);
}
function applyFillOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  if (!ctx) return;
  const W = S.doc.w, H = S.doc.h;
  let mask;
  if (op.enclose) {
    mask = encloseMask(op.enclose, op.ref || "all", ctx, op.gapClose || 0);
  } else {
    const x = clamp(Math.round(op.x), 0, W - 1), y = clamp(Math.round(op.y), 0, H - 1);
    mask = floodMask(ctx, x, y, op.tol, op.grow, op.gapClose || 0, op.ref || "layer");
  }
  if (!mask) return;
  const box = maskBBox(mask, W, H);
  if (!box) return;
  const snap = record ? grabSnap(ctx, box) : null;
  paintMask(mask, box, op.color);
  const mode = (op.target !== "mask" && layer.alphaLock) ? "source-atop" : "source-over";
  paintThrough(ctx, op.sel, mode, op.opacity, (t) => t.drawImage(scratch3, 0, 0));
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
}



function refImageData(mode, layerCtx) {
  const W = S.doc.w, H = S.doc.h;
  if (mode === "ref") {
    const refs = S.layers.filter((l) => l.isRef && isRaster(l));
    if (refs.length) {
      const t = tempAt(SEL_LEVEL + 1);
      for (const l of refs) t.ctx.drawImage(l.hasMask ? maskedCanvas(l) : l.canvas, 0, 0);
      return t.ctx.getImageData(0, 0, W, H);
    }
    mode = "all";
  }
  if (mode === "all") { compositeInto(scratchCtx); return scratchCtx.getImageData(0, 0, W, H); }
  return layerCtx.getImageData(0, 0, W, H);
}

function floodMask(srcCtx, x, y, tol, grow, gapClose, refMode) {
  const W = S.doc.w, H = S.doc.h;
  const ref = refMode !== undefined ? refImageData(refMode, srcCtx)
            : (!srcCtx ? refImageData("all") : srcCtx.getImageData(0, 0, W, H));
  const d = ref.data;

  let wall = null;
  if (gapClose > 0) {
    wall = new Uint8Array(W * H);
    for (let i = 0; i < W * H; i++) if (d[i * 4 + 3] > 60) wall[i] = 1;
    for (let g = 0; g < gapClose; g++) {
      const src = wall.slice();
      for (let i = 0; i < W * H; i++) {
        if (src[i]) continue;
        if ((i % W > 0 && src[i - 1]) || (i % W < W - 1 && src[i + 1]) ||
            (i >= W && src[i - W]) || (i < W * H - W && src[i + W])) wall[i] = 1;
      }
    }
    if (wall[y * W + x]) wall[y * W + x] = 0;
  }
  const i0 = (y * W + x) * 4;
  const r0 = d[i0], g0 = d[i0 + 1], b0 = d[i0 + 2], a0 = d[i0 + 3];
  const mask = new Uint8Array(W * H);
  const match = (i) => {
    if (wall && wall[i]) return false;
    const j = i * 4;
    return Math.abs(d[j] - r0) <= tol && Math.abs(d[j + 1] - g0) <= tol &&
           Math.abs(d[j + 2] - b0) <= tol && Math.abs(d[j + 3] - a0) <= tol;
  };
  const stack = [y * W + x];
  mask[y * W + x] = 1;
  while (stack.length) {
    const i = stack.pop();
    let lx = i, rx = i;
    while (lx % W > 0 && !mask[lx - 1] && match(lx - 1)) { lx--; mask[lx] = 1; }
    while (rx % W < W - 1 && !mask[rx + 1] && match(rx + 1)) { rx++; mask[rx] = 1; }
    for (let j = lx; j <= rx; j++)
      for (const k of [j - W, j + W])
        if (k >= 0 && k < W * H && !mask[k] && match(k)) { mask[k] = 1; stack.push(k); }
  }

  const expand = (grow || 0) + (gapClose || 0);
  for (let g = 0; g < expand; g++) {
    const src = mask.slice();
    for (let i = 0; i < W * H; i++) {
      if (src[i]) continue;
      if ((i % W > 0 && src[i - 1]) || (i % W < W - 1 && src[i + 1]) ||
          (i >= W && src[i - W]) || (i < W * H - W && src[i + W])) mask[i] = 1;
    }
  }
  return mask;
}








function dilateMask(mask, W, H, rounds) {
  for (let g = 0; g < rounds; g++) {
    const src = mask.slice();
    for (let i = 0, n = W * H; i < n; i++) {
      if (src[i]) continue;
      if ((i % W > 0 && src[i - 1]) || (i % W < W - 1 && src[i + 1]) ||
          (i >= W && src[i - W]) || (i < n - W && src[i + W])) mask[i] = 1;
    }
  }
  return mask;
}

function computeAutoRegions(o) {
  const W = S.doc.w, H = S.doc.h, n = W * H;
  const lay = S.layers[S.active];
  const ref = refImageData(o.refMode || "ref", lay && lay.ctx ? lay.ctx : null);
  const d = ref.data;
  const wall = new Uint8Array(n);
  for (let i = 0; i < n; i++) if (d[i * 4 + 3] > 60) wall[i] = 1;
  dilateMask(wall, W, H, o.gapClose || 0);

  const labels = new Int32Array(n);
  const regions = [];
  const stack = [];
  for (let s = 0; s < n; s++) {
    if (wall[s] || labels[s]) continue;
    const id = regions.length + 1;
    let size = 0, x0 = W, y0 = H, x1 = 0, y1 = 0, border = false;
    labels[s] = id; stack.push(s);
    while (stack.length) {
      const i = stack.pop();
      size++;
      const x = i % W, y = (i / W) | 0;
      if (x < x0) x0 = x; if (x > x1) x1 = x;
      if (y < y0) y0 = y; if (y > y1) y1 = y;
      if (x === 0 || y === 0 || x === W - 1 || y === H - 1) border = true;
      if (x > 0 && !wall[i - 1] && !labels[i - 1]) { labels[i - 1] = id; stack.push(i - 1); }
      if (x < W - 1 && !wall[i + 1] && !labels[i + 1]) { labels[i + 1] = id; stack.push(i + 1); }
      if (i >= W && !wall[i - W] && !labels[i - W]) { labels[i - W] = id; stack.push(i - W); }
      if (i < n - W && !wall[i + W] && !labels[i + W]) { labels[i + W] = id; stack.push(i + W); }
    }
    regions.push({ id, size, border, box: { x0, y0, x1: x1 + 1, y1: y1 + 1 } });
  }

  const minArea = Math.max(1, o.minArea || 200);
  let keep = regions.filter((r) => r.size >= minArea);

  if (o.skipBg !== false) {
    let bg = null;
    for (const r of keep) if (r.border && (!bg || r.size > bg.size)) bg = r;
    if (bg) keep = keep.filter((r) => r !== bg);
  }

  keep.sort((a, b) => b.size - a.size);
  if (o.maxCount) keep = keep.slice(0, o.maxCount);





  const expand = (o.gapClose || 0) * 2 + (o.grow || 0) + 2;
  {
    const alive = new Set(keep.map((r) => r.id));
    for (let g = 0; g < expand; g++) {
      const src = labels.slice();
      let moved = false;
      for (let i = 0; i < n; i++) {
        if (src[i]) continue;
        const x = i % W;


        let v = 0;
        if (x > 0 && alive.has(src[i - 1])) v = src[i - 1];
        else if (x < W - 1 && alive.has(src[i + 1])) v = src[i + 1];
        else if (i >= W && alive.has(src[i - W])) v = src[i - W];
        else if (i < n - W && alive.has(src[i + W])) v = src[i + W];
        if (v) { labels[i] = v; moved = true; }
      }
      if (!moved) break;
    }

    for (const r of keep) {
      r.box.x0 = Math.max(0, r.box.x0 - expand);
      r.box.y0 = Math.max(0, r.box.y0 - expand);
      r.box.x1 = Math.min(W, r.box.x1 + expand);
      r.box.y1 = Math.min(H, r.box.y1 + expand);
    }
  }
  return { labels, regions: keep };
}

function autoRegionColor(i) {
  const h = (i * 137.508) % 360;
  const [r, g, b] = hsvToRgb(h, 0.33, 0.97);
  return rgbHex(r, g, b);
}
function paintRegionInto(ctx, labels, region, color) {
  const W = S.doc.w;
  const b = region.box;
  const w = b.x1 - b.x0, h = b.y1 - b.y0;
  if (w <= 0 || h <= 0) return;
  const [cr, cg, cb] = hexRgb(color);
  const img = new ImageData(w, h);
  for (let y = b.y0; y < b.y1; y++)
    for (let x = b.x0; x < b.x1; x++) {
      if (labels[y * W + x] !== region.id) continue;
      const o = ((y - b.y0) * w + (x - b.x0)) * 4;
      img.data[o] = cr; img.data[o + 1] = cg; img.data[o + 2] = cb; img.data[o + 3] = 255;
    }
  ctx.putImageData(img, b.x0, b.y0);
}


function encloseMask(poly, refMode, layerCtx, gapClose) {
  const W = S.doc.w, H = S.doc.h;
  const t = tempAt(SEL_LEVEL + 2);
  t.ctx.fillStyle = "#fff";
  selPath(t.ctx, { type: "poly", pts: poly });
  t.ctx.fill("evenodd");
  const ins = t.ctx.getImageData(0, 0, W, H).data;
  const ref = refImageData(refMode, layerCtx).data;
  const wall = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) if (ref[i * 4 + 3] > 60) wall[i] = 1;
  for (let g = 0; g < (gapClose || 0); g++) {
    const src = wall.slice();
    for (let i = 0; i < W * H; i++) {
      if (src[i]) continue;
      if ((i % W > 0 && src[i - 1]) || (i % W < W - 1 && src[i + 1]) ||
          (i >= W && src[i - W]) || (i < W * H - W && src[i + W])) wall[i] = 1;
    }
  }
  const inside = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) if (ins[i * 4 + 3] > 128) inside[i] = 1;

  const outside = new Uint8Array(W * H);
  const stack = [];
  for (let i = 0; i < W * H; i++) {
    if (!inside[i] || wall[i]) continue;
    const px = i % W, py = (i / W) | 0;
    if (px === 0 || py === 0 || px === W - 1 || py === H - 1 ||
        !inside[i - 1] || !inside[i + 1] || !inside[i - W] || !inside[i + W]) {
      outside[i] = 1; stack.push(i);
    }
  }
  while (stack.length) {
    const i = stack.pop();
    for (const k of [i - 1, i + 1, i - W, i + W]) {
      if (k < 0 || k >= W * H) continue;
      if (!inside[k] || wall[k] || outside[k]) continue;
      outside[k] = 1; stack.push(k);
    }
  }
  const mask = new Uint8Array(W * H);
  let any = false;
  for (let i = 0; i < W * H; i++)
    if (inside[i] && !outside[i]) { mask[i] = 1; any = true; }
  return any ? mask : null;
}
function maskBBox(mask, W, H) {
  let x0 = W, y0 = H, x1 = 0, y1 = 0, any = false;
  for (let i = 0; i < W * H; i++) {
    if (!mask[i]) continue;
    any = true;
    const px = i % W, py = (i / W) | 0;
    if (px < x0) x0 = px; if (px > x1) x1 = px;
    if (py < y0) y0 = py; if (py > y1) y1 = py;
  }
  return any ? { x0, y0, x1: x1 + 1, y1: y1 + 1 } : null;
}
function paintMask(mask, box, color) {
  const W = S.doc.w;
  const [cr, cg, cb] = hexRgb(color);
  const w = box.x1 - box.x0, h = box.y1 - box.y0;
  const img = new ImageData(w, h);
  for (let py = box.y0; py < box.y1; py++)
    for (let px = box.x0; px < box.x1; px++) {
      if (!mask[py * W + px]) continue;
      const o = ((py - box.y0) * w + (px - box.x0)) * 4;
      img.data[o] = cr; img.data[o + 1] = cg; img.data[o + 2] = cb; img.data[o + 3] = 255;
    }
  scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
  scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  scratch3Ctx.putImageData(img, box.x0, box.y0);
}

function applyGradientOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  const box = op.sel ? selBBox(op.sel) : { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
  const snap = record ? grabSnap(ctx, box) : null;
  let g;
  if (op.type === "radial") {
    const r = Math.hypot(op.x1 - op.x0, op.y1 - op.y0);
    g = ctx.createRadialGradient(op.x0, op.y0, 0, op.x0, op.y0, Math.max(1, r));
  } else g = ctx.createLinearGradient(op.x0, op.y0, op.x1, op.y1);
  const [r0, g0, b0] = hexRgb(op.c0);
  g.addColorStop(0, `rgba(${r0},${g0},${b0},1)`);
  if (op.mode === "fg2trans") g.addColorStop(1, `rgba(${r0},${g0},${b0},0)`);
  else g.addColorStop(1, op.c1);
  const gmode = (op.target !== "mask" && layer.alphaLock) ? "source-atop" : "source-over";
  paintThrough(ctx, op.sel, gmode, op.opacity ?? 1, (t) => {
    t.fillStyle = g;
    t.fillRect(box.x0, box.y0, box.x1 - box.x0, box.y1 - box.y0);
  });
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
}

function runFilter(ctx, filter, params, sel, seed) {
  const box = sel ? selBBox(sel) : { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
  const w = box.x1 - box.x0, h = box.y1 - box.y0;
  if (w <= 0 || h <= 0) return null;
  const img = ctx.getImageData(box.x0, box.y0, w, h);
  if (!applyFilterData(img.data, w, h, filter, params, seed)) return null;
  return { img, box };
}






const fxColor = (p) => p.color || "#000000";
const fxSub   = (p) => p.sub   || "#ffffff";
function applyFilterData(d, w, h, filter, params, seed) {
  const p = params || {};

  if (w * h > 250000 &&
      FX.glPixel(d, w, h, filter, { ...p, color: hexRgb(fxColor(p)) })) return true;
  switch (filter) {
    case "hsv": FX.hsv(d, p.h || 0, p.s || 0, p.v || 0); break;
    case "bc": FX.brightContrast(d, p.b || 0, p.c || 0); break;
    case "levels": FX.levels(d, p.inLo ?? 0, p.inHi ?? 255, (p.gamma ?? 100) / 100,
                             p.outLo ?? 0, p.outHi ?? 255); break;
    case "blur": FX.blur(d, w, h, p.r ?? 8); break;
    case "sharpen": {
      const b = new Uint8ClampedArray(d);
      FX.blur(b, w, h, p.r ?? 2);
      FX.sharpen(d, b, p.amount ?? 100);
      break;
    }
    case "lum2alpha": FX.lumToAlpha(d, fxColor(p), (p.keep | 0) === 1); break;
    case "lineart": FX.lineart(d, w, h, { ...p, color: hexRgb(fxColor(p)) }); break;
    case "binarize": FX.binarize(d, p.t ?? 128); break;
    case "gray": FX.grayscale(d); break;
    case "invert": FX.invert(d); break;
    case "noise": FX.noise(d, p.amount ?? 20, seed, (p.mono | 0) === 1); break;
    case "mosaic": FX.mosaic(d, w, h, p.size ?? 20); break;
    case "gradmap": FX.gradientMap(d, [[0, hexRgb(fxColor(p))], [1, hexRgb(fxSub(p))]]); break;
    case "halftone": FX.halftone(d, w, h, p.pitch ?? 8, p.angle ?? 45, hexRgb(fxColor(p))); break;
    case "curve": FX.curve(d, p.pts || [[0, 0], [255, 255]], p.ch || "rgb"); break;
    default: return false;
  }
  return true;
}
function applyFilterOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  const res = runFilter(ctx, op.filter, op.params, op.sel, hashSeed(op.id));
  if (!res) return;
  const snap = record ? grabSnap(ctx, res.box) : null;
  writeFiltered(ctx, res, op.sel);
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
}
function writeFiltered(ctx, res, sel) {
  const { img, box } = res;
  if (!sel) { ctx.putImageData(img, box.x0, box.y0); return; }
  scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
  scratch3Ctx.globalCompositeOperation = "source-over";
  scratch3Ctx.globalAlpha = 1;
  scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  scratch3Ctx.putImageData(img, box.x0, box.y0);
  if (selNeedsMask(sel)) {

    paintThrough(ctx, sel, "source-over", 1, (t) => t.drawImage(scratch3, 0, 0));
  } else {
    ctx.save();
    clipSel(ctx, sel);
    ctx.clearRect(box.x0, box.y0, box.x1 - box.x0, box.y1 - box.y0);
    ctx.drawImage(scratch3, 0, 0);
    ctx.restore();
  }
}



const VERT_ROTATE = new Set(["ー", "〜", "～", "(", ")", "（", "）", "「", "」",
                             "『", "』", "【", "】", "[", "]", "{", "}", "<", ">",
                             "〈", "〉", "《", "》", "|", "…", "‥", "―", "-", "－"]);

const VERT_SHIFT = new Set(["、", "。", "，", "．", ",", "."]);



function fontCss(key) {
  if (FONTS[key]) return FONTS[key];
  const m = /^(f|sys):(.+)$/.exec(key || "");
  return m ? `"${m[2].replace(/["\\]/g, "")}",${FONTS.gothic}` : FONTS.gothic;
}


function textOpts(op) {
  return { trk: op.size * (op.track || 0) / 100, lhK: (op.lineH || 100) / 100,
           ow: Math.max(0, +op.outline || 0) };
}
function textMetrics(op) {
  const probe = scratch3Ctx;
  const o = textOpts(op);
  probe.font = `${op.size}px ${fontCss(op.font)}`;
  const lines = String(op.text).split("\n");
  if (op.vertical) {
    const colW = op.size * 1.45 * o.lhK;
    let maxLen = 0;
    for (const ln of lines) maxLen = Math.max(maxLen, [...ln].length);

    const totalW = lines.length * colW;
    return { lines, colW, lh: op.size, w: totalW, h: Math.max(0, maxLen * (op.size + o.trk) - o.trk),
             x0: op.x - totalW, y0: op.y };
  }
  const lh = op.size * 1.35 * o.lhK;
  const widths = lines.map((ln) => o.trk
    ? [...ln].reduce((s, ch) => s + probe.measureText(ch).width, 0) + o.trk * Math.max(0, [...ln].length - 1)
    : probe.measureText(ln).width);
  const wmax = Math.max(0, ...widths);
  const x0 = op.align === "center" ? op.x - wmax / 2 : op.align === "right" ? op.x - wmax : op.x;
  return { lines, lh, w: wmax, h: lines.length * lh, x0, y0: op.y, widths };
}
function drawTextOn(ctx, op) {
  const m = textMetrics(op);
  const o = textOpts(op);
  ctx.save();
  clipSel(ctx, op.sel);
  ctx.font = `${op.size}px ${fontCss(op.font)}`;
  ctx.fillStyle = op.color;

  const passes = o.ow > 0 ? ["stroke", "fill"] : ["fill"];
  if (o.ow > 0) {
    ctx.lineWidth = o.ow * 2;
    ctx.lineJoin = "round";
    ctx.strokeStyle = op.outlineColor || "#ffffff";
  }
  for (const pass of passes) {
    const put = pass === "stroke" ? (s, x, y) => ctx.strokeText(s, x, y)
                                  : (s, x, y) => ctx.fillText(s, x, y);
    if (op.vertical) {
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      m.lines.forEach((ln, ci) => {
        const cx = op.x - m.colW * (ci + 0.5);
        [...ln].forEach((ch, k) => {
          const cy = op.y + k * (op.size + o.trk);
          if (VERT_ROTATE.has(ch)) {
            ctx.save();
            ctx.translate(cx, cy + op.size / 2);
            ctx.rotate(Math.PI / 2);
            put(ch, 0, -op.size / 2);
            ctx.restore();
          } else if (VERT_SHIFT.has(ch)) {
            put(ch, cx + op.size * 0.32, cy - op.size * 0.28);
          } else {
            put(ch, cx, cy);
          }
        });
      });
    } else if (!o.trk) {
      ctx.textAlign = op.align || "left";
      ctx.textBaseline = "top";
      m.lines.forEach((ln, i) => put(ln, op.x, op.y + i * m.lh));
    } else {

      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      m.lines.forEach((ln, i) => {
        const w = m.widths[i];
        let x = op.align === "center" ? op.x - w / 2 : op.align === "right" ? op.x - w : op.x;
        for (const ch of ln) { put(ch, x, op.y + i * m.lh); x += ctx.measureText(ch).width + o.trk; }
      });
    }
  }
  ctx.restore();
}
function applyTextOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  if (!ctx) return;
  const m = textMetrics(op);
  const pad = Math.ceil(op.size * 0.6) + 8 + Math.ceil(textOpts(op).ow);
  const box = { x0: clamp(Math.floor(m.x0) - pad, 0, S.doc.w),
                y0: clamp(Math.floor(m.y0) - pad, 0, S.doc.h),
                x1: clamp(Math.ceil(m.x0 + m.w) + pad, 0, S.doc.w),
                y1: clamp(Math.ceil(m.y0 + m.h) + pad, 0, S.doc.h) };
  if (box.x1 <= box.x0 || box.y1 <= box.y0) return;
  const snap = record ? grabSnap(ctx, box) : null;
  drawTextOn(ctx, op);
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
}






function isText(l) { return l && l.type === "text"; }
function textLayerName(t) {
  const s = String((t && t.text) || "").replace(/\s+/g, " ").trim();
  return s ? s.slice(0, 12) : "テキスト";
}
function rebuildText(lay) {
  if (!isText(lay) || !lay.ctx) return;
  lay.ctx.setTransform(1, 0, 0, 1, 0, 0);
  lay.ctx.globalCompositeOperation = "source-over";
  lay.ctx.globalAlpha = 1;
  lay.ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  if (lay.text && String(lay.text.text || "").trim()) drawTextOn(lay.ctx, lay.text);
  touch();
  updateThumb();
}
function balloonPath(ctx, op) {
  const x0 = Math.min(op.x0, op.x1), x1 = Math.max(op.x0, op.x1);
  const y0 = Math.min(op.y0, op.y1), y1 = Math.max(op.y0, op.y1);
  const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
  const rx = (x1 - x0) / 2, ry = (y1 - y0) / 2;
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);

  const a0 = Math.PI * 0.62, a1 = Math.PI * 0.80;
  const p0 = [cx + rx * Math.cos(a0), cy + ry * Math.sin(a0)];
  const p1 = [cx + rx * Math.cos(a1), cy + ry * Math.sin(a1)];
  const tip = [cx - rx * 0.55, cy + ry * 1.75];
  ctx.moveTo(p0[0], p0[1]);
  ctx.lineTo(tip[0], tip[1]);
  ctx.lineTo(p1[0], p1[1]);
  ctx.closePath();
  return { x0: clamp(x0 - op.lw - 2, 0, S.doc.w), y0: clamp(y0 - op.lw - 2, 0, S.doc.h),
           x1: clamp(x1 + op.lw + 2, 0, S.doc.w),
           y1: clamp(Math.max(y1, tip[1]) + op.lw + 4, 0, S.doc.h) };
}
function applyBalloonOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  const probe = scratch3Ctx;
  probe.save();
  const box = balloonPath(probe, op);
  probe.restore();
  const snap = record ? grabSnap(ctx, box) : null;
  ctx.save();
  clipSel(ctx, op.sel);
  balloonPath(ctx, op);
  ctx.fillStyle = op.fill;
  ctx.fill();
  ctx.lineWidth = op.lw;
  ctx.strokeStyle = op.line;
  ctx.lineJoin = "round";
  ctx.stroke();
  ctx.restore();
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
}

function runGen(ctx, key, p, sel, seed) {
  const W = S.doc.w, H = S.doc.h;
  if (key === "speed") {
    const rnd = FX.rng(seed);
    const cx = W / 2, cy = H / 2;
    const R = Math.hypot(W, H) * 0.62;
    const inner = R * (p.inner ?? 22) / 100;
    ctx.save();
    clipSel(ctx, sel);
    ctx.fillStyle = fxColor(p);
    const n = p.count ?? 180;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + rnd() * 0.02;
      const jit = 1 - (p.jitter ?? 55) / 100 * rnd();
      const r0 = inner * (0.85 + rnd() * 0.4) / Math.max(0.25, jit);


      const wdt = (p.width ?? 14) * (0.35 + rnd() * 0.9) / R;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
      ctx.lineTo(cx + Math.cos(a - wdt) * R, cy + Math.sin(a - wdt) * R);
      ctx.lineTo(cx + Math.cos(a + wdt) * R, cy + Math.sin(a + wdt) * R);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    return { x0: 0, y0: 0, x1: W, y1: H };
  }
  if (key === "outline") {
    const wdt = Math.max(1, p.width ?? 6);
    scratch2Ctx.setTransform(1, 0, 0, 1, 0, 0);
    scratch2Ctx.globalCompositeOperation = "source-over";
    scratch2Ctx.globalAlpha = 1;
    scratch2Ctx.clearRect(0, 0, W, H);
    const steps = Math.max(8, Math.min(32, wdt * 4));
    for (let i = 0; i < steps; i++) {
      const a = i / steps * Math.PI * 2;
      scratch2Ctx.drawImage(ctx.canvas, Math.cos(a) * wdt, Math.sin(a) * wdt);
    }
    scratch2Ctx.globalCompositeOperation = "source-in";
    scratch2Ctx.fillStyle = fxColor(p);
    scratch2Ctx.fillRect(0, 0, W, H);
    scratch2Ctx.globalCompositeOperation = "source-over";
    ctx.save();
    clipSel(ctx, sel);
    ctx.globalCompositeOperation = "destination-over";
    ctx.drawImage(scratch2, 0, 0);
    ctx.restore();
    return { x0: 0, y0: 0, x1: W, y1: H };
  }
  if (key === "frame") {
    const m = p.margin ?? 40, lw = p.width ?? 10;
    ctx.save();
    clipSel(ctx, sel);
    ctx.strokeStyle = fxColor(p);
    ctx.lineWidth = lw;
    ctx.strokeRect(m + lw / 2, m + lw / 2, W - 2 * m - lw, H - 2 * m - lw);
    ctx.restore();
    return { x0: 0, y0: 0, x1: W, y1: H };
  }
  return null;
}






function heartPath(c) {
  c.beginPath();
  c.moveTo(0, 0.78);
  c.bezierCurveTo(-1.3, -0.18, -0.58, -1.05, 0, -0.36);
  c.bezierCurveTo(0.58, -1.05, 1.3, -0.18, 0, 0.78);
  c.closePath();
}
function starPath(c, n = 5, inner = 0.45) {
  c.beginPath();
  for (let i = 0; i < n * 2; i++) {
    const a = -Math.PI / 2 + i * Math.PI / n;
    const r = i % 2 ? inner : 1;
    const x = Math.cos(a) * r, y = Math.sin(a) * r;
    if (i) c.lineTo(x, y); else c.moveTo(x, y);
  }
  c.closePath();
}

function twinklePath(c, k = 0.16) {
  c.beginPath();
  c.moveTo(0, -1);
  c.quadraticCurveTo(k, -k, 1, 0);
  c.quadraticCurveTo(k, k, 0, 1);
  c.quadraticCurveTo(-k, k, -1, 0);
  c.quadraticCurveTo(-k, -k, 0, -1);
  c.closePath();
}
function dropPath(c) {
  c.beginPath();
  c.moveTo(0, -1);
  c.bezierCurveTo(0.62, -0.1, 0.72, 0.42, 0.36, 0.78);
  c.bezierCurveTo(0.06, 1.05, -0.36, 0.96, -0.58, 0.6);
  c.bezierCurveTo(-0.76, 0.3, -0.5, -0.3, 0, -1);
  c.closePath();
}
const MATERIALS = {
  eyeHi: { name: "瞳のハイライト", cat: "eye", draw(c, o) {
    c.fillStyle = o.color;
    c.beginPath(); c.ellipse(-0.18, -0.26, 0.52, 0.62, -0.3, 0, 7); c.fill();
    c.globalAlpha *= 0.85;
    c.beginPath(); c.ellipse(0.42, 0.38, 0.24, 0.2, 0, 0, 7); c.fill();
  } },
  sparkle: { name: "きらきら", cat: "eye", draw(c, o) {
    c.fillStyle = o.color;
    twinklePath(c, 0.14); c.fill();
  } },
  sparkleSet: { name: "きらきら(散らし)", cat: "eye", draw(c, o) {
    c.fillStyle = o.color;
    const rnd = FX.rng(o.seed >>> 0);
    const put = (x, y, s, a) => {
      c.save(); c.translate(x, y); c.scale(s, s); c.globalAlpha = a;
      twinklePath(c, 0.14); c.fill(); c.restore();
    };
    put(0, 0, 1, 1);
    for (let i = 0; i < 5; i++)
      put((rnd() - 0.5) * 2.6, (rnd() - 0.5) * 2.6, 0.18 + rnd() * 0.3, 0.5 + rnd() * 0.5);
  } },
  starHi: { name: "星のハイライト", cat: "eye", draw(c, o) {
    c.fillStyle = o.color; starPath(c, 5, 0.42); c.fill();
  } },
  heartEye: { name: "♡目(瞳に入れる)", cat: "eye", draw(c, o) {
    c.fillStyle = o.color; heartPath(c); c.fill();
    c.fillStyle = o.sub; c.globalAlpha *= 0.9;
    c.save(); c.translate(-0.3, -0.16); c.scale(0.26, 0.26);
    twinklePath(c, 0.14); c.fill(); c.restore();
  } },
  heart: { name: "♡", cat: "sym", draw(c, o) {
    c.fillStyle = o.color; heartPath(c); c.fill();
  } },
  heartOutline: { name: "♡(枠だけ)", cat: "sym", draw(c, o) {
    c.strokeStyle = o.color; c.lineWidth = 0.13; c.lineJoin = "round";
    heartPath(c); c.stroke();
  } },
  star: { name: "★", cat: "sym", draw(c, o) {
    c.fillStyle = o.color; starPath(c, 5, 0.45); c.fill();
  } },
  note: { name: "♪", cat: "sym", draw(c, o) {
    c.fillStyle = o.color;
    c.beginPath(); c.ellipse(-0.32, 0.55, 0.42, 0.31, -0.35, 0, 7); c.fill();
    c.beginPath();
    c.moveTo(0.02, 0.62); c.lineTo(0.02, -0.85);
    c.lineTo(0.72, -0.55); c.lineTo(0.72, -0.28); c.lineTo(0.2, -0.56);
    c.lineTo(0.2, 0.62); c.closePath(); c.fill();
  } },
  sweat: { name: "汗", cat: "sym", draw(c, o) {
    c.fillStyle = o.color; dropPath(c); c.fill();
    c.fillStyle = o.sub; c.globalAlpha *= 0.75;
    c.beginPath(); c.ellipse(-0.16, 0.36, 0.16, 0.24, -0.2, 0, 7); c.fill();
  } },
  anger: { name: "怒りマーク", cat: "sym", draw(c, o) {
    c.strokeStyle = o.color; c.lineWidth = 0.17; c.lineCap = "round";
    const v = (x, y, s, rot) => {
      c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s);
      c.beginPath(); c.moveTo(-0.5, -0.4); c.lineTo(0, 0.35); c.lineTo(0.5, -0.4); c.stroke();
      c.restore();
    };
    v(0, -0.5, 0.9, 0); v(-0.55, 0.25, 0.75, -0.9); v(0.55, 0.25, 0.75, 0.9);
  } },
};
const MAT_CATS = { eye: "瞳・きらきら", sym: "記号" };
function drawMaterial(ctx, op) {
  const m = MATERIALS[op.mat];
  if (!m) return;
  ctx.save();
  clipSel(ctx, op.sel);
  ctx.translate(op.x, op.y);
  ctx.rotate(op.angle || 0);
  ctx.scale(op.r, op.r);
  ctx.globalAlpha = op.opacity ?? 1;
  m.draw(ctx, { color: op.color, sub: op.sub, seed: hashSeed(op.id || "s") });
  ctx.restore();
}
function applyStampOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  if (!ctx) return;
  const pad = op.r * 3 + 8;
  const box = { x0: clamp(Math.floor(op.x - pad), 0, S.doc.w),
                y0: clamp(Math.floor(op.y - pad), 0, S.doc.h),
                x1: clamp(Math.ceil(op.x + pad), 0, S.doc.w),
                y1: clamp(Math.ceil(op.y + pad), 0, S.doc.h) };
  if (box.x1 <= box.x0 || box.y1 <= box.y0) return;
  const snap = record ? grabSnap(ctx, box) : null;
  drawMaterial(ctx, op);
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
  touch();
}







const DOLL_JOINTS = {
  head: { parent: "neck", x: 0, y: -0.44 },
  neck: { parent: "chest", x: 0, y: -0.31 },
  chest: { parent: "hip", x: 0, y: -0.21 },
  hip: { parent: null, x: 0, y: 0 },
  shoulderL: { parent: "chest", x: -0.095, y: -0.27 },
  elbowL: { parent: "shoulderL", x: -0.15, y: -0.11 },
  wristL: { parent: "elbowL", x: -0.185, y: 0.05 },
  shoulderR: { parent: "chest", x: 0.095, y: -0.27 },
  elbowR: { parent: "shoulderR", x: 0.15, y: -0.11 },
  wristR: { parent: "elbowR", x: 0.185, y: 0.05 },
  hipL: { parent: "hip", x: -0.06, y: 0.03 },
  kneeL: { parent: "hipL", x: -0.07, y: 0.26 },
  ankleL: { parent: "kneeL", x: -0.07, y: 0.48 },
  hipR: { parent: "hip", x: 0.06, y: 0.03 },
  kneeR: { parent: "hipR", x: 0.07, y: 0.26 },
  ankleR: { parent: "kneeR", x: 0.07, y: 0.48 },
};

const DOLL_BONES = [
  ["hip", "chest", 0.115], ["chest", "neck", 0.075], ["neck", "head", 0.05],
  ["chest", "shoulderL", 0.055], ["shoulderL", "elbowL", 0.045], ["elbowL", "wristL", 0.035],
  ["chest", "shoulderR", 0.055], ["shoulderR", "elbowR", 0.045], ["elbowR", "wristR", 0.035],
  ["hip", "hipL", 0.06], ["hipL", "kneeL", 0.058], ["kneeL", "ankleL", 0.042],
  ["hip", "hipR", 0.06], ["hipR", "kneeR", 0.058], ["kneeR", "ankleR", 0.042],
];

const DOLL_POSES = {
  stand: { name: "立ち", d: {} },
  tpose: { name: "Tポーズ", d: {
    elbowL: [-0.09, -0.16], wristL: [-0.09, -0.16],
    elbowR: [0.09, -0.16], wristR: [0.09, -0.16] } },
  cheer: { name: "両手を上げる", d: {
    elbowL: [-0.02, -0.26], wristL: [0.01, -0.44],
    elbowR: [0.02, -0.26], wristR: [-0.01, -0.44] } },
  walk: { name: "歩き", d: {
    elbowL: [0.03, -0.02], wristL: [0.07, -0.03],
    elbowR: [-0.03, 0.02], wristR: [-0.07, 0.04],
    kneeL: [0.07, -0.01], ankleL: [0.13, 0.0],
    kneeR: [-0.07, 0.0], ankleR: [-0.11, -0.02] } },


  run: { name: "走り(横向き)", d: {
    chest: [0.03, 0.01], neck: [0.04, 0.01], head: [0.05, 0.01],
    elbowL: [0.17, -0.05], wristL: [0.285, -0.29],
    elbowR: [-0.17, 0.03], wristR: [-0.325, -0.07],
    kneeL: [0.17, -0.06], ankleL: [0.23, -0.14],
    kneeR: [-0.13, 0.04], ankleR: [-0.27, -0.06] } },
  sit: { name: "座り(横向き)", d: {
    hip: [0, 0.16], chest: [0, 0.16], neck: [0, 0.16], head: [0, 0.16],
    shoulderL: [0, 0.16], elbowL: [0.06, 0.19], wristL: [0.12, 0.19],
    shoulderR: [0, 0.16], elbowR: [-0.02, 0.19], wristR: [0.02, 0.19],
    hipL: [0, 0.16], kneeL: [0.19, -0.07], ankleL: [0.19, -0.07],
    hipR: [0, 0.16], kneeR: [0.09, -0.07], ankleR: [0.09, -0.07] } },
};
function dollBasePose(x, y, h, pose, flip) {
  const d = (DOLL_POSES[pose] || DOLL_POSES.stand).d;
  const out = {};
  for (const [k, j] of Object.entries(DOLL_JOINTS)) {
    const off = d[k] || [0, 0];
    const jx = (j.x + off[0]) * (flip ? -1 : 1);
    out[k] = [x + jx * h, y + (j.y + off[1]) * h];
  }
  return out;
}

function dollChildren(name) {
  const out = [];
  for (const [k, j] of Object.entries(DOLL_JOINTS))
    if (j.parent === name) out.push(k, ...dollChildren(k));
  return out;
}
function dollMove(pose, name, dx, dy) {
  const next = { ...pose };
  for (const k of [name, ...dollChildren(name)])
    if (next[k]) next[k] = [next[k][0] + dx, next[k][1] + dy];
  return next;
}
function capsule(ctx, a, b, w) {
  const dx = b[0] - a[0], dy = b[1] - a[1];
  const len = Math.hypot(dx, dy) || 1;
  const ang = Math.atan2(dy, dx);
  ctx.save();
  ctx.translate(a[0], a[1]);
  ctx.rotate(ang);
  ctx.beginPath();
  ctx.moveTo(0, -w / 2);
  ctx.lineTo(len, -w / 2);
  ctx.arc(len, 0, w / 2, -Math.PI / 2, Math.PI / 2);
  ctx.lineTo(0, w / 2);
  ctx.arc(0, 0, w / 2, Math.PI / 2, -Math.PI / 2);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
function drawDoll(ctx, doll) {
  const p = doll.pose, h = doll.h;
  ctx.save();
  ctx.fillStyle = doll.color || "#8892a6";
  for (const [a, b, w] of DOLL_BONES) {
    if (!p[a] || !p[b]) continue;
    capsule(ctx, p[a], p[b], Math.max(2, w * h));
  }

  if (p.head) {
    ctx.beginPath();
    ctx.ellipse(p.head[0], p.head[1], h * 0.062, h * 0.078, 0, 0, 7);
    ctx.fill();
  }
  ctx.restore();
}
function isDoll(l) { return l && l.type === "doll"; }
function rebuildDoll(lay) {
  if (!isDoll(lay) || !lay.ctx) return;
  lay.ctx.setTransform(1, 0, 0, 1, 0, 0);
  lay.ctx.globalCompositeOperation = "source-over";
  lay.ctx.globalAlpha = 1;
  lay.ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  if (lay.doll) drawDoll(lay.ctx, lay.doll);
  touch();
  updateThumb();
}

function dollHit(lay, x, y) {
  if (!isDoll(lay) || !lay.doll) return null;
  const r = Math.max(10, lay.doll.h * 0.035);
  let best = null, bd = r * r;
  for (const [k, q] of Object.entries(lay.doll.pose)) {
    const d = (q[0] - x) ** 2 + (q[1] - y) ** 2;
    if (d <= bd) { bd = d; best = k; }
  }
  return best;
}






const HAIR_STYLES = { straight: "ストレート", bob: "ボブ", twin: "ツインテール" };
const HAIR_PART_NAMES = { back: "後ろ髪", sideL: "横髪 左", sideR: "横髪 右",
                          tailL: "ツインテール 左", tailR: "ツインテール 右",
                          bangs: "前髪" };
function hairParts(style) {
  return style === "twin" ? ["back", "tailL", "tailR", "sideL", "sideR", "bangs"]
                          : ["back", "sideL", "sideR", "bangs"];
}

function strandPath(c, ax, ay, bx, by, w0, bow) {
  const mx = (ax + bx) / 2, my = (ay + by) / 2;
  c.beginPath();
  c.moveTo(ax - w0 / 2, ay);
  c.quadraticCurveTo(mx - w0 * 0.35 + bow, my, bx, by);
  c.quadraticCurveTo(mx + w0 * 0.55 + bow, my, ax + w0 / 2, ay);
  c.closePath();
}
function drawHairPart(ctx, part, o) {
  const { x, y, r, style } = o;
  const long = style === "bob" ? r * 1.5 : r * 2.6;
  ctx.save();
  ctx.fillStyle = o.color;
  if (part === "back") {
    ctx.beginPath();
    ctx.moveTo(x - r * 1.06, y);
    ctx.quadraticCurveTo(x - r * 1.15, y + long, x - r * 0.55, y + long * 1.05);
    ctx.quadraticCurveTo(x, y + long * 1.18, x + r * 0.55, y + long * 1.05);
    ctx.quadraticCurveTo(x + r * 1.15, y + long, x + r * 1.06, y);
    ctx.quadraticCurveTo(x + r * 1.02, y - r * 1.25, x, y - r * 1.3);
    ctx.quadraticCurveTo(x - r * 1.02, y - r * 1.25, x - r * 1.06, y);
    ctx.closePath();
    ctx.fill();
  } else if (part === "sideL" || part === "sideR") {


    const s = part === "sideL" ? -1 : 1;
    strandPath(ctx, x + s * r * 0.82, y - r * 0.72,
               x + s * r * 0.74, y + r * (style === "bob" ? 0.95 : 1.7),
               r * 0.34, s * r * 0.3);
    ctx.fill();

    strandPath(ctx, x + s * r * 0.6, y - r * 0.78,
               x + s * r * 0.5, y + r * (style === "bob" ? 0.5 : 1.0),
               r * 0.2, s * r * 0.1);
    ctx.fill();
  } else if (part === "tailL" || part === "tailR") {
    const s = part === "tailL" ? -1 : 1;
    strandPath(ctx, x + s * r * 0.95, y - r * 0.78,
               x + s * r * 1.85, y + r * 2.3, r * 0.5, s * r * 0.75);
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(x + s * r * 1.02, y - r * 0.72, r * 0.2, r * 0.13, 0, 0, 7);
    ctx.fill();
  } else if (part === "bangs") {

    const n = 7;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1) - 0.5;
      const rootX = x + t * r * 1.85;
      const rootY = y - r * 1.02 + Math.abs(t) * r * 0.42;
      const tipX = rootX + t * r * 0.7;
      const tipY = y - r * 0.08 + (0.5 - Math.abs(t)) * r * 0.5;
      strandPath(ctx, rootX, rootY, tipX, tipY, r * 0.42, t * r * 0.18);
      ctx.fill();
    }



    ctx.beginPath();
    ctx.ellipse(x, y, r * 1.02, r * 1.22, 0, Math.PI, 0);
    ctx.quadraticCurveTo(x, y - r * 0.62, x - r * 1.02, y);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function applyGenOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  const box = { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
  const snap = record ? grabSnap(ctx, box) : null;
  runGen(ctx, op.gen, op.params || {}, op.sel, hashSeed(op.id));
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
}



function applyVecEraseOp(op, record) {
  const lay = layerById(op.layer);
  if (!isVector(lay)) return;
  const hit = vecHit(lay, op.x, op.y, op.tol || 12);
  if (!hit) return;
  const before = record ? lay.strokes.map((s) => ({ ...s })) : null;
  const s = lay.strokes[hit.si];
  const pieces = [];
  if (op.mode === "whole") {

  } else if (op.mode === "inter") {
    const ints = vecIntersections(lay, hit.si);
    let lo = 0, hi = s.pts.length - 1;
    for (const t of ints) { if (t <= hit.param) lo = t; }
    for (let i = ints.length - 1; i >= 0; i--) if (ints[i] > hit.param) hi = ints[i];
    const a = subPts(s.pts, 0, lo), b = subPts(s.pts, hi, s.pts.length - 1);
    if (a) pieces.push(a);
    if (b) pieces.push(b);
  } else {

    const r = op.tol || 12;
    let span = 0.5;
    for (let i = 1; i < s.pts.length; i++) {
      const L = Math.hypot(s.pts[i][0] - s.pts[i - 1][0], s.pts[i][1] - s.pts[i - 1][1]);
      if (L > 0.01) { span = r / L; break; }
    }
    const a = subPts(s.pts, 0, Math.max(0, hit.param - span));
    const b = subPts(s.pts, Math.min(s.pts.length - 1, hit.param + span), s.pts.length - 1);
    if (a) pieces.push(a);
    if (b) pieces.push(b);
  }
  lay.strokes.splice(hit.si, 1,
    ...pieces.map((pts, k) => ({ ...s, id: s.id + "_" + op.id.slice(-4) + k, pts })));
  rebuildVector(lay);
  if (record) pushHistory(op.id, opLabel(op), () => {
    lay.strokes = before; rebuildVector(lay); updateThumb();
  });
  updateThumb();
}


function vecHandles(s) {
  const n = s.pts.length;
  const step = Math.max(1, Math.round(n / 12));
  const idx = [];
  for (let i = 0; i < n; i += step) idx.push(i);
  if (idx[idx.length - 1] !== n - 1) idx.push(n - 1);
  return idx;
}
function applyVecEditOp(op, record) {
  const lay = layerById(op.layer);
  if (!isVector(lay)) return;
  const i = lay.strokes.findIndex((s) => s.id === op.stroke);
  if (i < 0) return;
  const before = record ? lay.strokes.map((s) => ({ ...s })) : null;
  lay.strokes[i] = { ...lay.strokes[i], pts: op.pts };
  rebuildVector(lay);
  if (record) pushHistory(op.id, opLabel(op), () => {
    lay.strokes = before; rebuildVector(lay); updateThumb();
  });
  updateThumb();
}
function applyVecStyleOp(op, record) {
  const lay = layerById(op.layer);
  if (!isVector(lay)) return;
  const i = lay.strokes.findIndex((s) => s.id === op.stroke);
  if (i < 0) return;
  const before = record ? lay.strokes.map((s) => ({ ...s })) : null;
  lay.strokes[i] = { ...lay.strokes[i], ...op.props };
  rebuildVector(lay);
  if (record) pushHistory(op.id, opLabel(op), () => {
    lay.strokes = before; rebuildVector(lay); updateThumb();
  });
  updateThumb();
}
function applyVecDeleteOp(op, record) {
  const lay = layerById(op.layer);
  if (!isVector(lay)) return;
  const i = lay.strokes.findIndex((s) => s.id === op.stroke);
  if (i < 0) return;
  const before = record ? lay.strokes.map((s) => ({ ...s })) : null;
  lay.strokes.splice(i, 1);
  rebuildVector(lay);
  if (record) pushHistory(op.id, opLabel(op), () => {
    lay.strokes = before; rebuildVector(lay); updateThumb();
  });
  updateThumb();
}
function applyVecWidthOp(op, record) {
  const lay = layerById(op.layer);
  if (!isVector(lay)) return;
  const before = record ? lay.strokes.map((s) => ({ ...s })) : null;
  for (const s of lay.strokes) s.size = clamp(s.size * op.scale, 0.5, 400);
  rebuildVector(lay);
  if (record) pushHistory(op.id, opLabel(op), () => {
    lay.strokes = before; rebuildVector(lay); updateThumb();
  });
  updateThumb();
}

function applyTransformOp(op, record) {
  const layer = layerById(op.layer);
  if (!layer) return;
  const ctx = targetCtxOf(layer, op.target);
  const full = { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
  const snap = record ? grabSnap(ctx, full) : null;

  scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
  scratch3Ctx.globalCompositeOperation = "source-over";
  scratch3Ctx.globalAlpha = 1;
  scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  scratch3Ctx.save();
  clipSel(scratch3Ctx, op.sel);
  scratch3Ctx.drawImage(ctx.canvas, 0, 0);
  scratch3Ctx.restore();

  ctx.save();
  if (op.sel) { clipSel(ctx, op.sel); ctx.clearRect(0, 0, S.doc.w, S.doc.h); }
  else ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  ctx.restore();

  ctx.save();
  ctx.setTransform(op.m[0], op.m[1], op.m[2], op.m[3], op.m[4], op.m[5]);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(scratch3, 0, 0);
  ctx.restore();
  if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
  updateThumb();
}

function applyOp(op, record) {
  switch (op.kind) {
    case "stroke": applyStrokeOp(op, record); break;
    case "fill": applyFillOp(op, record); break;
    case "gradient": applyGradientOp(op, record); break;
    case "filter": applyFilterOp(op, record); break;
    case "text": applyTextOp(op, record); break;
    case "balloon": applyBalloonOp(op, record); break;
    case "gen": applyGenOp(op, record); break;
    case "stamp": applyStampOp(op, record); break;
    case "vecErase": applyVecEraseOp(op, record); break;
    case "vecWidth": applyVecWidthOp(op, record); break;
    case "vecEdit": applyVecEditOp(op, record); break;
    case "vecStyle": applyVecStyleOp(op, record); break;
    case "vecDelete": applyVecDeleteOp(op, record); break;
    case "transform": applyTransformOp(op, record); break;
    case "setText": {
      const lay = layerById(op.layer);
      if (!lay || !isText(lay)) break;
      const prev = lay.text, prevName = lay.name;
      lay.text = { ...op.text };
      if (op.rename) lay.name = textLayerName(lay.text);
      rebuildText(lay);
      if (record) pushHistory(op.id, opLabel(op), () => {
        lay.text = prev; lay.name = prevName; rebuildText(lay); rebuildLayerList();
      }, 512);
      rebuildLayerList();
      break;
    }
    case "setDoll": {
      const lay = layerById(op.layer);
      if (!lay || !isDoll(lay)) break;
      const prev = lay.doll;
      lay.doll = JSON.parse(JSON.stringify(op.doll));
      rebuildDoll(lay);
      if (record) pushHistory(op.id, opLabel(op), () => {
        lay.doll = prev; rebuildDoll(lay);
      }, 2048);
      break;
    }
    case "rasterizeText": {
      const lay = layerById(op.layer);
      if (!lay || !isText(lay)) break;
      const prev = lay.text;
      lay.type = "raster";
      delete lay.text;
      if (record) pushHistory(op.id, opLabel(op), () => {
        lay.type = "text"; lay.text = prev; rebuildText(lay); rebuildLayerList();
      }, 512);
      rebuildLayerList();
      touch();
      break;
    }
    case "hairSet": {
      const parts = hairParts(op.style);
      const at = clamp(op.at ?? S.layers.length, 0, S.layers.length);
      const made = parts.map((part, i) => {
        const lay = wrapLayer({ id: op.ids[i], name: HAIR_PART_NAMES[part], visible: true,
                                opacity: 1, blend: "normal", clip: false,
                                type: "raster", depth: op.depth || 0 });
        drawHairPart(lay.ctx, part, { x: op.x, y: op.y, r: op.r,
                                      style: op.style, color: op.color });
        return lay;
      });
      S.layers.splice(at, 0, ...made);
      S.active = at + made.length - 1;
      if (record) pushHistory(op.id, opLabel(op), () => {
        for (const m of made) {
          const i = layerIndex(m.id);
          if (i >= 0) S.layers.splice(i, 1);
        }
        S.active = clamp(S.active, 0, S.layers.length - 1);
        rebuildLayerList();
      }, 1024);
      rebuildLayerList();
      touch();
      break;
    }
    case "autoColor": {

      const res = computeAutoRegions(op.opts);
      const made = [];
      const at = clamp(op.at ?? S.layers.length, 0, S.layers.length);
      if (!res.regions.length) { toast("塗れる領域が見つかりませんでした"); break; }




      if (op.split) {
        op.ids.forEach((id, i) => {
          const lay = wrapLayer({ id, name: `下塗り${i + 1}`, visible: true,
                                  opacity: 1, blend: "normal", clip: false,
                                  type: "raster", depth: op.depth || 0 });
          const r = res.regions[i];
          if (r) paintRegionInto(lay.ctx, res.labels, r, op.mono ? op.color : autoRegionColor(i));
          made.push(lay);
        });
      } else {
        const lay = wrapLayer({ id: op.ids[0], name: "下塗り", visible: true, opacity: 1,
                                blend: "normal", clip: false, type: "raster",
                                depth: op.depth || 0 });
        res.regions.forEach((r, i) =>
          paintRegionInto(lay.ctx, res.labels, r, op.mono ? op.color : autoRegionColor(i)));
        made.push(lay);
      }
      S.layers.splice(at, 0, ...made);
      S.active = at + made.length - 1;
      if (record) pushHistory(op.id, opLabel(op), () => {
        for (const m of made) {
          const i = layerIndex(m.id);
          if (i >= 0) S.layers.splice(i, 1);
        }
        S.active = clamp(S.active, 0, S.layers.length - 1);
        rebuildLayerList();
      }, 1024);
      rebuildLayerList();
      touch();
      toast(`${res.regions.length}個の領域を塗りました`);
      break;
    }
    case "addLayer": {
      const lay = wrapLayer(op.layer);
      const at = clamp(op.at ?? S.layers.length, 0, S.layers.length);
      S.layers.splice(at, 0, lay);
      S.active = at;
      if (isText(lay)) rebuildText(lay);
      if (isDoll(lay)) rebuildDoll(lay);
      if (record) pushHistory(op.id, opLabel(op), () => {
        const i = layerIndex(op.layer.id);
        if (i >= 0) { S.layers.splice(i, 1); S.active = clamp(S.active, 0, S.layers.length - 1); }
        rebuildLayerList();
      });
      rebuildLayerList();
      break;
    }
    case "delLayer": {
      const i = layerIndex(op.layer);
      if (i < 0) break;
      const [lay] = S.layers.splice(i, 1);
      S.active = clamp(S.active, 0, S.layers.length - 1);
      if (record) pushHistory(op.id, opLabel(op), () => {
        S.layers.splice(clamp(i, 0, S.layers.length), 0, lay);
        rebuildLayerList();
      });
      rebuildLayerList();
      break;
    }
    case "dupLayer": {
      const i = layerIndex(op.layer);
      if (i < 0) break;
      const src = S.layers[i];


      const lay = wrapLayer({ id: op.newId, name: src.name + "のコピー",
                              visible: src.visible, opacity: src.opacity,
                              blend: src.blend, clip: src.clip, alphaLock: src.alphaLock,
                              depth: src.depth, type: src.type,
                              text: src.text ? { ...src.text } : undefined,
                              doll: src.doll ? JSON.parse(JSON.stringify(src.doll)) : undefined,
                              strokes: src.strokes ? src.strokes.map((s) => ({ ...s })) : undefined,

                              filter: src.filter, params: src.params ? { ...src.params } : undefined });


      if (lay.ctx && src.canvas) lay.ctx.drawImage(src.canvas, 0, 0);
      if (src.hasMask && lay.ctx) { attachMask(lay); lay.maskCtx.clearRect(0, 0, S.doc.w, S.doc.h);
                         lay.maskCtx.drawImage(src.mask, 0, 0); }
      S.layers.splice(i + 1, 0, lay);
      S.active = i + 1;
      if (record) pushHistory(op.id, opLabel(op), () => {
        const j = layerIndex(op.newId);
        if (j >= 0) { S.layers.splice(j, 1); S.active = clamp(S.active, 0, S.layers.length - 1); }
        rebuildLayerList();
      });
      rebuildLayerList();
      break;
    }
    case "mergeDown": {
      const i = layerIndex(op.layer);
      if (i <= 0) break;
      const lay = S.layers[i], below = S.layers[i - 1];
      if (!below.ctx || isText(below) || isDoll(below)) {
        toast(isText(below) ? "テキストレイヤーには結合できません(先に「絵に変換」を)"
            : isDoll(below) ? "デッサン人形のレイヤーには結合できません"
                            : "下が絵のレイヤーではないので結合できません");
        break;
      }
      const snap = record ? grabSnap(below.ctx, { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h }) : null;
      below.ctx.save();
      below.ctx.globalAlpha = lay.opacity;
      below.ctx.globalCompositeOperation = lay.clip ? "source-atop" : blendGco(lay.blend);
      below.ctx.drawImage(maskedCanvas(lay), 0, 0);
      below.ctx.restore();
      S.layers.splice(i, 1);
      S.active = i - 1;
      if (record) pushHistory(op.id, opLabel(op), () => {
        putSnap(below.ctx, snap);
        S.layers.splice(Math.min(i, S.layers.length), 0, lay);
        rebuildLayerList();
      }, snap ? snap.bytes : 0);
      rebuildLayerList();
      break;
    }
    case "clearLayer": {
      const lay = layerById(op.layer);
      if (!lay) break;
      const ctx = targetCtxOf(lay, op.target);
      if (!ctx) { toast("テキストレイヤーは消去できません。🅣で文字を消すか、レイヤーごと削除してください"); break; }
      const box = op.sel ? selBBox(op.sel) : { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };
      const snap = record ? grabSnap(ctx, box) : null;
      if (selNeedsMask(op.sel)) {

        const t = tempAt(SEL_LEVEL);
        t.ctx.fillStyle = "#fff";
        t.ctx.fillRect(0, 0, S.doc.w, S.doc.h);
        t.ctx.globalCompositeOperation = "destination-in";
        t.ctx.drawImage(buildSelMask(op.sel), 0, 0);
        t.ctx.globalCompositeOperation = "source-over";
        ctx.save();
        ctx.globalCompositeOperation = "destination-out";
        ctx.drawImage(t.c, 0, 0);
        ctx.restore();
      } else {
        ctx.save();
        if (op.sel) clipSel(ctx, op.sel);
        ctx.clearRect(0, 0, S.doc.w, S.doc.h);
        ctx.restore();
      }
      if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
      updateThumb();
      break;
    }
    case "flipLayer": {
      const lay = layerById(op.layer);
      if (!lay) break;
      const ctx = targetCtxOf(lay, op.target);
      if (!ctx) { toast("テキストレイヤーは反転できません。先に「絵に変換」してください"); break; }
      scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
      scratch3Ctx.globalCompositeOperation = "source-over";
      scratch3Ctx.globalAlpha = 1;
      scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
      scratch3Ctx.drawImage(ctx.canvas, 0, 0);
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, S.doc.w, S.doc.h);
      if (op.axis === "h") { ctx.translate(S.doc.w, 0); ctx.scale(-1, 1); }
      else { ctx.translate(0, S.doc.h); ctx.scale(1, -1); }
      ctx.drawImage(scratch3, 0, 0);
      ctx.restore();
      if (record) pushHistory(op.id, opLabel(op),
        () => applyOp({ ...op, id: op.id + "_r" }, false));
      updateThumb();
      break;
    }
    case "offsetLayer": {
      const lay = layerById(op.layer);
      if (!lay) break;

      if (isText(lay) && op.target !== "mask") {
        const px = lay.text.x, py = lay.text.y;
        lay.text = { ...lay.text, x: px + op.dx, y: py + op.dy };
        rebuildText(lay);
        if (record) pushHistory(op.id, opLabel(op), () => {
          lay.text = { ...lay.text, x: px, y: py }; rebuildText(lay);
        }, 512);
        break;
      }
      if (isDoll(lay) && op.target !== "mask") {
        const prev = lay.doll;
        if (!prev) break;
        const pose = {};
        for (const [k, q] of Object.entries(prev.pose)) pose[k] = [q[0] + op.dx, q[1] + op.dy];
        lay.doll = { ...prev, pose };
        rebuildDoll(lay);
        if (record) pushHistory(op.id, opLabel(op), () => {
          lay.doll = prev; rebuildDoll(lay);
        }, 2048);
        break;
      }
      const ctx = targetCtxOf(lay, op.target);
      if (!ctx) break;
      const snap = record ? grabSnap(ctx, { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h }) : null;
      scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
      scratch3Ctx.globalCompositeOperation = "source-over";
      scratch3Ctx.globalAlpha = 1;
      scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
      scratch3Ctx.drawImage(ctx.canvas, 0, 0);
      ctx.clearRect(0, 0, S.doc.w, S.doc.h);
      ctx.drawImage(scratch3, op.dx, op.dy);
      if (snap) pushHistory(op.id, opLabel(op), () => { putSnap(ctx, snap); updateThumb(); }, snap.bytes);
      updateThumb();
      break;
    }
    case "moveLayer": {

      const i = layerIndex(op.layer);
      if (i < 0) break;
      const end = skipSubtree(i);
      const block = S.layers.slice(i, end);
      const fromDepth = block[0].depth;
      const prevDepths = block.map((b) => b.depth);



      let to = clamp(op.to, 0, S.layers.length);
      if (to > i) to -= (end - i);
      S.layers.splice(i, end - i);
      to = clamp(to, 0, S.layers.length);
      const delta = (op.depth ?? fromDepth) - fromDepth;
      if (delta) for (const b of block) b.depth = Math.max(0, b.depth + delta);
      S.layers.splice(to, 0, ...block);
      S.active = to;
      if (record) pushHistory(op.id, opLabel(op), () => {
        const j = layerIndex(op.layer);
        if (j >= 0) {
          const e2 = skipSubtree(j);
          const blk = S.layers.slice(j, e2);
          S.layers.splice(j, e2 - j);
          blk.forEach((b, k) => { b.depth = prevDepths[k]; });
          let back = clamp(op.from ?? i, 0, S.layers.length);
          S.layers.splice(back, 0, ...blk);
        }
        rebuildLayerList(); touch();
      });
      rebuildLayerList();
      break;
    }
    case "setMask": {
      const lay = layerById(op.layer);
      if (!lay) break;
      if (op.on) {
        attachMask(lay);
        if (record) pushHistory(op.id, opLabel(op), () => {
          lay.mask = null; lay.maskCtx = null; lay.hasMask = false; rebuildLayerList();
        });
      } else {
        const old = lay.mask;
        lay.mask = null; lay.maskCtx = null; lay.hasMask = false;
        if (record) pushHistory(op.id, opLabel(op), () => {
          lay.mask = old;
          lay.maskCtx = old ? old.getContext("2d", { willReadFrequently: true }) : null;
          lay.hasMask = !!old; rebuildLayerList();
        });
      }
      rebuildLayerList();
      break;
    }
    case "setLayer": {
      const lay = layerById(op.layer);
      if (!lay) break;
      const prev = {};
      for (const k of Object.keys(op.props)) prev[k] = lay[k];
      Object.assign(lay, op.props);
      if (record) pushHistory(op.id, opLabel(op), () => {
        Object.assign(lay, op.prev ?? prev); rebuildLayerList(); touch();
      });
      rebuildLayerList();
      break;
    }

    case "groupLayer": {
      const i = layerIndex(op.layer);
      if (i < 0) break;
      const target = S.layers[i];
      const end = skipSubtree(i);
      const d = target.depth;
      const folder = wrapLayer({ id: op.folderId, name: op.name || "フォルダ", visible: true,
                                 opacity: 1, blend: "normal", clip: false,
                                 type: "folder", depth: d, open: true });
      for (let j = i; j < end; j++) S.layers[j].depth++;
      S.layers.splice(i, 0, folder);
      S.active = i;
      if (record) pushHistory(op.id, opLabel(op), () => {
        const fi = layerIndex(op.folderId);
        if (fi >= 0) {
          const fend = skipSubtree(fi);
          for (let j = fi + 1; j < fend; j++) S.layers[j].depth--;
          S.layers.splice(fi, 1);
          S.active = clamp(S.active, 0, S.layers.length - 1);
        }
        rebuildLayerList(); touch();
      });
      rebuildLayerList();
      break;
    }

    case "addFolder": {
      const lay = wrapLayer(op.layer);
      const at = clamp(op.at ?? S.layers.length, 0, S.layers.length);
      S.layers.splice(at, 0, lay);
      S.active = at;
      if (record) pushHistory(op.id, opLabel(op), () => {
        const i = layerIndex(op.layer.id);
        if (i >= 0) {

          for (let j = i + 1; j < S.layers.length && S.layers[j].depth > lay.depth; j++)
            S.layers[j].depth--;
          S.layers.splice(i, 1);
          S.active = clamp(S.active, 0, S.layers.length - 1);
        }
        rebuildLayerList(); touch();
      });
      rebuildLayerList();
      break;
    }
    case "setDepth": {
      const i = layerIndex(op.layer);
      if (i < 0) break;
      const e = S.layers[i];
      const end = skipSubtree(i);
      const delta = op.depth - e.depth;
      const prevDepths = [];
      for (let j = i; j < end; j++) {
        prevDepths.push(S.layers[j].depth);
        S.layers[j].depth = Math.max(0, S.layers[j].depth + delta);
      }
      if (record) pushHistory(op.id, opLabel(op), () => {
        for (let j = i; j < end; j++) S.layers[j].depth = prevDepths[j - i];
        rebuildLayerList(); touch();
      });
      rebuildLayerList();
      break;
    }

    case "addAdjust": {
      const lay = wrapLayer(op.layer);
      const at = clamp(op.at ?? S.layers.length, 0, S.layers.length);
      S.layers.splice(at, 0, lay);
      S.active = at;
      if (record) pushHistory(op.id, opLabel(op), () => {
        const i = layerIndex(op.layer.id);
        if (i >= 0) { S.layers.splice(i, 1); S.active = clamp(S.active, 0, S.layers.length - 1); }
        rebuildLayerList(); touch();
      });
      rebuildLayerList();
      break;
    }
    case "setAdjust": {
      const lay = layerById(op.layer);
      if (!lay || lay.type !== "adjust") break;
      const prev = { filter: lay.filter, params: { ...lay.params } };
      lay.filter = op.filter; lay.params = op.params;
      if (record) pushHistory(op.id, opLabel(op), () => {
        lay.filter = prev.filter; lay.params = prev.params; rebuildLayerList(); touch();
      });
      rebuildLayerList();
      break;
    }
  }
  touch();
  requestRender();
}

function wsAlive() { return S.ws && S.ws.readyState === 1; }
const pendingOps = [];
function sendOp(op) {
  if (wsAlive()) S.ws.send(JSON.stringify({ t: "op", op }));
  else pendingOps.push(op);
}
function localOp(op) {
  applyOp(op, true); sendOp(op); S.dirty++;
  if (op && op.color && op.kind !== "setLayer") noteUsedColor(op.color);
}


let renderQueued = false;
function requestRender() {
  if (renderQueued) return;
  renderQueued = true;


  const popRaf = SOLO.win && !SOLO.win.closed && (inSolo || document.hidden);
  (popRaf ? SOLO.win.requestAnimationFrame.bind(SOLO.win) : requestAnimationFrame)(
    () => { renderQueued = false; render(); });
}
function blendGco(b) { return BLEND_GCO[b] || "source-over"; }
function makeChecker() {
  const c = makeCanvas(16, 16);
  const x = c.getContext("2d");
  x.fillStyle = "#3a3b40"; x.fillRect(0, 0, 16, 16);
  x.fillStyle = "#4a4b52"; x.fillRect(0, 0, 8, 8); x.fillRect(8, 8, 8, 8);
  return vctx.createPattern(c, "repeat");
}

function maskedCanvas(lay) {
  if (!lay.hasMask || !lay.mask) return lay.canvas;
  scratch2Ctx.setTransform(1, 0, 0, 1, 0, 0);
  scratch2Ctx.globalCompositeOperation = "source-over";
  scratch2Ctx.globalAlpha = 1;
  scratch2Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  scratch2Ctx.drawImage(lay.canvas, 0, 0);
  scratch2Ctx.globalCompositeOperation = "destination-in";
  scratch2Ctx.drawImage(lay.mask, 0, 0);
  scratch2Ctx.globalCompositeOperation = "source-over";
  const out = makeCanvas();
  out.getContext("2d").drawImage(scratch2, 0, 0);
  return out;
}
function drawMember(target, lay, mode, alpha, preview) {
  target.globalCompositeOperation = mode;
  target.globalAlpha = alpha;
  const stroking = preview && S.stroke && S.stroke.op.layer === lay.id;
  const moving = preview && S.moving && S.moving.layer === lay.id;
  const xforming = preview && S.xform && S.xform.layer === lay.id;
  const needTemp = lay.hasMask || (stroking && S.stroke.op.tool === "eraser") || xforming ||
                   (stroking && S.stroke.op.target === "mask");
  if (needTemp) {
    scratch3Ctx.setTransform(1, 0, 0, 1, 0, 0);
    scratch3Ctx.globalCompositeOperation = "source-over";
    scratch3Ctx.globalAlpha = 1;
    scratch3Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
    if (xforming) {
      const x = S.xform;
      scratch3Ctx.save();
      scratch3Ctx.drawImage(x.rest, 0, 0);
      const m = xformMatrix(x);
      scratch3Ctx.setTransform(m[0], m[1], m[2], m[3], m[4], m[5]);
      scratch3Ctx.drawImage(x.src, 0, 0);
      scratch3Ctx.restore();
    } else scratch3Ctx.drawImage(lay.canvas, 0, 0);
    if (stroking && S.stroke.op.target !== "mask") {
      scratch3Ctx.globalAlpha = S.stroke.op.opacity;
      scratch3Ctx.globalCompositeOperation =
        S.stroke.op.tool === "eraser" ? "destination-out"
        : (lay.alphaLock ? "source-atop" : "source-over");
      scratch3Ctx.drawImage(liveStrokeImage(), 0, 0);
      scratch3Ctx.globalAlpha = 1;
      scratch3Ctx.globalCompositeOperation = "source-over";
    }
    if (lay.hasMask && lay.mask) {
      scratch3Ctx.globalCompositeOperation = "destination-in";
      if (stroking && S.stroke.op.target === "mask") {

        scratch2Ctx.setTransform(1, 0, 0, 1, 0, 0);
        scratch2Ctx.globalCompositeOperation = "source-over";
        scratch2Ctx.globalAlpha = 1;
        scratch2Ctx.clearRect(0, 0, S.doc.w, S.doc.h);
        scratch2Ctx.drawImage(lay.mask, 0, 0);
        scratch2Ctx.globalAlpha = S.stroke.op.opacity;
        scratch2Ctx.globalCompositeOperation =
          S.stroke.op.tool === "eraser" ? "destination-out" : "source-over";
        scratch2Ctx.drawImage(liveStrokeImage(), 0, 0);
        scratch2Ctx.globalCompositeOperation = "source-over";
        scratch2Ctx.globalAlpha = 1;
        scratch3Ctx.drawImage(scratch2, 0, 0);
      } else scratch3Ctx.drawImage(lay.mask, 0, 0);
      scratch3Ctx.globalCompositeOperation = "source-over";
    }
    target.globalCompositeOperation = mode;
    target.globalAlpha = alpha;
    target.drawImage(scratch3, 0, 0);
  } else if (moving) {
    target.drawImage(lay.canvas, S.moving.dx, S.moving.dy);
  } else {
    const b = knownBB(lay);
    if (b === undefined) target.drawImage(lay.canvas, 0, 0);
    else if (b) target.drawImage(lay.canvas, b[0], b[1], b[2], b[3], b[0], b[1], b[2], b[3]);
  }
  if (stroking && !needTemp && S.stroke.op.tool !== "eraser") {
    target.globalCompositeOperation = lay.alphaLock ? "source-atop"
      : (mode === "source-atop" ? "source-atop" : mode);
    target.globalAlpha = alpha * S.stroke.op.opacity;
    target.drawImage(liveStrokeImage(), 0, 0);
  }
  if (preview) {
    for (const r of S.remote.values()) {
      if (r.op.layer !== lay.id || r.op.tool === "eraser") continue;
      target.globalCompositeOperation = mode === "source-atop" ? "source-atop" : "source-over";
      target.globalAlpha = alpha * r.op.opacity;
      target.drawImage(r.canvas, 0, 0);
    }
  }
}

function applyAdjust(target, e) {

  const R = S.adjRect;
  const x0 = R ? R.x0 : 0, y0 = R ? R.y0 : 0;
  const w = R ? R.x1 - R.x0 : S.doc.w, h = R ? R.y1 - R.y0 : S.doc.h;
  if (w <= 0 || h <= 0) return;
  let img;
  try { img = target.getImageData(x0, y0, w, h); } catch (err) { return; }
  applyFilterData(img.data, w, h, e.filter, e.params || {}, hashSeed(e.id));
  target.putImageData(img, x0, y0);
}





const PER_PIXEL_ADJ = new Set(["hsv", "bc", "levels", "binarize", "gray", "invert", "gradmap", "curve", "lum2alpha"]);
function dirtyLiveCompose(prevAt) {
  const st = S.stroke;
  if (!st || S.noLiveSplit || S.noDirtyAdj || S.remote.size || S.xform || S.moving || S.grad || S.balloon || S.stampDrag || S.dollDrag) return false;
  if (prevAt !== S.composeVersion || S.dirtyFor !== st) return false;
  let any = false;
  for (const e of S.layers) {
    if (e.type !== "adjust" || !e.visible) continue;
    if (!PER_PIXEL_ADJ.has(e.filter)) return false;
    any = true;
  }
  if (!any) return false;
  const f = st.frameBox;
  st.frameBox = null;
  if (!f) return true;
  const R = { x0: clamp(Math.floor(f.x0) - 2, 0, S.doc.w), y0: clamp(Math.floor(f.y0) - 2, 0, S.doc.h),
              x1: clamp(Math.ceil(f.x1) + 2, 0, S.doc.w), y1: clamp(Math.ceil(f.y1) + 2, 0, S.doc.h) };
  if (R.x1 <= R.x0 || R.y1 <= R.y0) return true;
  docCtx.save();
  docCtx.setTransform(1, 0, 0, 1, 0, 0);
  docCtx.beginPath(); docCtx.rect(R.x0, R.y0, R.x1 - R.x0, R.y1 - R.y0); docCtx.clip();
  docCtx.globalCompositeOperation = "source-over"; docCtx.globalAlpha = 1;
  docCtx.clearRect(R.x0, R.y0, R.x1 - R.x0, R.y1 - R.y0);
  S.adjRect = R;
  try { renderDocInto(docCtx, true); }
  finally { S.adjRect = null; docCtx.restore(); }
  return true;
}

function renderOne(idx, depth, preview, level, target, mode, alpha) {
  const e = S.layers[idx];
  if (!e) return idx + 1;
  if (!e.visible) return skipSubtree(idx);
  if (e.type === "adjust") { applyAdjust(target, e); return idx + 1; }
  if (e.type === "folder") {



    const R = (preview && livePreviewActive()) ? undefined : subtreeBox(idx + 1, skipSubtree(idx));
    if (R === null) return skipSubtree(idx);
    const t = R ? tempSmall(level, R) : tempAt(level);
    const next = renderNodes(t.ctx, idx + 1, e.depth + 1, preview, level + 1);
    target.globalCompositeOperation = mode;
    target.globalAlpha = alpha;
    if (R) target.drawImage(t.c, 0, 0, R[2], R[3], R[0], R[1], R[2], R[3]);
    else target.drawImage(t.c, 0, 0);
    target.globalCompositeOperation = "source-over";
    target.globalAlpha = 1;
    return next;
  }
  drawMember(target, e, mode, alpha, preview);
  return idx + 1;
}

function renderNodes(ctx, start, depth, preview, level, end) {
  let i = start;
  const n = S.layers.length;
  const lim = end === undefined ? n : end;
  while (i < lim) {
    const e = S.layers[i];
    if (e.depth < depth) break;
    if (e.depth > depth) { i++; continue; }
    const after = skipSubtree(i);
    const hasClip = after < n && S.layers[after].depth === depth && S.layers[after].clip;
    if (!hasClip) {
      i = renderOne(i, depth, preview, level, ctx, blendGco(e.blend), e.opacity);
      continue;
    }

    const R = (preview && livePreviewActive()) ? undefined : subtreeBox(i, after);
    if (R === null) {
      let j = after;
      while (j < n && S.layers[j].depth === depth && S.layers[j].clip) j = skipSubtree(j);
      i = j;
      continue;
    }
    const t = R ? tempSmall(level, R) : tempAt(level);
    let j = renderOne(i, depth, preview, level + 1, t.ctx, "source-over", 1);
    while (j < n && S.layers[j].depth === depth && S.layers[j].clip) {
      const cl = S.layers[j];
      const m = cl.blend === "normal" ? "source-atop" : blendGco(cl.blend);
      j = renderOne(j, depth, preview, level + 1, t.ctx,
                    m === "source-over" ? "source-atop" : m, cl.opacity);
    }
    ctx.globalCompositeOperation = blendGco(e.blend);
    ctx.globalAlpha = e.opacity;
    if (R) ctx.drawImage(t.c, 0, 0, R[2], R[3], R[0], R[1], R[2], R[3]);
    else ctx.drawImage(t.c, 0, 0);
    i = j;
  }
  ctx.globalCompositeOperation = "source-over";
  ctx.globalAlpha = 1;
  return i;
}
function renderDocInto(ctx, preview) { renderNodes(ctx, 0, 0, preview, 0); }
function compositeInto(ctx) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalCompositeOperation = "source-over";
  ctx.globalAlpha = 1;
  ctx.clearRect(0, 0, S.doc.w, S.doc.h);
  renderDocInto(ctx, false);
}


function livePreviewActive() {
  return !!(S.stroke || S.remote.size || S.xform || S.moving || S.grad ||
            S.balloon || S.stampDrag || S.dollDrag);
}





const liveSplit = { ver: -1, key: "", below: null, above: null };
function topGroups() {
  const g = [], n = S.layers.length;
  let i = 0;
  while (i < n) {
    if (S.layers[i].depth !== 0) { i++; continue; }
    let j = skipSubtree(i);
    while (j < n && S.layers[j].depth === 0 && S.layers[j].clip) j = skipSubtree(j);
    g.push([i, j]);
    i = j;
  }
  return g;
}
function fastLiveCompose(settleId) {
  if (S.noLiveSplit || S.remote.size || S.grad || S.balloon || S.stampDrag || S.dollDrag) return false;

  const ids = settleId ? [settleId]
    : [S.stroke && S.stroke.op.layer, S.xform && S.xform.layer, S.moving && S.moving.layer].filter(Boolean);
  if (ids.length !== 1) return false;
  if (settleId && liveSplit.ver !== S.composeVersion) return false;
  const idx = layerIndex(ids[0]);
  if (idx < 0) return false;
  const groups = topGroups();
  const gi = groups.findIndex(([a, b]) => idx >= a && idx < b);
  if (gi < 0) return false;
  const [a, b] = groups[gi];
  if (S.layers[a].type === "adjust") return false;
  for (let k = gi + 1; k < groups.length; k++) {
    const e = S.layers[groups[k][0]];
    if (e.visible && (e.type === "adjust" || blendGco(e.blend) !== "source-over")) return false;
  }
  const key = a + ":" + b + ":" + S.layers.length + ":" + S.doc.w + "x" + S.doc.h;
  if (liveSplit.ver !== S.composeVersion || liveSplit.key !== key) {
    for (const k of ["below", "above"]) {
      if (!liveSplit[k]) liveSplit[k] = makeCanvas();
      const c = liveSplit[k];
      if (c.width !== S.doc.w || c.height !== S.doc.h) { c.width = S.doc.w; c.height = S.doc.h; }
      const x = c.getContext("2d");
      x.setTransform(1, 0, 0, 1, 0, 0);
      x.globalCompositeOperation = "source-over"; x.globalAlpha = 1;
      x.clearRect(0, 0, S.doc.w, S.doc.h);
      if (k === "below") renderNodes(x, 0, 0, false, 0, a);
      else renderNodes(x, b, 0, false, 0);
    }
    liveSplit.ver = S.composeVersion; liveSplit.key = key;
  }
  docCtx.drawImage(liveSplit.below, 0, 0);
  renderNodes(docCtx, a, 0, true, 0, b);
  docCtx.globalCompositeOperation = "source-over"; docCtx.globalAlpha = 1;
  docCtx.drawImage(liveSplit.above, 0, 0);
  liveSplit.layer = ids[0];
  return true;
}
function ensureComposite() {
  if (!docC) return;


  const spreadOnly = !!(S.stroke && S.stroke.op.spread) && !S.remote.size && !S.xform && !S.moving &&
                     !S.grad && !S.balloon && !S.stampDrag && !S.dollDrag;
  if (S.composedAt === S.composeVersion && (!livePreviewActive() || spreadOnly) && !S.forceCompose) return;
  const prevAt = S.composedAt;
  S.forceCompose = livePreviewActive() && !spreadOnly;
  S.composedAt = S.composeVersion;
  if (S.forceCompose && !S.liveFast && dirtyLiveCompose(prevAt)) return;

  S.dirtyFor = S.forceCompose ? S.stroke : null;
  if (S.stroke) S.stroke.frameBox = null;
  docCtx.setTransform(1, 0, 0, 1, 0, 0);
  docCtx.globalCompositeOperation = "source-over";
  docCtx.globalAlpha = 1;
  docCtx.clearRect(0, 0, S.doc.w, S.doc.h);
  if (S.forceCompose) {
    if (fastLiveCompose()) { S.liveFast = true; return; }
    S.liveFast = false;
  } else if (S.liveFast) {


    S.liveFast = false;
    if (fastLiveCompose(liveSplit.layer)) return;
  }
  renderDocInto(docCtx, true);
}

function render() {
  renderSurface(null);
  const lay = soloSync();
  if (lay) withSolo(() => renderSurface(lay));
}

function renderSurface(solo) {
  const w = view.width, h = view.height;
  vctx.setTransform(1, 0, 0, 1, 0, 0);
  vctx.clearRect(0, 0, w, h);
  const m = viewMatOf(S.view);
  vctx.setTransform(dpr * m.a, dpr * m.b, dpr * m.c, dpr * m.d, dpr * m.e, dpr * m.f);
  vctx.imageSmoothingEnabled = S.view.scale < 3;
  if (!checker) checker = makeChecker();
  vctx.fillStyle = checker;
  vctx.fillRect(0, 0, S.doc.w, S.doc.h);
  if (solo) {


    const st = S.stroke && S.stroke.op.layer === solo.id ? S.stroke : null;
    const simple = !S.noLiveSplit && !solo.hasMask && !S.remote.size &&
      !(S.xform && S.xform.layer === solo.id) && !(S.moving && S.moving.layer === solo.id) &&
      (!st || (st.op.tool === "brush" && st.op.target !== "mask" && !solo.alphaLock));
    if (simple) {
      vctx.drawImage(solo.canvas, 0, 0);
      if (st) {
        vctx.globalAlpha = st.op.opacity;
        vctx.drawImage(liveStrokeImage(), 0, 0);
        vctx.globalAlpha = 1;
      }
    } else vctx.drawImage(soloComposite(solo), 0, 0);
  } else {
    ensureComposite();
    if (docC && S.stroke && S.stroke.op.spread) {


      if (!spreadPrevC) spreadPrevC = makeCanvas();
      const pc = spreadPrevC;
      if (pc.width !== S.doc.w || pc.height !== S.doc.h) { pc.width = S.doc.w; pc.height = S.doc.h; }
      const px = pc.getContext("2d");
      px.setTransform(1, 0, 0, 1, 0, 0);
      px.globalCompositeOperation = "copy"; px.globalAlpha = 1;
      px.drawImage(docC, 0, 0);
      px.globalCompositeOperation = S.stroke.op.tool === "eraser" ? "destination-out" : "source-atop";
      px.globalAlpha = S.stroke.op.opacity;
      px.drawImage(liveStrokeImage(), 0, 0);
      px.globalCompositeOperation = "source-over"; px.globalAlpha = 1;
      vctx.drawImage(pc, 0, 0);
    } else if (docC) vctx.drawImage(docC, 0, 0);
  }

  if (S.encloseDraft && S.encloseDraft.pts.length > 1) {
    vctx.save();
    vctx.beginPath();
    const p = S.encloseDraft.pts;
    vctx.moveTo(p[0][0], p[0][1]);
    for (let i = 1; i < p.length; i++) vctx.lineTo(p[i][0], p[i][1]);
    vctx.closePath();
    vctx.fillStyle = S.color + "44";
    vctx.fill();
    vctx.strokeStyle = S.color;
    vctx.lineWidth = 2 / S.view.scale;
    vctx.stroke();
    vctx.restore();
  }

  {
    const lay = S.layers[S.active];
    if (S.tool === "doll" && isDoll(lay) && lay.doll) {
      const rr = Math.max(4, lay.doll.h * 0.022);
      vctx.save();
      for (const [k, q] of Object.entries(lay.doll.pose)) {
        vctx.beginPath();
        vctx.arc(q[0], q[1], rr, 0, 7);
        vctx.fillStyle = (S.dollDrag && S.dollDrag.joint === k) ? "#ffd24a" : "#ffffff";
        vctx.fill();
        vctx.lineWidth = 1.5 / S.view.scale;
        vctx.strokeStyle = "#1b6fd8";
        vctx.stroke();
      }
      vctx.restore();
    }
  }

  if (S.stampDrag) {
    const s = S.stampDrag;
    vctx.save();
    vctx.globalAlpha = 0.75;
    drawMaterial(vctx, { mat: S.material, x: s.x, y: s.y,
                         r: s.r > 6 ? s.r : S.matSize, angle: s.r > 6 ? s.angle : 0,
                         color: S.color, sub: S.sub, id: s.opId });
    vctx.restore();
  }

  if (S.balloon) {
    vctx.save();
    balloonPath(vctx, { ...S.balloon, lw: Math.max(2, S.size / 4) });
    vctx.fillStyle = S.sub; vctx.globalAlpha = 0.65; vctx.fill();
    vctx.globalAlpha = 1;
    vctx.strokeStyle = S.color; vctx.lineWidth = Math.max(2, S.size / 4);
    vctx.lineJoin = "round"; vctx.stroke();
    vctx.restore();
  }

  if (S.grad) {
    vctx.save();
    vctx.strokeStyle = "#fff"; vctx.lineWidth = 1.5 / S.view.scale;
    vctx.setLineDash([8 / S.view.scale, 6 / S.view.scale]);
    vctx.beginPath(); vctx.moveTo(S.grad.x0, S.grad.y0); vctx.lineTo(S.grad.x1, S.grad.y1);
    vctx.stroke(); vctx.restore();
  }
  for (const sel of [S.sel, S.selDraft]) {
    if (!sel) continue;
    vctx.save();
    selPath(vctx, sel);
    vctx.lineWidth = 1.6 / S.view.scale;
    vctx.setLineDash([6 / S.view.scale, 5 / S.view.scale]);
    vctx.strokeStyle = "#fff"; vctx.stroke();
    vctx.strokeStyle = "#111"; vctx.lineDashOffset = 6 / S.view.scale; vctx.stroke();
    vctx.restore();
  }

  if (S.persp.on) {
    const vps = activeVPs();
    const R = Math.hypot(S.doc.w, S.doc.h) * 1.6;
    vctx.save();
    vctx.lineWidth = 1 / S.view.scale;
    const cols = ["rgba(90,170,255,.5)", "rgba(255,150,90,.5)", "rgba(150,255,150,.5)"];
    vps.forEach((v, k) => {
      vctx.strokeStyle = cols[k];
      vctx.beginPath();
      for (let i = 0; i < 24; i++) {
        const a = i * Math.PI / 12;
        vctx.moveTo(v[0], v[1]);
        vctx.lineTo(v[0] + Math.cos(a) * R, v[1] + Math.sin(a) * R);
      }
      vctx.stroke();

      vctx.fillStyle = cols[k].replace(".5", ".95");
      vctx.beginPath(); vctx.arc(v[0], v[1], 10 / S.view.scale, 0, 7); vctx.fill();
      vctx.strokeStyle = "#fff";
      vctx.beginPath(); vctx.arc(v[0], v[1], 10 / S.view.scale, 0, 7); vctx.stroke();
    });
    vctx.restore();
  }

  if (S.sym !== "none" && ["brush", "eraser"].includes(S.tool)) {
    vctx.save();
    vctx.strokeStyle = "rgba(120,180,255,.55)";
    vctx.lineWidth = 1 / S.view.scale;
    vctx.beginPath();
    if (S.sym === "v" || S.sym === "vh") { vctx.moveTo(S.doc.w / 2, 0); vctx.lineTo(S.doc.w / 2, S.doc.h); }
    if (S.sym === "h" || S.sym === "vh") { vctx.moveTo(0, S.doc.h / 2); vctx.lineTo(S.doc.w, S.doc.h / 2); }
    if (S.sym.startsWith("r")) {
      const n = +S.sym.slice(1), R = Math.hypot(S.doc.w, S.doc.h) / 2;
      for (let i = 0; i < n; i++) {
        const a = i * 2 * Math.PI / n;
        vctx.moveTo(S.doc.w / 2, S.doc.h / 2);
        vctx.lineTo(S.doc.w / 2 + R * Math.cos(a), S.doc.h / 2 + R * Math.sin(a));
      }
    }
    vctx.stroke();
    vctx.restore();
  }
  vctx.lineWidth = 1 / S.view.scale;
  vctx.strokeStyle = "#666";
  vctx.strokeRect(0, 0, S.doc.w, S.doc.h);

  if (S.tool === "vecedit" && S.vecSel) {
    const lay = layerById(S.vecSel.layer);
    const s = lay && lay.strokes && lay.strokes.find((k) => k.id === S.vecSel.stroke);
    if (s) {
      vctx.save();
      vctx.strokeStyle = "#4a90d9";
      vctx.lineWidth = 2 / S.view.scale;
      vctx.setLineDash([]);
      vctx.beginPath();
      vctx.moveTo(s.pts[0][0], s.pts[0][1]);
      for (let i = 1; i < s.pts.length; i++) vctx.lineTo(s.pts[i][0], s.pts[i][1]);
      vctx.stroke();
      const r = 6 / S.view.scale;
      for (const hi of vecHandles(s)) {
        vctx.beginPath();
        vctx.arc(s.pts[hi][0], s.pts[hi][1], r, 0, 7);
        vctx.fillStyle = "#fff"; vctx.fill();
        vctx.strokeStyle = "#4a90d9"; vctx.stroke();
      }
      vctx.restore();
    }
  }

  if (S.xform) drawXformHandles();
  vctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  if (S.hover && !!S.hoverSolo === inSolo &&
      ["brush", "eraser", "blur", "smudge", "gapfill"].includes(S.tool) && !S.stroke) {
    const r = S.size * S.view.scale / 2;
    if (r > 2.5) {
      vctx.beginPath(); vctx.arc(S.hover[0], S.hover[1], r, 0, 7);
      vctx.lineWidth = 1.2; vctx.strokeStyle = "rgba(255,255,255,.9)"; vctx.stroke();
      vctx.beginPath(); vctx.arc(S.hover[0], S.hover[1], r + 1.2, 0, 7);
      vctx.strokeStyle = "rgba(0,0,0,.6)"; vctx.stroke();
    }
  }
  if (solo) return;
  const zl = $("zoomVal");
  if (zl) zl.textContent = Math.round(S.view.scale * 100) + "%";
}

function fitView() {
  resize();
  const r = view.getBoundingClientRect();
  const sc = Math.min(r.width / S.doc.w, r.height / S.doc.h) * 0.95;
  S.view.scale = sc; S.view.rot = 0; S.view.flip = false;
  S.view.x = (r.width - S.doc.w * sc) / 2;
  S.view.y = (r.height - S.doc.h * sc) / 2;
  requestRender();
  updateViewPanel();
}
function resize() {
  const r = view.getBoundingClientRect();
  dpr = window.devicePixelRatio || 1;
  view.width = Math.round(r.width * dpr);
  view.height = Math.round(r.height * dpr);
  requestRender();
}
window.addEventListener("resize", resize);
function toDoc(cx, cy) {
  const r = view.getBoundingClientRect();
  return screenToDoc(cx - r.left, cy - r.top);
}


function xformMatrix(x) {
  const c = Math.cos(x.rot), s = Math.sin(x.rot);
  const a = x.sx * c, b = x.sx * s, cc = -x.sy * s, d = x.sy * c;

  const e = x.cx + x.dx - (a * x.cx + cc * x.cy);
  const f = x.cy + x.dy - (b * x.cx + d * x.cy);
  return [a, b, cc, d, e, f];
}
function beginTransform() {
  const lay = activeRaster();
  if (!lay) { toast("絵のレイヤーを選んでください"); return; }
  const target = activeTarget();
  const ctx = targetCtxOf(lay, target);
  if (!ctx) {
    toast("テキストレイヤーは変形できません。サイズは🅣で、位置は↔️移動で変えられます");
    return;
  }
  const box = S.sel ? selBBox(S.sel) : contentBBox(ctx);
  if (!box) { toast("変形するものがありません"); return; }
  const src = makeCanvas(), sctx = src.getContext("2d");
  sctx.save(); clipSel(sctx, S.sel); sctx.drawImage(ctx.canvas, 0, 0); sctx.restore();
  const rest = makeCanvas(), rctx = rest.getContext("2d");
  rctx.drawImage(ctx.canvas, 0, 0);
  if (S.sel) { rctx.save(); clipSel(rctx, S.sel); rctx.clearRect(0, 0, S.doc.w, S.doc.h); rctx.restore(); }
  else rctx.clearRect(0, 0, S.doc.w, S.doc.h);
  S.xform = { layer: lay.id, target, src, rest, box, sel: S.sel,
              cx: (box.x0 + box.x1) / 2, cy: (box.y0 + box.y1) / 2,
              dx: 0, dy: 0, sx: 1, sy: 1, rot: 0, mode: null };
  $("xformBar").classList.remove("hidden");
  requestRender();
}
function contentBBox(ctx) {
  const d = ctx.getImageData(0, 0, S.doc.w, S.doc.h).data;
  let x0 = S.doc.w, y0 = S.doc.h, x1 = 0, y1 = 0, any = false;
  for (let y = 0; y < S.doc.h; y++) {
    for (let x = 0; x < S.doc.w; x++) {
      if (d[(y * S.doc.w + x) * 4 + 3] < 4) continue;
      any = true;
      if (x < x0) x0 = x; if (x > x1) x1 = x;
      if (y < y0) y0 = y; if (y > y1) y1 = y;
    }
  }
  return any ? { x0, y0, x1: x1 + 1, y1: y1 + 1 } : null;
}
function xformCorners() {
  const x = S.xform, m = xformMatrix(x);
  const pt = (px, py) => [m[0] * px + m[2] * py + m[4], m[1] * px + m[3] * py + m[5]];
  return [pt(x.box.x0, x.box.y0), pt(x.box.x1, x.box.y0),
          pt(x.box.x1, x.box.y1), pt(x.box.x0, x.box.y1)];
}
function drawXformHandles() {
  const c = xformCorners();
  vctx.save();
  vctx.strokeStyle = "#4a90d9"; vctx.lineWidth = 1.5 / S.view.scale;
  vctx.setLineDash([]);
  vctx.beginPath();
  vctx.moveTo(c[0][0], c[0][1]);
  for (let i = 1; i < 4; i++) vctx.lineTo(c[i][0], c[i][1]);
  vctx.closePath(); vctx.stroke();
  const r = 6 / S.view.scale;
  vctx.fillStyle = "#fff";
  for (const p of c) {
    vctx.beginPath(); vctx.arc(p[0], p[1], r, 0, 7); vctx.fill(); vctx.stroke();
  }

  const mid = [(c[0][0] + c[1][0]) / 2, (c[0][1] + c[1][1]) / 2];
  const dx = c[0][1] - c[1][1], dy = c[1][0] - c[0][0];
  const len = Math.hypot(dx, dy) || 1;
  const rp = [mid[0] + dx / len * 34 / S.view.scale, mid[1] + dy / len * 34 / S.view.scale];
  vctx.beginPath(); vctx.moveTo(mid[0], mid[1]); vctx.lineTo(rp[0], rp[1]); vctx.stroke();
  vctx.beginPath(); vctx.arc(rp[0], rp[1], r, 0, 7); vctx.fillStyle = "#7ed321"; vctx.fill(); vctx.stroke();
  vctx.restore();
}
function xformHandleAt(dx, dy) {
  const c = xformCorners();
  const tol = 14 / S.view.scale;
  for (let i = 0; i < 4; i++)
    if (Math.hypot(c[i][0] - dx, c[i][1] - dy) < tol) return { type: "scale", i };
  const mid = [(c[0][0] + c[1][0]) / 2, (c[0][1] + c[1][1]) / 2];
  const nx = c[0][1] - c[1][1], ny = c[1][0] - c[0][0];
  const len = Math.hypot(nx, ny) || 1;
  const rp = [mid[0] + nx / len * 34 / S.view.scale, mid[1] + ny / len * 34 / S.view.scale];
  if (Math.hypot(rp[0] - dx, rp[1] - dy) < tol) return { type: "rotate" };
  return { type: "move" };
}
function commitTransform(apply) {
  const x = S.xform;
  if (!x) return;
  S.xform = null;
  $("xformBar").classList.add("hidden");
  if (apply && (x.dx || x.dy || x.sx !== 1 || x.sy !== 1 || x.rot))
    localOp({ id: uid(), kind: "transform", layer: x.layer, target: x.target,
              sel: x.sel || undefined, m: xformMatrix(x) });
  requestRender();
}


const pointers = new Map();
let pan = null, pinch = null;
let liveBuf = [], liveTimer = null;
let gesture = null, holdTimer = null;


function spreadNow() {
  return !!S.spread && !inSolo && ["brush", "eraser"].includes(S.tool) && !S.maskEdit;
}
function currentStrokeOp() {
  const spread = spreadNow();
  const tool = ["eraser", "blur", "smudge", "gapfill"].includes(S.tool) ? S.tool : "brush";

  const clipAll = !!S.clipAll && !spread && (tool === "brush" || tool === "eraser") && activeTarget() !== "mask";
  return { id: uid(), kind: "stroke", layer: spread ? undefined : S.layers[S.active]?.id,
           spread: spread || undefined, clipAll: clipAll || undefined,
           target: spread ? "layer" : activeTarget(),
           tool,
           ref: S.fillRef,
           color: S.color, size: S.size, opacity: S.opacity, hard: S.hard,
           pSize: S.pSize, pOp: S.pOp, pcSize: S.pcSize, pcOp: S.pcOp,
           spacing: S.spacing, scatter: S.scatter,
           brushShape: S.brushShape, mix: S.mix,
           aspect: S.aspect, angle: S.angle, follow: S.follow, grain: S.grain,
           jSize: S.jSize, jAngle: S.jAngle, jOpacity: S.jOpacity, tilt: S.tilt,
           taperIn: S.taperIn, taperOut: S.taperOut, post: S.post,
           taperUnit: S.taperUnit === "px" ? "px" : undefined,
           taperTip: S.taperTip !== 8 && S.taperTip != null ? S.taperTip : undefined,
           taperShape: S.taperShape || undefined, taperOp: S.taperOp || undefined,
           wash: S.wash || undefined, flow: S.wash ? S.flow : undefined,
           pMinSize: S.pMinSize !== 15 ? S.pMinSize : undefined, pMinOp: S.pMinOp || undefined,
           speedSize: S.speedSize || undefined, speedOp: S.speedOp || undefined,

           dsp: S.dynSpacing !== false && (tool === "brush" || tool === "eraser") ? 1 : undefined,
           sym: S.sym === "none" ? undefined : S.sym,
           sel: S.sel || undefined, pts: [] };
}



function tiltOf(e) {
  if (e.pointerType !== "pen") return 0;
  const tx = e.tiltX || 0, ty = e.tiltY || 0;
  if (!tx && !ty) return 0;
  const a = Math.min(90, Math.hypot(tx, ty));
  return clamp(a / 70, 0, 1);
}
function normPressure(e) {
  if (e.pointerType === "pen") return clamp(e.pressure || 0.5, 0.03, 1);
  return clamp(e.pressure > 0 && e.pressure !== 1 ? e.pressure : 0.5, 0.03, 1);
}

function activeVPs() {
  const n = S.persp.mode === "1" ? 1 : S.persp.mode === "2" ? 2 : 3;
  return S.persp.vps.slice(0, n);
}
function perspSnap(st, x, y) {
  const vps = activeVPs();
  if (!vps.length || !st.origin) return [x, y];
  const [ox, oy] = st.origin;
  if (!st.vpLocked) {




    const dx = x - ox, dy = y - oy;
    const dlen = Math.hypot(dx, dy);
    if (dlen < 8) return [x, y];
    let best = null, bestCos = -1;
    for (const v of vps) {
      const vx = v[0] - ox, vy = v[1] - oy;
      const len = Math.hypot(vx, vy) || 1;

      const cos = Math.abs((dx * vx + dy * vy) / (dlen * len));
      if (cos > bestCos) { bestCos = cos; best = v; }
    }

    if (S.persp.mode !== "3" && Math.abs(dy) / dlen > bestCos) best = "vert";
    st.vp = best;
    if (dlen >= 60) st.vpLocked = true;
  }
  if (st.vp === "vert") return [ox, y];
  const vx = st.vp[0] - ox, vy = st.vp[1] - oy;
  const vlen = Math.hypot(vx, vy) || 1;
  const ux = vx / vlen, uy = vy / vlen;
  const t = (x - ox) * ux + (y - oy) * uy;
  return [ox + ux * t, oy + uy * t];
}
function applyRuler(st, x, y) {
  if (S.persp.on) return perspSnap(st, x, y);
  const r = S.ruler;
  if (r === "none" || !st.origin) return [x, y];
  const [ox, oy] = st.origin;
  if (r === "h") return [x, oy];
  if (r === "v") return [ox, y];
  if (r === "line") {
    if (!st.dir) {
      const d = Math.hypot(x - ox, y - oy);
      if (d < 6) return [x, y];
      st.dir = [(x - ox) / d, (y - oy) / d];
    }
    const t = (x - ox) * st.dir[0] + (y - oy) * st.dir[1];
    return [ox + st.dir[0] * t, oy + st.dir[1] * t];
  }
  const cx = S.doc.w / 2, cy = S.doc.h / 2;
  if (r === "radial") {
    const a = Math.atan2(oy - cy, ox - cx);
    const t = (x - cx) * Math.cos(a) + (y - cy) * Math.sin(a);
    return [cx + Math.cos(a) * t, cy + Math.sin(a) * t];
  }
  if (r === "circle") {
    const R = Math.hypot(ox - cx, oy - cy);
    const a = Math.atan2(y - cy, x - cx);
    return [cx + Math.cos(a) * R, cy + Math.sin(a) * R];
  }
  return [x, y];
}
function startStroke(e) {
  const lay = S.layers[S.active];
  if (!spreadNow()) {
    if (!lay) return;
    if (!lay.visible) { toast("非表示レイヤーには描けません"); return; }
  }
  const op = currentStrokeOp();
  op.curve = 1;
  S.stroke = beginLocalStroke(op);
  S.stroke.pointerId = e.pointerId;
  S.stroke.origin = toDoc(e.clientX, e.clientY);
  S.stroke.vp = null;
  S.stroke.vpLocked = false;
  sendLive({ t: "live", ph: "b", op: { ...op, pts: undefined } });
  addStrokePoint(e);
  if (holdTimer) clearTimeout(holdTimer);
  const heldInSolo = inSolo;
  holdTimer = setTimeout(() => {
    const st = S.stroke;
    if (st && st.op.pts.length && st.bbox &&
        (st.bbox.x1 - st.bbox.x0) < S.size + 8 && (st.bbox.y1 - st.bbox.y0) < S.size + 8) {
      endStroke(true);
      if (heldInSolo) withSolo(() => pickColor(e.clientX, e.clientY));
      else pickColor(e.clientX, e.clientY);
      toast("スポイト: " + S.color);
    }
  }, 650);
}
function addStrokePoint(e) {
  const st = S.stroke;
  if (!st) return;
  const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
  const pts = [];



  const a60 = 1 / (1 + S.stab * 0.9);
  for (const ev of (evs.length ? evs : [e])) {
    let [x, y] = toDoc(ev.clientX, ev.clientY);
    let p = normPressure(ev);
    const now = ev.timeStamp || performance.now();
    const dt = st.lastT === undefined ? 16.67 : clamp(now - st.lastT, 0.5, 100);
    st.lastT = now;

    if (st.raw) {
      const k = 1 - Math.exp(-dt / 25), d4 = Math.max(4, dt);
      st.fvx = (st.fvx || 0) + ((x - st.raw[0]) / d4 - (st.fvx || 0)) * k;
      st.fvy = (st.fvy || 0) + ((y - st.raw[1]) / d4 - (st.fvy || 0)) * k;
    }
    st.raw = [x, y];
    st.rawT = now;

    if (S.pSmooth > 0) {
      if (st.pSm !== undefined) p = st.pSm + (p - st.pSm) * (1 - Math.exp(-dt / (S.pSmooth * 0.6)));
      st.pSm = p;
    }

    const sxy = [ev.clientX, ev.clientY];
    if (st.lastScr) {


      const v = Math.hypot(sxy[0] - st.lastScr[0], sxy[1] - st.lastScr[1]) / Math.max(4, dt);
      st.vSm = (st.vSm || 0) + (v - (st.vSm || 0)) * (1 - Math.exp(-dt / 40));
    }
    st.lastScr = sxy;
    if (st.smooth && S.stab > 0) {

      const a = S.stabSpeed ? 1 / (1 + S.stab * 0.9 * (0.4 + 1.2 * clamp((st.vSm || 0) / 2, 0, 1))) : a60;
      const alpha = 1 - Math.pow(1 - a, dt / 16.67);
      x = st.smooth[0] + (x - st.smooth[0]) * alpha;
      y = st.smooth[1] + (y - st.smooth[1]) * alpha;
    }
    st.smooth = [x, y];
    [x, y] = applyRuler(st, x, y);
    const tl = tiltOf(ev);

    const q = [Math.round(x * 100) / 100, Math.round(y * 100) / 100,
               Math.round(p * 1000) / 1000];
    if (st.op.speedSize || st.op.speedOp) {
      q.push(Math.round(tl * 100) / 100, Math.round(clamp((st.vSm || 0) / 2, 0, 1) * 100) / 100);
    } else if (tl > 0) q.push(Math.round(tl * 100) / 100);
    pts.push(q);
  }
  st.op.pts.push(...pts);
  strokeAddPoints(st, pts);
  liveBuf.push(...pts);
  if (!liveTimer) liveTimer = setTimeout(flushLive, 40);
  requestRender();
}
function flushLive() {
  liveTimer = null;
  if (S.stroke && liveBuf.length)
    sendLive({ t: "live", ph: "p", id: S.stroke.op.id, pts: liveBuf.splice(0) });
}
function endStroke(cancel) {
  const st = S.stroke;
  if (!st) return;
  if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
  if (!cancel) { strokeCatchUp(st); strokeFlick(st); }
  flushLive();
  S.stroke = null;
  liveBuf.length = 0;
  if (cancel || st.op.pts.length === 0) {
    sendLive({ t: "live", ph: "c", id: st.op.id });
    clearStrokeCanvas(st);
    requestRender();
    return;
  }
  sendLive({ t: "live", ph: "e", id: st.op.id });

  const needRedraw = (st.op.post > 0) || st.op.taperIn > 0 || st.op.taperOut > 0;
  if (needRedraw && !S.shape) {
    if (st.op.post > 0) st.op.pts = smoothPts(st.op.pts, st.op.post);
    clearStrokeCanvas(st);
    st.dist = 0; st.mixColor = st.op.color;
    st.total = ptsLength(st.op.pts);
    strokeAddPoints(st, st.op.pts, true);
  } else strokeAddPoints(st, [], true);



  const vl = layerById(st.op.layer);
  if (isVector(vl) && st.op.target !== "mask" && !st.op.spread && st.op.tool === "brush") {
    clearStrokeCanvas(st);
    applyStrokeOp(st.op, true);
  } else finalizeStroke(st, true);
  sendOp(st.op);
  if (st.op.tool === "brush") noteUsedColor(st.op.color);
}


function strokeCatchUp(st) {
  if (S.shape || !(S.stab > 0) || !st.raw || !st.smooth || !st.op.pts.length) return;
  const [sx, sy] = st.smooth;
  let [rx, ry] = applyRuler(st, st.raw[0], st.raw[1]);
  const d = Math.hypot(rx - sx, ry - sy);
  if (d < 0.5) return;
  const last = st.op.pts[st.op.pts.length - 1];
  const n = Math.min(64, Math.ceil(d / 2));
  const pts = [];
  for (let k = 1; k <= n; k++) {
    const t = k / n;
    const q = [Math.round((sx + (rx - sx) * t) * 100) / 100, Math.round((sy + (ry - sy) * t) * 100) / 100, last[2]];
    if (last.length > 3) q.push(...last.slice(3));
    pts.push(q);
  }
  st.smooth = [rx, ry];
  st.op.pts.push(...pts);
  strokeAddPoints(st, pts);
  liveBuf.push(...pts);
}





function strokeFlick(st) {
  const f = S.flick || 0;
  if (!(f > 0) || S.shape || S.persp.on || S.ruler !== "none" || st.op.tool !== "brush") return;
  if (!st.op.pSize && !(st.op.taperOut > 0)) return;
  if (!st.raw || st.rawT === undefined || st.op.pts.length < 3) return;
  if (performance.now() - st.rawT > 50) return;
  const vx = st.fvx || 0, vy = st.fvy || 0;
  const m = viewMatOf(S.view), zoom = Math.sqrt(Math.abs(m.a * m.d - m.b * m.c)) || 1;
  const v = Math.hypot(vx, vy) * zoom;
  if (v < 0.6) return;
  const vd = Math.hypot(vx, vy);

  const cap = Math.min(400, (st.op.size || 4) * 16);
  const L = cap * (1 - Math.exp(-vd * 60 / cap)) * (f / 100);
  if (L < 2) return;
  const ux = vx / vd, uy = vy / vd;
  const last = st.op.pts[st.op.pts.length - 1];
  const p0 = last[2], n = Math.min(64, Math.max(3, Math.ceil(L / 2)));
  const pts = [];
  for (let k = 1; k <= n; k++) {
    const t = k / n, e = t * (2 - t);
    const q = [Math.round((last[0] + ux * L * e) * 100) / 100, Math.round((last[1] + uy * L * e) * 100) / 100,
               Math.round(p0 * (1 - t) * 1000) / 1000];
    if (last.length > 3) q.push(...last.slice(3));
    pts.push(q);
  }
  st.op.pts.push(...pts);
  strokeAddPoints(st, pts);
  liveBuf.push(...pts);
}
function sendLive(m) { if (wsAlive()) S.ws.send(JSON.stringify(m)); }

function pickColor(cx, cy) {
  const [x, y] = toDoc(cx, cy).map(Math.round);
  if (x < 0 || y < 0 || x >= S.doc.w || y >= S.doc.h) return;
  compositeInto(scratchCtx);
  const d = scratchCtx.getImageData(x, y, 1, 1).data;
  if (d[3] > 8) { setColor(rgbHex(d[0], d[1], d[2])); saveRecent(); }
}
function magicWand(cx, cy) {
  const [dx, dy] = toDoc(cx, cy).map(Math.round);
  if (dx < 0 || dy < 0 || dx >= S.doc.w || dy >= S.doc.h) return;
  const lay = activeRaster();
  if (!lay && S.fillRef === "layer") { toast("絵のレイヤーを選んでください"); return; }
  const mask = floodMask(lay ? lay.ctx : null, dx, dy, S.fillTol, S.fillGrow,
                         S.gapClose, S.fillRef);
  const polys = FX.maskToPolys(mask, S.doc.w, S.doc.h, 1.2);
  if (!polys.length) { toast("選択できる領域がありません"); return; }
  setSel(combineSel(S.sel, { type: "polys", polys }, S.selModeUI || "new"));
  toast(`自動選択: ${polys.length}輪郭`);
}

onView("pointerdown", (e) => {
  e.preventDefault();
  try { view.setPointerCapture(e.pointerId); } catch (err) {}
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, type: e.pointerType });
  const touches = [...pointers.values()].filter((p) => p.type === "touch");
  if (e.pointerType === "touch") {
    if (!gesture || pointers.size === 1) gesture = { t0: performance.now(), maxTouches: 0, moved: 0 };
    gesture.maxTouches = Math.max(gesture.maxTouches, touches.length);
  }
  if (e.pointerType === "touch" && touches.length === 2) {
    if (S.stroke) endStroke(true);
    S.selDraft = null; S.shape = null; S.grad = null; S.balloon = null;
    S.stampDrag = null;
    S.encloseDraft = null;
    pan = null;
    const [a, b] = touches;
    pinch = { d: Math.hypot(a.x - b.x, a.y - b.y),
              ang: Math.atan2(b.y - a.y, b.x - a.x),
              cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, view: { ...S.view } };
    const r = view.getBoundingClientRect();
    pinch.docMid = screenToDoc(pinch.cx - r.left, pinch.cy - r.top, pinch.view);
    return;
  }
  if (pointers.size > 1) return;


  let mRole = "tool";
  if (e.pointerType === "mouse" || (e.pointerType === "pen" && (e.button === 2 || e.button === 5))) {
    mRole = mouseRole(e.button, e.pointerType);
    if (mRole === "none") { pointers.delete(e.pointerId); return; }
    if (mRole === "undo" || mRole === "redo") {
      pointers.delete(e.pointerId);
      if (mRole === "undo") reqUndo(); else reqRedo();
      return;
    }
    if (mRole !== "tool" && mRole !== "hand" && mRole !== S.tool && !S.xform && !spaceDown) {
      btnTool = { id: e.pointerId, prev: S.tool };
      S.tool = mRole;
    }
  }
  const isTouch = e.pointerType === "touch";
  const primary = (e.pointerType === "pen" && mRole !== "hand" && !spaceDown) ||
    (e.pointerType === "mouse" && mRole !== "hand" && !spaceDown) ||
    (isTouch && S.fingerDraw);
  const [dx, dy] = toDoc(e.clientX, e.clientY);

  const DRAWERS = ["brush", "eraser", "blur", "smudge", "gapfill", "fill", "enclose",
                   "gradient", "line", "rect", "ellipse", "text", "balloon", "move",
                   "transform", "stamp", "doll", "grab"];



  if (S.tool === "grab" && primary && !S.xform && (S.unsel || !grabHitsActive(dx, dy))) {
    pan = { x: e.clientX, y: e.clientY, view: { ...S.view }, id: e.pointerId };
    return;
  }
  const spreadOn = spreadNow();
  if (primary && S.unsel && DRAWERS.includes(S.tool) && !S.xform && !spreadOn) {
    toast("レイヤーが選ばれていません。レイヤーの一覧で選んでください");
    return;
  }
  if (primary && DRAWERS.includes(S.tool) && !activeRaster() && !spreadOn) {
    toast(S.layers[S.active]?.type === "folder"
      ? "フォルダには描けません。中のレイヤーを選んでください"
      : "調整レイヤーには描けません。絵のレイヤーを選んでください");
    return;
  }


  if (primary && DRAWERS.includes(S.tool) && !["text", "move", "doll", "grab"].includes(S.tool) &&
      activeTarget() !== "mask" && !spreadOn &&
      (isText(S.layers[S.active]) || isDoll(S.layers[S.active]))) {
    toast(isDoll(S.layers[S.active])
      ? "デッサン人形のレイヤーには描けません。上に新しいレイヤーを作ってなぞってください"
      : "テキストレイヤーには直接描けません。🅣で文字を編集するか「絵に変換」してください");
    return;
  }


  if (S.persp.on && primary && !S.xform) {
    const tol = 16 / S.view.scale;
    const vps = activeVPs();
    for (let k = 0; k < vps.length; k++) {
      if (Math.hypot(vps[k][0] - dx, vps[k][1] - dy) < tol) {
        S.persp.drag = { k, id: e.pointerId };
        return;
      }
    }
  }
  if (S.xform && primary) {
    const h = xformHandleAt(dx, dy);
    S.xform.mode = h;
    S.xform.grab = { x: dx, y: dy, dx0: S.xform.dx, dy0: S.xform.dy,
                     sx0: S.xform.sx, sy0: S.xform.sy, rot0: S.xform.rot };
    S.xform.pointerId = e.pointerId;
    return;
  }
  if (S.tool === "picker") { if (primary) pickColor(e.clientX, e.clientY); return; }
  if (S.tool === "wand") { if (primary) magicWand(e.clientX, e.clientY); return; }
  if (S.tool === "hand" || !primary || spaceDown) {
    pan = { x: e.clientX, y: e.clientY, view: { ...S.view }, id: e.pointerId };
    return;
  }

  if (S.tool === "vecedit" && primary) {
    const lay = S.layers[S.active];
    if (!isVector(lay)) { toast("ベクターレイヤーを選んでください"); return; }
    const tol = 14 / S.view.scale;
    if (S.vecSel && S.vecSel.layer === lay.id) {
      const s = lay.strokes.find((k) => k.id === S.vecSel.stroke);
      if (s) {
        for (const hi of vecHandles(s)) {
          if (Math.hypot(s.pts[hi][0] - dx, s.pts[hi][1] - dy) < tol) {
            S.vecDrag = { layer: lay.id, stroke: s.id, hi, id: e.pointerId,
                          orig: s.pts.map((p) => p.slice()), start: [dx, dy] };
            return;
          }
        }
      }
    }
    const hit = vecHit(lay, dx, dy, tol);
    S.vecSel = hit ? { layer: lay.id, stroke: lay.strokes[hit.si].id } : null;
    if (hit) toast("線を選択しました(白丸をドラッグで形を変更 / Deleteで削除)");
    requestRender();
    return;
  }

  if (S.tool === "eraser" && isVector(S.layers[S.active]) && activeTarget() !== "mask" && !spreadOn) {
    localOp({ id: uid(), kind: "vecErase", layer: S.layers[S.active].id,
              mode: S.vecErase, x: Math.round(dx), y: Math.round(dy),
              tol: Math.max(6, Math.round(S.size / 2)) });
    return;
  }
  if (["brush", "eraser"].includes(S.tool) && S.persp.on) {


    const op = currentStrokeOp();
    op.shape = "line";
    S.stroke = beginLocalStroke(op);
    S.stroke.pointerId = e.pointerId;
    S.stroke.origin = [dx, dy];
    S.shape = { start: [dx, dy], kind: "line", persp: true };
    sendLive({ t: "live", ph: "b", op: { ...op, pts: undefined } });
  } else if (["brush", "eraser", "blur", "smudge", "gapfill"].includes(S.tool)) startStroke(e);
  else if (S.tool === "fill") {
    localOp({ id: uid(), kind: "fill", layer: S.layers[S.active]?.id, target: activeTarget(),
              x: Math.round(dx), y: Math.round(dy), color: S.color,
              opacity: S.opacity, tol: S.fillTol, grow: S.fillGrow,
              gapClose: S.gapClose, ref: S.fillRef, sel: S.sel || undefined });
  } else if (S.tool === "enclose") {
    S.encloseDraft = { pts: [[dx, dy]], id: e.pointerId };
  } else if (S.tool === "gradient") {
    S.grad = { x0: dx, y0: dy, x1: dx, y1: dy, id: e.pointerId };
  } else if (S.tool === "transform") {
    beginTransform();
  } else if (S.tool === "text") {


    const cur = S.layers[S.active];
    openTextEditor(isText(cur) ? cur : null, [Math.round(dx), Math.round(dy)]);
  } else if (S.tool === "doll") {
    const lay = S.layers[S.active];
    if (!isDoll(lay)) { toast("デッサン人形のレイヤーを選んでください(✨素材パネルで作れます)"); return; }
    const hit = dollHit(lay, dx, dy);
    if (!hit) { toast("関節の丸をつまんでください"); return; }
    S.dollDrag = { layer: lay.id, joint: hit, x: dx, y: dy,
                   base: JSON.parse(JSON.stringify(lay.doll)), id: e.pointerId };
  } else if (S.tool === "stamp") {



    S.stampDrag = { x: dx, y: dy, r: 0, angle: 0, id: e.pointerId, opId: uid() };
  } else if (S.tool === "balloon") {
    S.balloon = { x0: dx, y0: dy, x1: dx, y1: dy, id: e.pointerId };
  } else if (["line", "rect", "ellipse"].includes(S.tool)) {
    const op = currentStrokeOp();
    op.shape = S.tool;
    S.stroke = beginLocalStroke(op);
    S.stroke.pointerId = e.pointerId;
    S.shape = { start: [dx, dy], kind: S.tool };
  } else if (S.tool === "move" || S.tool === "grab") {
    S.moving = { layer: S.layers[S.active]?.id, dx: 0, dy: 0, start: [dx, dy], id: e.pointerId };
  } else if (S.tool === "selrect") {
    S.selMode = e.shiftKey ? "add" : (e.altKey ? "sub" : S.selModeUI);
    S.selDraft = { type: "rect", x0: dx, y0: dy, x1: dx, y1: dy, id: e.pointerId };
  } else if (S.tool === "lasso") {
    S.selMode = e.shiftKey ? "add" : (e.altKey ? "sub" : S.selModeUI);
    S.selDraft = { type: "poly", pts: [[dx, dy]], id: e.pointerId };
  }
});

onView("pointermove", (e) => {
  if (e.pointerType !== "touch") {
    const r = view.getBoundingClientRect();
    S.hover = [e.clientX - r.left, e.clientY - r.top];
    S.hoverSolo = inSolo;
  }
  if (!pointers.has(e.pointerId)) { requestRender(); return; }
  const prev = pointers.get(e.pointerId);
  if (gesture) gesture.moved += Math.hypot(e.clientX - prev.x, e.clientY - prev.y);
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, type: e.pointerType });
  if (holdTimer && Math.hypot(e.clientX - prev.x, e.clientY - prev.y) > 3) {
    clearTimeout(holdTimer); holdTimer = null;
  }
  if (pinch) {
    const t = [...pointers.values()].filter((p) => p.type === "touch");
    if (t.length >= 2) {
      const d = Math.hypot(t[0].x - t[1].x, t[0].y - t[1].y);
      const ang = Math.atan2(t[1].y - t[0].y, t[1].x - t[0].x);
      const cx = (t[0].x + t[1].x) / 2, cy = (t[0].y + t[1].y) / 2;
      S.view.scale = clamp(pinch.view.scale * clamp(d / pinch.d, 0.05, 20), 0.02, 32);
      let rot = pinch.view.rot + (pinch.view.flip ? -(ang - pinch.ang) : (ang - pinch.ang));
      const norm = ((rot % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
      if (norm < 0.07 || norm > 2 * Math.PI - 0.07) rot = Math.round(rot / (2 * Math.PI)) * 2 * Math.PI;
      S.view.rot = rot;
      const r = view.getBoundingClientRect();
      anchorAt(pinch.docMid, cx - r.left, cy - r.top);
      requestRender(); updateViewPanel();
    }
    return;
  }
  if (S.xform && S.xform.pointerId === e.pointerId && S.xform.mode) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    const x = S.xform, g = x.grab;
    if (x.mode.type === "move") { x.dx = g.dx0 + (dx - g.x); x.dy = g.dy0 + (dy - g.y); }
    else if (x.mode.type === "scale") {
      const w0 = Math.max(1, (x.box.x1 - x.box.x0) / 2), h0 = Math.max(1, (x.box.y1 - x.box.y0) / 2);
      const gx = Math.abs(g.x - x.cx) || w0, gy = Math.abs(g.y - x.cy) || h0;
      const k = Math.hypot(dx - x.cx, dy - x.cy) / Math.max(1, Math.hypot(g.x - x.cx, g.y - x.cy));
      x.sx = Math.max(0.02, g.sx0 * k); x.sy = Math.max(0.02, g.sy0 * k);
    } else if (x.mode.type === "rotate") {
      const a0 = Math.atan2(g.y - x.cy, g.x - x.cx);
      const a1 = Math.atan2(dy - x.cy, dx - x.cx);
      x.rot = g.rot0 + (a1 - a0);
    }
    requestRender();
    return;
  }
  if (S.vecDrag && S.vecDrag.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    const lay = layerById(S.vecDrag.layer);
    const s = lay && lay.strokes.find((k) => k.id === S.vecDrag.stroke);
    if (s) {
      const mvx = dx - S.vecDrag.start[0], mvy = dy - S.vecDrag.start[1];
      const span = Math.max(4, Math.round(S.vecDrag.orig.length / 8));
      const pts = S.vecDrag.orig.map((p) => p.slice());
      for (let i = 0; i < pts.length; i++) {
        const d = Math.abs(i - S.vecDrag.hi);
        if (d > span) continue;
        const w = 0.5 + 0.5 * Math.cos(Math.PI * d / span);
        pts[i][0] += mvx * w; pts[i][1] += mvy * w;
      }
      s.pts = pts;
      rebuildVector(lay);
      requestRender();
    }
    return;
  }
  if (S.persp.drag && S.persp.drag.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    S.persp.vps[S.persp.drag.k] = [Math.round(dx), Math.round(dy)];
    requestRender();
    return;
  }
  if (S.grad && S.grad.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    S.grad.x1 = dx; S.grad.y1 = dy;
    requestRender();
    return;
  }
  if (S.dollDrag && S.dollDrag.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    const d = S.dollDrag;
    const lay = layerById(d.layer);
    if (lay && isDoll(lay)) {
      lay.doll = { ...d.base,
                   pose: dollMove(d.base.pose, d.joint, dx - d.x, dy - d.y) };
      rebuildDoll(lay);
      requestRender();
    }
    return;
  }
  if (S.stampDrag && S.stampDrag.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    const s = S.stampDrag;
    s.r = Math.hypot(dx - s.x, dy - s.y);
    if (s.r > 4) s.angle = Math.atan2(dy - s.y, dx - s.x) + Math.PI / 2;
    requestRender();
    return;
  }
  if (S.balloon && S.balloon.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    S.balloon.x1 = dx; S.balloon.y1 = dy;
    requestRender();
    return;
  }
  if (S.stroke && S.stroke.pointerId === e.pointerId) {
    if (S.shape) {
      let [dx, dy] = toDoc(e.clientX, e.clientY);
      const st = S.stroke;
      if (S.shape.persp) {
        st.vp = null; st.vpLocked = false;
        [dx, dy] = perspSnap(st, dx, dy);
      }
      clearStrokeCanvas(st);
      st.op.pts = shapePts(S.shape.kind, S.shape.start, [dx, dy], st.op.size);
      strokeAddPoints(st, st.op.pts);
      requestRender();
    } else addStrokePoint(e);
    return;
  }
  if (S.moving && S.moving.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    S.moving.dx = Math.round(dx - S.moving.start[0]);
    S.moving.dy = Math.round(dy - S.moving.start[1]);
    requestRender();
    return;
  }
  if (S.encloseDraft && S.encloseDraft.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    S.encloseDraft.pts.push([dx, dy]);
    requestRender();
    return;
  }
  if (S.selDraft && S.selDraft.id === e.pointerId) {
    const [dx, dy] = toDoc(e.clientX, e.clientY);
    if (S.selDraft.type === "rect") { S.selDraft.x1 = dx; S.selDraft.y1 = dy; }
    else S.selDraft.pts.push([dx, dy]);
    requestRender();
    return;
  }
  if (pan && pan.id === e.pointerId) {
    S.view.x = pan.view.x + (e.clientX - pan.x);
    S.view.y = pan.view.y + (e.clientY - pan.y);
    requestRender();
  }
});

function finishSpecial(e, cancel) {
  if (S.vecDrag && S.vecDrag.id === e.pointerId) {
    const d = S.vecDrag;
    S.vecDrag = null;
    const lay = layerById(d.layer);
    const s = lay && lay.strokes.find((k) => k.id === d.stroke);
    if (s && !cancel) {
      const pts = s.pts.map((p) => [Math.round(p[0] * 100) / 100, Math.round(p[1] * 100) / 100, p[2]]);
      s.pts = d.orig;
      rebuildVector(lay);
      localOp({ id: uid(), kind: "vecEdit", layer: d.layer, stroke: d.stroke, pts });
    } else if (s) { s.pts = d.orig; rebuildVector(lay); }
  }
  if (S.persp.drag && S.persp.drag.id === e.pointerId) { S.persp.drag = null; savePrefs(); }
  if (S.xform && S.xform.pointerId === e.pointerId) { S.xform.mode = null; S.xform.pointerId = null; }
  if (S.stroke && S.stroke.pointerId === e.pointerId) { S.shape = null; endStroke(cancel); }
  if (S.grad && S.grad.id === e.pointerId) {
    const g = S.grad;
    S.grad = null;
    if (!cancel && Math.hypot(g.x1 - g.x0, g.y1 - g.y0) > 4)
      localOp({ id: uid(), kind: "gradient", layer: S.layers[S.active]?.id,
                target: activeTarget(), x0: g.x0, y0: g.y0, x1: g.x1, y1: g.y1,
                type: S.gradType, mode: S.gradMode, c0: S.color, c1: S.sub,
                opacity: S.opacity, sel: S.sel || undefined });
    requestRender();
  }
  if (S.dollDrag && S.dollDrag.id === e.pointerId) {
    const d = S.dollDrag;
    S.dollDrag = null;
    const lay = layerById(d.layer);
    if (lay && isDoll(lay)) {
      const moved = lay.doll;



      lay.doll = d.base;
      if (cancel) rebuildDoll(lay);
      else localOp({ id: uid(), kind: "setDoll", layer: lay.id, doll: moved,
                     prevDoll: d.base });
    }
    requestRender();
  }
  if (S.stampDrag && S.stampDrag.id === e.pointerId) {
    const s = S.stampDrag;
    S.stampDrag = null;

    const r = s.r > 6 ? s.r : S.matSize;
    if (!cancel)
      localOp({ id: s.opId, kind: "stamp", layer: S.layers[S.active]?.id,
                target: activeTarget(), mat: S.material, x: s.x, y: s.y,
                r, angle: s.r > 6 ? s.angle : 0, color: S.color, sub: S.sub,
                opacity: S.opacity, sel: S.sel || undefined });
    requestRender();
  }
  if (S.balloon && S.balloon.id === e.pointerId) {
    const b = S.balloon;
    S.balloon = null;
    if (!cancel && Math.abs(b.x1 - b.x0) > 12 && Math.abs(b.y1 - b.y0) > 12)
      localOp({ id: uid(), kind: "balloon", layer: S.layers[S.active]?.id,
                target: activeTarget(), x0: b.x0, y0: b.y0, x1: b.x1, y1: b.y1,
                fill: S.sub, line: S.color, lw: Math.max(2, S.size / 4),
                sel: S.sel || undefined });
    requestRender();
  }
  if (S.moving && S.moving.id === e.pointerId) {
    const mv = S.moving;
    S.moving = null;
    if (!cancel && (mv.dx || mv.dy))
      localOp({ id: uid(), kind: "offsetLayer", layer: mv.layer, target: activeTarget(),
                dx: mv.dx, dy: mv.dy });
    requestRender();
  }
  if (S.encloseDraft && S.encloseDraft.id === e.pointerId) {
    const d = S.encloseDraft;
    S.encloseDraft = null;
    if (!cancel && d.pts.length >= 6) {
      toast("囲った範囲を塗っています…");
      localOp({ id: uid(), kind: "fill", layer: S.layers[S.active]?.id, target: activeTarget(),
                enclose: d.pts.map(([x, y]) => [Math.round(x), Math.round(y)]),
                color: S.color, opacity: S.opacity, tol: S.fillTol, grow: S.fillGrow,
                gapClose: S.gapClose, ref: S.fillRef, sel: S.sel || undefined });
    }
    requestRender();
  }
  if (S.selDraft && S.selDraft.id === e.pointerId) {
    const d = S.selDraft;
    S.selDraft = null;
    if (!cancel) {
      let shape = null;
      if (d.type === "rect" && Math.abs(d.x1 - d.x0) > 3 && Math.abs(d.y1 - d.y0) > 3)
        shape = { type: "rect", x0: Math.round(d.x0), y0: Math.round(d.y0),
                  x1: Math.round(d.x1), y1: Math.round(d.y1) };
      else if (d.type === "poly" && d.pts.length >= 3)
        shape = { type: "poly", pts: d.pts.map(([x, y]) => [Math.round(x), Math.round(y)]) };
      if (shape) setSel(combineSel(S.sel, shape, S.selMode || "new"));
      else if ((S.selMode || "new") === "new") setSel(null);
    }
    requestRender();
  }
}
function evalTapGesture() {
  if (!gesture) return;
  const g = gesture;
  gesture = null;
  if (performance.now() - g.t0 < 350 && g.moved < 14) {
    if (g.maxTouches === 2) { reqUndo(); toast("↩ 元に戻す"); }
    else if (g.maxTouches === 3) { reqRedo(); toast("↪ やり直す"); }
  }
}
onView("pointerup", (e) => {
  pointers.delete(e.pointerId);
  finishSpecial(e, false);
  restoreBtnTool(e);
  if (pan && pan.id === e.pointerId) pan = null;
  const left = [...pointers.values()].filter((p) => p.type === "touch").length;
  if (pinch && left < 2) pinch = null;
  if (e.pointerType === "touch" && left === 0) evalTapGesture();
});
onView("pointercancel", (e) => {
  pointers.delete(e.pointerId);
  finishSpecial(e, true);
  restoreBtnTool(e);
  if (pan && pan.id === e.pointerId) pan = null;
  pinch = null; gesture = null;
});
onView("pointerleave", () => { S.hover = null; requestRender(); });
onView("contextmenu", (e) => e.preventDefault());
onView("wheel", (e) => {
  e.preventDefault();
  const w = S.wheel || WHEEL_DEFAULT;
  const role = (e.ctrlKey || e.metaKey) ? w.ctrl : e.shiftKey ? w.shift : e.altKey ? w.alt : w.plain;

  const d = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
  const up = d < 0;
  if (role === "zoom" || !role) zoomAt(e.clientX, e.clientY, up ? 1.12 : 1 / 1.12);
  else if (role === "size") stepBrush("size", (up ? 1 : -1) * Math.max(1, Math.round(S.size * 0.08)), 1, 400);
  else if (role === "opacity") stepBrush("opacity", up ? 0.05 : -0.05, 0.01, 1);
  else if (role === "rotate") viewCenterOp(() => { S.view.rot += (up ? -1 : 1) * Math.PI / 36; });
  else if (role === "panV" || role === "panH") {
    const step = (up ? 1 : -1) * 60;
    if (role === "panV") S.view.y += step; else S.view.x += step;
    requestRender();
  }
}, { passive: false });

window.addEventListener("mouseup", (e) => { if (e.button === 3 || e.button === 4) e.preventDefault(); });
window.addEventListener("auxclick", (e) => { if (e.button === 3 || e.button === 4) e.preventDefault(); });

let spaceDown = false;

let btnTool = null;
function mouseRole(button, pointerType) {
  const mb = S.mouseBtn || {};
  let r;
  if (pointerType === "pen") {

    r = button === 2 ? mb.penBarrel : button === 5 ? mb.penEraser : "tool";
  } else {
    r = button === 0 ? mb.left : button === 1 ? mb.middle : button === 2 ? mb.right :
        button === 3 ? mb.back : button === 4 ? mb.forward : "hand";
  }
  return (r === "tool" || r === "none" || r === "undo" || r === "redo" || TOOLS[r]) ? r
       : (button === 0 || pointerType === "pen" ? "tool" : "hand");
}

function grabHitsActive(dx, dy) {
  const lay = activeRaster();
  if (!lay || !lay.canvas || lay.visible === false) return false;
  const r = Math.max(2, Math.round(4 / (S.view.scale || 1)));
  const x0 = Math.floor(dx) - r, y0 = Math.floor(dy) - r, n = r * 2 + 1;
  let d;
  try { d = (lay.ctx || lay.canvas.getContext("2d")).getImageData(x0, y0, n, n).data; }
  catch (err) { return true; }
  for (let i = 3; i < d.length; i += 4) if (d[i] > 8) return true;
  return false;
}
function restoreBtnTool(e) {
  if (!btnTool || btnTool.id !== e.pointerId) return;
  S.tool = btnTool.prev; btnTool = null;
  requestRender();
}





const KEY_GROUPS = [["tool", "道具"], ["edit", "編集"], ["sel", "選択範囲"], ["brush", "ブラシ・色"],
                    ["view", "表示"], ["layer", "レイヤー"], ["file", "ファイル"], ["panel", "パネル"]];
const click = (id) => () => { const b = $(id); if (b) b.click(); };
const viewCenter = (k) => () => { const r = view.getBoundingClientRect(); zoomAt(r.left + r.width / 2, r.top + r.height / 2, k); };
function toggleLayerProp(key, label) {
  const lay = S.layers[S.active];
  if (!lay || S.unsel) { toast("レイヤーを選んでください"); return; }
  localOp({ id: uid(), kind: "setLayer", layer: lay.id, props: { [key]: !lay[key] }, prev: { [key]: !!lay[key] } });
  toast(`${label}: ${!lay[key] ? "切" : "入"}`);
}
function stepBrush(key, d, lo, hi) { S[key] = clamp(+(S[key] + d).toFixed(2), lo, hi); syncBrushUI(); savePrefs(); }
const KEY_ACTIONS = {};
const DEF_TOOL_KEYS = { brush: ["B"], eraser: ["E"], fill: ["G"], move: ["V"], selrect: ["M"], lasso: ["L"],
                        picker: ["I"], line: ["U"], wand: ["W"], gradient: ["R"] };
for (const [t, v] of Object.entries(TOOLS)) {
  if (t === "hand" || t === "transform") continue;
  KEY_ACTIONS["tool:" + t] = { g: "tool", name: v.icon + " " + v.name, def: DEF_TOOL_KEYS[t] || [], tool: t };
}
Object.assign(KEY_ACTIONS, {
  undo:       { g: "edit", name: "元に戻す", def: ["Ctrl+Z"], run: () => reqUndo() },
  redo:       { g: "edit", name: "やり直す", def: ["Ctrl+Y", "Ctrl+Shift+Z"], run: () => reqRedo() },
  transform:  { g: "edit", name: "変形", def: ["Ctrl+T"], run: () => { setTool("transform"); beginTransform(); } },
  clearLayer: { g: "edit", name: "レイヤーの中身を消す", def: [], run: click("btnClearLayer") },
  selAll:     { g: "sel", name: "すべてを選択", def: ["Ctrl+A"], run: () => selectAll() },
  selNone:    { g: "sel", name: "選択を解除", def: ["Ctrl+D"], run: () => setSel(null) },
  selInv:     { g: "sel", name: "選択範囲を反転", def: ["Ctrl+I"], run: () => invertSel() },
  sizeDown:   { g: "brush", name: "ブラシを細く", def: ["["], run: () => stepBrush("size", -2, 1, 400) },
  sizeUp:     { g: "brush", name: "ブラシを太く", def: ["]"], run: () => stepBrush("size", 2, 1, 400) },
  opDown:     { g: "brush", name: "不透明度を下げる(10%)", def: [], run: () => stepBrush("opacity", -0.1, 0.01, 1) },
  opUp:       { g: "brush", name: "不透明度を上げる(10%)", def: [], run: () => stepBrush("opacity", 0.1, 0.01, 1) },
  swapColor:  { g: "brush", name: "描画色と背景色を入れ替え", def: ["X"], run: click("btnSwapColor") },
  pickHold:   { g: "brush", name: "押している間スポイト", def: ["Alt"], hold: "picker" },
  washToggle: { g: "brush", name: "ウォッシュの入/切", def: [], run: () => { const c = $("wash"); c.checked = !c.checked; c.onchange({ target: c }); toast("ウォッシュ: " + (S.wash ? "入" : "切")); } },
  handHold:   { g: "view", name: "押している間 画面を動かす", def: ["Space"], hold: "hand" },
  zoomIn:     { g: "view", name: "拡大", def: ["Ctrl+="], run: viewCenter(1.25) },
  zoomOut:    { g: "view", name: "縮小", def: ["Ctrl+-"], run: viewCenter(1 / 1.25) },
  fit:        { g: "view", name: "全体を表示", def: ["Ctrl+0"], run: () => { fitView(); requestRender(); } },
  rotL:       { g: "view", name: "左に回す(15°)", def: [], run: click("btnRotL") },
  rotR:       { g: "view", name: "右に回す(15°)", def: [], run: click("btnRotR") },
  rot0:       { g: "view", name: "回転を戻す", def: [], run: click("btnRot0") },
  flipView:   { g: "view", name: "左右反転して表示", def: ["H"], run: click("btnFlipView") },
  newLayer:   { g: "layer", name: "新しいレイヤー", def: ["Ctrl+Shift+N"], run: click("btnAddLayer") },
  dupLayer:   { g: "layer", name: "レイヤーを複製", def: ["Ctrl+J"], run: click("btnDupLayer") },
  delLayer:   { g: "layer", name: "レイヤーを削除", def: [], run: click("btnDelLayer") },
  mergeDown:  { g: "layer", name: "下のレイヤーと結合", def: ["Ctrl+E"], run: click("btnMergeDown") },
  layerUp:    { g: "layer", name: "重ね順を上げる", def: ["Ctrl+]"], run: click("btnLayerUp") },
  layerDown:  { g: "layer", name: "重ね順を下げる", def: ["Ctrl+["], run: click("btnLayerDown") },
  clip:       { g: "layer", name: "クリッピングの入/切", def: ["Ctrl+Alt+G"], run: () => toggleLayerProp("clip", "クリッピング") },
  alphaLock:  { g: "layer", name: "透明部分の保護の入/切", def: ["/"], run: () => toggleLayerProp("alphaLock", "透明部分の保護") },
  visible:    { g: "layer", name: "表示/非表示", def: [], run: () => toggleLayerProp("visible", "表示") },
  unselLayer: { g: "layer", name: "レイヤーの選択を外す", def: [], run: () => setUnsel(!S.unsel) },
  solo:       { g: "layer", name: "パーツ単体の枠", def: [], run: click("btnSolo") },

  saveNative: { g: "file", name: "SmartPaint形式で out に新しく保存", def: [], run: click("btnSaveNative") },
  savePsd:    { g: "file", name: "PSD で out に新しく保存", def: [], run: click("btnSavePsd") },
  saveOver:   { g: "file", name: "上書き保存", def: ["Ctrl+S"], run: () => doSaveOver() },
  saveAs:     { g: "file", name: "別名で保存", def: ["Ctrl+Shift+S"], run: () => openSaveAs() },
  savePng:    { g: "file", name: "PNG で書き出し", def: [], run: click("btnSavePng") },
  zen:        { g: "panel", name: "液タブモード(UIを隠す)", def: ["Tab"], run: click("btnZen") },
  pLayers:    { g: "panel", name: "レイヤーのパネル", def: ["F7"], run: click("btnLayers") },
  pBrush:     { g: "panel", name: "ブラシ・ツール設定", def: ["F5"], run: click("btnBrushSet") },
  pColor:     { g: "panel", name: "色", def: [], run: click("btnColor") },
  pHistory:   { g: "panel", name: "履歴", def: [], run: click("btnHistory") },
  pFilter:    { g: "panel", name: "フィルタ・効果", def: [], run: click("btnFilter") },
  pKeys:      { g: "panel", name: "ショートカットの設定", def: ["Ctrl+Alt+K"], run: () => openKeysPanel() },
});
function keyBindings() {
  const out = {};
  for (const [id, a] of Object.entries(KEY_ACTIONS)) out[id] = (S.keys && S.keys[id]) ? S.keys[id] : a.def;
  return out;
}
let keyIndex = null;
function rebuildKeyIndex() {
  keyIndex = new Map();
  for (const [id, ks] of Object.entries(keyBindings())) for (const k of ks) keyIndex.set(k, id);
}
const MOD_KEYS = { Control: "Ctrl", Shift: "Shift", Alt: "Alt", Meta: "Ctrl" };
function comboOf(e) {
  if (MOD_KEYS[e.key]) {

    const me = MOD_KEYS[e.key];
    return ((e.ctrlKey || e.metaKey) && me !== "Ctrl" ? "Ctrl+" : "") + (e.shiftKey && me !== "Shift" ? "Shift+" : "") +
           (e.altKey && me !== "Alt" ? "Alt+" : "") + me;
  }
  let k;
  if (/^Key[A-Z]$/.test(e.code)) k = e.code.slice(3);
  else if (/^Digit\d$/.test(e.code)) k = e.code.slice(5);
  else if (/^Numpad\d$/.test(e.code)) k = "Num" + e.code.slice(6);
  else if (e.code === "Space") k = "Space";
  else if (e.code === "Equal" || e.code === "NumpadAdd" || e.key === "+" || e.key === ";") k = "=";
  else if (e.code === "Minus" || e.code === "NumpadSubtract") k = "-";
  else if (e.key.length === 1) k = e.key.toUpperCase();
  else k = e.key;
  return (e.ctrlKey || e.metaKey ? "Ctrl+" : "") + (e.shiftKey ? "Shift+" : "") + (e.altKey ? "Alt+" : "") + k;
}
let keyHold = null;
let holdAct = null;
let keyCapture = null;
function releaseHolds() {
  if (holdAct) {
    if (holdAct.kind === "hand") spaceDown = false;
    if (holdAct.kind === "picker" && S.tool === "picker" && !S.stroke) setTool(holdAct.prev);
    holdAct = null;
  }
  keyHold = null;
}
window.addEventListener("blur", releaseHolds);
window.addEventListener("keydown", (e) => {
  if (keyCapture) { captureKey(e); return; }
  const tag = e.target.tagName;
  if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;

  if ((e.key === "Delete" || e.key === "Backspace") && S.vecSel) {
    e.preventDefault();
    localOp({ id: uid(), kind: "vecDelete", layer: S.vecSel.layer, stroke: S.vecSel.stroke });
    S.vecSel = null;
    return;
  }
  if (e.key === "Escape") {
    if (S.xform) commitTransform(false);
    else if (S.vecSel) { S.vecSel = null; requestRender(); }
    else if (S.sel) setSel(null);
    else setUnsel(true);
    return;
  }
  if (e.key === "Enter" && S.xform) { commitTransform(true); return; }
  if (!keyIndex) rebuildKeyIndex();
  const combo = comboOf(e);
  const id = keyIndex.get(combo);
  if (!id) return;
  e.preventDefault();
  if (e.repeat) return;
  const a = KEY_ACTIONS[id];
  if (a.hold) {
    if (holdAct) return;

    if (a.hold === "picker" && ["selrect", "lasso", "wand"].includes(S.tool)) return;
    holdAct = { key: e.key, code: e.code, kind: a.hold, prev: S.tool };
    if (a.hold === "hand") spaceDown = true;
    if (a.hold === "picker" && S.tool !== "picker" && !S.stroke) setTool("picker");
    return;
  }
  if (a.tool) {
    if (S.tool === a.tool) return;
    keyHold = { code: e.code, prev: S.tool, t: performance.now() };
    setTool(a.tool);
    return;
  }
  a.run();
});
window.addEventListener("keyup", (e) => {
  if (holdAct && (e.code === holdAct.code || (MOD_KEYS[e.key] && MOD_KEYS[e.key] === MOD_KEYS[holdAct.key]))) releaseHolds();


  if (keyHold && e.code === keyHold.code) {
    if (performance.now() - keyHold.t >= 350 && !S.stroke) setTool(keyHold.prev);
    keyHold = null;
  }
});

function openKeysPanel() { if (togglePanel("keysPanel")) { syncMouseBtnUI(); buildKeysList(); } }
function buildKeysList() {
  const box = $("keysList"); if (!box) return;
  const q = ($("keysFilter").value || "").trim();
  const binds = keyBindings();
  box.textContent = "";
  for (const [g, gname] of KEY_GROUPS) {
    const ids = Object.keys(KEY_ACTIONS).filter((id) => KEY_ACTIONS[id].g === g &&
      (!q || KEY_ACTIONS[id].name.includes(q) || binds[id].some((k) => k.toUpperCase().includes(q.toUpperCase()))));
    if (!ids.length) continue;
    const h = document.createElement("div"); h.className = "keysGroup"; h.textContent = gname; box.append(h);
    for (const id of ids) {
      const row = document.createElement("div"); row.className = "keyRow";
      const nm = document.createElement("span"); nm.className = "kname"; nm.textContent = KEY_ACTIONS[id].name;
      row.append(nm);
      for (const k of binds[id]) {
        const c = document.createElement("span"); c.className = "keyChip"; c.textContent = k;
        c.dataset.tipHead = k; c.dataset.tip = "クリックでこの割り当てを外します";
        c.onclick = () => setBinding(id, binds[id].filter((x) => x !== k));
        row.append(c);
      }
      if (binds[id].length < 2) {
        const add = document.createElement("button"); add.className = "keyAdd"; add.textContent = "＋";
        add.dataset.tipHead = "キーを割り当てる"; add.dataset.tip = "押してから、割り当てたいキーを押します(Esc でやめる)";
        add.onclick = () => {
          if (keyCapture) keyCapture.btn.classList.remove("wait");
          keyCapture = { id, btn: add }; add.classList.add("wait"); add.textContent = "キーを押す…";
        };
        row.append(add);
      }
      box.append(row);
    }
  }
}
function setBinding(id, keys) {
  S.keys = { ...(S.keys || {}), [id]: keys };
  rebuildKeyIndex(); savePrefs(); buildKeysList();
}
function captureKey(e) {
  e.preventDefault(); e.stopPropagation();
  const cap = keyCapture;
  if (e.key === "Escape") { keyCapture = null; buildKeysList(); return; }
  const combo = comboOf(e);

  if (MOD_KEYS[e.key] && !KEY_ACTIONS[cap.id].hold) { cap.btn.textContent = "続けてキーを…"; return; }
  if (["Enter"].includes(e.key)) { toast("Enter は変形の確定に使うので割り当てられません"); return; }
  keyCapture = null;
  const binds = keyBindings();
  const S2 = { ...(S.keys || {}) };
  for (const [oid, ks] of Object.entries(binds)) {
    if (oid !== cap.id && ks.includes(combo)) {
      S2[oid] = ks.filter((k) => k !== combo);
      toast(`「${KEY_ACTIONS[oid].name}」から ${combo} を外して付け替えました`);
    }
  }
  S2[cap.id] = [...binds[cap.id].filter((k) => k !== combo), combo].slice(-2);
  S.keys = S2;
  rebuildKeyIndex(); savePrefs(); buildKeysList();
}
$("keysFilter").oninput = () => buildKeysList();
$("keysReset").onclick = () => { S.keys = {}; rebuildKeyIndex(); savePrefs(); buildKeysList(); toast("キーボードを初めの割り当てに戻しました"); };
$("btnOpenKeys").onclick = () => openKeysPanel();


let connecting = false, reconnectTimer = null, building = false;
const buildQueue = [];
function connect() {
  if (connecting || wsAlive()) return;
  connecting = true;
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws`);
  S.ws = ws;
  ws.onopen = () => {
    connecting = false; S.wsOpen = true;
    $("connDot").classList.add("on");
    sayHello();
  };
  ws.onclose = () => {
    connecting = false; S.wsOpen = false;
    $("connDot").classList.remove("on");
    if (reconnectTimer) clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => { reconnectTimer = null; connect(); }, 1000);
  };
  ws.onerror = () => ws.close();
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.t === "init") {
      S.me = m.me ?? null;
      building = true; buildQueue.length = 0;
      buildDoc(m.doc, m.oplog, m.steps).then(() => {
        building = false;
        for (const q of buildQueue.splice(0)) handleMsg(q, ws);
        const pend = pendingOps.splice(0);
        for (const op of pend) { applyOp(op, true); sendOp(op); }
      });
      return;
    }
    if (building) { buildQueue.push(m); return; }
    handleMsg(m, ws);
  };
}




function keepActive(fn) {
  const keep = S.layers[S.active]?.id;
  fn();
  if (keep === undefined) return;
  const i = layerIndex(keep);
  const next = i >= 0 ? i : clamp(S.active, 0, S.layers.length - 1);
  if (next !== S.active) { S.active = next; rebuildLayerList(); }
}
function handleMsg(m, ws) {
  switch (m.t) {
    case "doc": ws.close(); break;
    case "fonts": loadServerFonts(); break;
    case "op": keepActive(() => applyOp(m.op, true)); break;
    case "undo": {
      const i = S.history.findLastIndex((h) => h.opId === m.id);
      if (i < 0 || i !== S.history.length - 1) { ws.close(); break; }
      const h = S.history.pop();
      S.histBytes -= h.bytes || 0;
      keepActive(() => h.restore());
      updateHistoryPanel();
      touch();
      requestRender();
      break;
    }
    case "peers":
      S.peers = m.list || [];
      renderPeers();
      break;
    case "pong": {

      const rtt = Date.now() - (m.ts || Date.now());
      S.rtt = S.rtt == null ? rtt : Math.round(S.rtt * 0.7 + rtt * 0.3);
      S.rttWorst = Math.max(S.rttWorst || 0, rtt);
      renderPeers();
      break;
    }
    case "view": applySharedView(m.v); break;
    case "saved":

      S.doc.rev = m.rev;
      updateHistoryPanel();
      toast("保存: " + m.path);
      break;
    case "docname":
      S.doc.src = m.src; S.doc.name = m.name;
      break;
    case "live": {
      if (m.ph === "b") S.remote.set(m.op.id, newStrokeState(m.op, makeCanvas()));
      else if (m.ph === "p") {
        const r = S.remote.get(m.id);
        if (r) { strokeAddPoints(r, m.pts); requestRender(); }
      } else if (m.ph === "c") { S.remote.delete(m.id); requestRender(); }
      break;
    }
  }
}

function reqUndo(n) {
  if (wsAlive()) S.ws.send(JSON.stringify({ t: "undo", n: Number.isInteger(n) && n > 0 ? n : 1 }));
}
function reqRedo() { if (wsAlive()) S.ws.send(JSON.stringify({ t: "redo" })); }


function setUnsel(on) {
  S.unsel = !!on && S.layers.length > 0;
  S.unselId = S.unsel ? S.layers[S.active]?.id : null;
  rebuildLayerList();
  if (S.unsel) toast("レイヤーの選択を外しました（🤚つかむ = 画面を動かす）");
}
function rebuildLayerList() {
  const list = $("layerList");
  list.innerHTML = "";

  if (S.unsel && S.layers[S.active]?.id !== S.unselId) { S.unsel = false; S.unselId = null; }
  list.onclick = (ev) => { if (ev.target === list && !S.unsel) setUnsel(true); };
  const ub = $("btnUnselLayer"); if (ub) ub.classList.toggle("active", !!S.unsel);

  const hidden = new Set();
  for (let i = 0; i < S.layers.length; i++) {
    const e = S.layers[i];
    if (e.type === "folder" && !e.open) {
      const end = skipSubtree(i);
      for (let j = i + 1; j < end; j++) hidden.add(j);
    }
  }


  const order = [];
  const walk = (from, to) => {
    const sibs = [];
    for (let k = from; k < to; k = skipSubtree(k)) sibs.push(k);
    for (let s = sibs.length - 1; s >= 0; s--) {
      const k = sibs[s];
      order.push(k);
      if (S.layers[k].type === "folder") walk(k + 1, skipSubtree(k));
    }
  };
  walk(0, S.layers.length);
  order.forEach((i) => {
    const lay = S.layers[i];
    if (hidden.has(i)) return;
    const row = document.createElement("div");
    row.className = "layerItem" + (i === S.active && !S.unsel ? " active" : "") +
                    (lay.visible ? "" : " invisible") +
                    (lay.type === "folder" ? " folder" : "") +
                    (lay.type === "adjust" ? " adjust" : "");
    row.style.marginLeft = (lay.depth * 14) + "px";
    const eye = document.createElement("button");
    eye.className = "eye";
    eye.textContent = lay.visible ? "👁️" : "🚫";
    eye.dataset.tipHead = lay.visible ? "表示中" : "非表示";
    eye.dataset.tip = "クリックで表示/非表示を切り替えます";
    eye.onclick = (ev) => {
      ev.stopPropagation();
      localOp({ id: uid(), kind: "setLayer", layer: lay.id,
                props: { visible: !lay.visible }, prev: { visible: lay.visible } });
    };
    row.append(eye);
    if (lay.type === "folder") {
      const tw = document.createElement("button");
      tw.className = "eye";
      tw.textContent = lay.open ? "📂" : "📁";
      tw.dataset.tipHead = lay.open ? "フォルダを閉じる" : "フォルダを開く";
      tw.dataset.tip = "中身の表示/非表示を切り替えます(絵は消えません)";
      tw.onclick = (ev) => { ev.stopPropagation(); lay.open = !lay.open; rebuildLayerList(); };
      row.append(tw);
    } else if (lay.type === "adjust") {
      const ic = document.createElement("span");
      ic.className = "adjIcon";
      ic.textContent = "◐";
      row.append(ic);
    } else {
      const th = document.createElement("canvas");
      th.width = th.height = 60;
      drawThumbInto(lay, th);
      row.append(th);
    }
    const nm = document.createElement("span");
    nm.className = "lname";
    const marks = (isVector(lay) ? "✒️" : "") + (isText(lay) ? "🅣" : "") +
                  (lay.isRef ? "🔎" : "") + (lay.clip ? "⤵" : "") +
                  (lay.alphaLock ? "🔒" : "") + (lay.hasMask ? "🎭" : "") +
                  (lay.blend !== "normal" ? "✦" : "");
    const extra = lay.type === "adjust" ? `[${FILTERS[lay.filter]?.name || "調整"}]` : "";
    nm.textContent = (marks ? marks + " " : "") + lay.name + extra;
    nm.ondblclick = (ev) => {
      ev.stopPropagation();
      const v = prompt("レイヤー名", lay.name);
      if (v && v !== lay.name)
        localOp({ id: uid(), kind: "setLayer", layer: lay.id,
                  props: { name: v }, prev: { name: lay.name } });
    };
    row.append(nm);
    if (isText(lay)) {
      const tb = document.createElement("button");
      tb.className = "eye";
      tb.textContent = "🅣";
      tb.dataset.tipHead = "文字を書き直す";
      tb.dataset.tip = "文章・書体・サイズ・色・縦書きを何度でも変えられます";
      tb.onclick = (ev) => { ev.stopPropagation(); S.active = i; openTextEditor(lay); };
      row.append(tb);
    }
    if (lay.hasMask) {
      const mb = document.createElement("button");
      mb.className = "eye";
      mb.textContent = (i === S.active && S.maskEdit) ? "🎭*" : "🎭";
      mb.dataset.tipHead = "マスクを編集";
      mb.dataset.tip = "ONの間、描画はマスクに対して行われます(黒=隠す/白=見せる)";
      mb.onclick = (ev) => {
        ev.stopPropagation();
        S.active = i; S.maskEdit = !S.maskEdit;
        rebuildLayerList(); updateMaskBadge();
      };
      row.append(mb);
    }

    const kind = lay.type === "folder" ? "フォルダ"
               : lay.type === "adjust" ? `調整レイヤー(${FILTERS[lay.filter]?.name || ""})`
               : isVector(lay) ? `ベクターレイヤー(線 ${lay.strokes.length}本)`
               : isText(lay) ? "テキストレイヤー(あとから書き直せます)" : "レイヤー";
    const flags = [lay.visible ? null : "非表示", lay.clip ? "クリッピング" : null,
                   lay.alphaLock ? "αロック" : null, lay.hasMask ? "マスク付き" : null,
                   lay.isRef ? "参照レイヤー" : null,
                   lay.blend !== "normal" ? BLEND_NAMES[lay.blend] : null,
                   lay.opacity < 1 ? `不透明度 ${Math.round(lay.opacity * 100)}%` : null,
                   ].filter(Boolean);
    row.dataset.tipHead = lay.name;
    row.dataset.tip = kind + (flags.length ? " / " + flags.join(" / ") : "") +
                      "<br>ダブルクリックで名前を変更・⠿でドラッグ並べ替え";
    row.onclick = () => {
      if (dragState && dragState.moved) return;
      S.unsel = false; S.unselId = null;
      S.active = i;
      if (!S.layers[i].hasMask) S.maskEdit = false;
      if (S.layers[i].type === "adjust") openAdjustEditor(S.layers[i]);
      rebuildLayerList(); updateMaskBadge();
    };

    row.oncontextmenu = (ev) => {
      ev.preventDefault();
      if (S.active !== i || S.unsel) {
        S.unsel = false; S.unselId = null; S.active = i;
        if (!S.layers[i].hasMask) S.maskEdit = false;
        rebuildLayerList(); updateMaskBadge();
      }
      const L = S.layers[i];
      showMenu(ev.clientX, ev.clientY, [
        { label: "📄 複製（コピー）", fn: () => $("btnDupLayer").onclick() },
        { label: "✏️ 名前を変更", fn: () => {
            const v = prompt("レイヤー名", L.name);
            if (v && v !== L.name)
              localOp({ id: uid(), kind: "setLayer", layer: L.id, props: { name: v }, prev: { name: L.name } });
          } },
        { label: L.visible ? "🙈 非表示にする" : "👁 表示する", fn: () =>
            localOp({ id: uid(), kind: "setLayer", layer: L.id,
                      props: { visible: !L.visible }, prev: { visible: L.visible } }) },
        { sep: true },
        { label: "🔼 上へ", fn: () => moveActive(1) },
        { label: "🔽 下へ", fn: () => moveActive(-1) },
        { label: "⤓ 下のレイヤーと結合", fn: () => $("btnMergeDown").onclick() },
        { sep: true },
        { label: "🔲 パーツ単体の枠で見る", fn: () => { setSolo(true); } },
        { label: "🧹 中身を消す（クリア）", fn: () => $("btnClearLayer").onclick() },
        { label: "🗑️ 削除", danger: true, fn: () => $("btnDelLayer").onclick() },
      ]);
    };

    const grip = document.createElement("button");
    grip.className = "eye grip";
    grip.textContent = "⠿";
    grip.dataset.tipHead = "並べ替え";
    grip.dataset.tip = "つまんで上下にドラッグすると重ね順が変わります";
    grip.onpointerdown = (ev) => startLayerDrag(ev, i, row);
    row.append(grip);
    row.dataset.idx = i;
    list.appendChild(row);
  });
  $("layerSwing").checked = !!S.layerSwing;
  const lay = S.layers[S.active];
  if (lay) {
    $("layerOpacity").value = Math.round(lay.opacity * 100);
    $("layerOpacityVal").textContent = Math.round(lay.opacity * 100);
    $("layerBlend").value = lay.blend || "normal";
    $("layerClip").checked = !!lay.clip;
    $("layerLock").checked = !!lay.alphaLock;

    const mcap = $("btnMask").querySelector("small");
    if (mcap) mcap.textContent = lay.hasMask ? "マスク解除" : "マスク";
    $("btnMask").dataset.tip = lay.hasMask
      ? "このレイヤーのマスクを外します" : "消さずに隠せるマスクを付けます";
    $("btnMask").disabled = lay.type !== "raster";
    $("layerRef").checked = !!lay.isRef;
    $("layerRef").disabled = lay.type !== "raster";
  }
  updateMaskBadge();
}

let dragState = null;



const SWING_PX = 28;
function swingPlan(idx, targetIdx, dx) {
  if (!S.layerSwing || Math.abs(dx) < SWING_PX) return null;
  const me = S.layers[idx];
  if (!me) return null;
  const end = skipSubtree(idx);
  const inSelf = (k) => k >= idx && k < end;
  if (targetIdx !== undefined && inSelf(targetIdx)) return null;
  let host = -1;
  if (dx > 0) {
    if (targetIdx !== undefined) host = S.layers[targetIdx]?.type === "folder" ? targetIdx : -1;
    else {
      for (let j = idx - 1; j >= 0; j--) {
        if (S.layers[j].depth < me.depth) break;
        if (S.layers[j].depth === me.depth) { host = j; break; }
      }
      if (host >= 0 && S.layers[host].type !== "folder") host = -1;
    }
    if (host < 0) return null;
    return { to: skipSubtree(host), depth: S.layers[host].depth + 1, hint: host,
             hintId: S.layers[host].id, into: true };
  }
  const base = targetIdx !== undefined ? targetIdx : idx;
  const d = S.layers[base]?.depth ?? 0;
  if (d === 0) return null;
  for (let j = base - 1; j >= 0; j--) if (S.layers[j].depth < d) { host = j; break; }
  if (host < 0 || inSelf(host)) return null;
  return { to: skipSubtree(host), depth: S.layers[host].depth, hint: host,
           hintId: S.layers[host].id, into: false };
}
function startLayerDrag(ev, idx, row) {
  ev.preventDefault();
  ev.stopPropagation();
  try { ev.target.setPointerCapture(ev.pointerId); } catch (e) {}
  dragState = { idx, id: S.layers[idx].id, pointerId: ev.pointerId, moved: false, row, x0: ev.clientX, dx: 0 };
  row.classList.add("dragging");
  const clearMarks = () => {
    for (const r of document.querySelectorAll("#layerList .layerItem"))
      r.classList.remove("dropTarget", "dropInto", "dropOut");
  };
  const move = (e) => {
    if (e.pointerId !== dragState.pointerId) return;
    dragState.moved = true;
    dragState.dx = e.clientX - dragState.x0;
    const rows = [...document.querySelectorAll("#layerList .layerItem")];
    let target = null;
    for (const r of rows) {
      const b = r.getBoundingClientRect();
      if (e.clientY >= b.top && e.clientY <= b.bottom) { target = r; break; }
    }
    clearMarks();
    dragState.targetIdx = (target && target !== row) ? +target.dataset.idx : undefined;

    const plan = swingPlan(dragState.idx, dragState.targetIdx, dragState.dx);
    row.style.transform = S.layerSwing ? `translateX(${clamp(dragState.dx, -40, 40)}px)` : "";
    if (plan) {
      const h = document.querySelector(`#layerList .layerItem[data-idx="${plan.hint}"]`);
      if (h) h.classList.add(plan.into ? "dropInto" : "dropOut");
    } else if (target && target !== row) target.classList.add("dropTarget");
  };
  const up = (e) => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
    row.classList.remove("dragging");
    row.style.transform = "";
    clearMarks();
    const ds = dragState;
    setTimeout(() => { dragState = null; }, 60);
    const plan = swingPlan(ds.idx, ds.targetIdx, ds.dx);
    if (plan) {
      localOp({ id: uid(), kind: "moveLayer", layer: ds.id, to: plan.to,
                from: ds.idx, depth: plan.depth });
      const f = S.layers.find((l) => l.id === plan.hintId);
      toast(plan.into ? `📁 ${f ? f.name : "フォルダ"} の中へ入れました` : `📁 ${f ? f.name : "フォルダ"} の外へ出しました`);
      return;
    }
    if (ds.targetIdx === undefined || ds.targetIdx === ds.idx) return;
    const t = S.layers[ds.targetIdx];
    if (!t) return;

    const end = skipSubtree(ds.idx);
    if (ds.targetIdx > ds.idx && ds.targetIdx < end) { toast("自分の中には移動できません"); return; }

    const to = ds.targetIdx > ds.idx ? skipSubtree(ds.targetIdx) : ds.targetIdx;
    localOp({ id: uid(), kind: "moveLayer", layer: ds.id, to,
              from: ds.idx, depth: t.depth });
  };
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
}

function updateMaskBadge() {
  const on = S.maskEdit && S.layers[S.active]?.hasMask;
  $("maskBadge").classList.toggle("hidden", !on);
}
function drawThumbInto(lay, th) {
  const c = th.getContext("2d");
  c.clearRect(0, 0, th.width, th.height);
  if (!isRaster(lay)) return;
  const k = Math.min(th.width / S.doc.w, th.height / S.doc.h);
  c.drawImage(lay.canvas, (th.width - S.doc.w * k) / 2, (th.height - S.doc.h * k) / 2,
              S.doc.w * k, S.doc.h * k);
}
let thumbTimer = null;
function updateThumb() {
  if (thumbTimer) return;
  thumbTimer = setTimeout(() => { thumbTimer = null; rebuildLayerList(); }, 400);
}
function insertDepth() {
  const cur = S.layers[S.active];
  if (!cur) return 0;
  return cur.type === "folder" ? cur.depth + 1 : cur.depth;
}
$("btnAddLayer").onclick = () => {
  localOp({ id: uid(), kind: "addLayer", at: S.active + 1,
            layer: { id: "L" + uid(), name: "レイヤー" + (S.layers.length + 1), visible: true,
                     opacity: 1, blend: "normal", clip: false, alphaLock: false,
                     type: "raster", depth: insertDepth() } });
};
$("btnAddVector").onclick = () => {
  localOp({ id: uid(), kind: "addLayer", at: S.active + 1,
            layer: { id: "V" + uid(), name: "ベクター" + (S.layers.length + 1), visible: true,
                     opacity: 1, blend: "normal", clip: false, alphaLock: false,
                     type: "vector", depth: insertDepth(), strokes: [] } });
  toast("ベクターレイヤー: 消しゴムで「交点まで消去」が使えます");
};
$("btnVecThin").onclick = () => {
  const lay = S.layers[S.active];
  if (!isVector(lay)) { toast("ベクターレイヤーを選んでください"); return; }
  localOp({ id: uid(), kind: "vecWidth", layer: lay.id, scale: 0.8 });
};
$("btnVecThick").onclick = () => {
  const lay = S.layers[S.active];
  if (!isVector(lay)) { toast("ベクターレイヤーを選んでください"); return; }
  localOp({ id: uid(), kind: "vecWidth", layer: lay.id, scale: 1.25 });
};
$("vecErase").onchange = (e) => { S.vecErase = e.target.value; savePrefs(); };
$("btnVecApplyStyle").onclick = () => {
  if (!S.vecSel) { toast("🔧線を編集ツールで線を選んでください"); return; }
  localOp({ id: uid(), kind: "vecStyle", layer: S.vecSel.layer, stroke: S.vecSel.stroke,
            props: { color: S.color, size: S.size } });
  toast("選択中の線を今の色・太さにしました");
};
$("btnVecDelete").onclick = () => {
  if (!S.vecSel) { toast("🔧線を編集ツールで線を選んでください"); return; }
  localOp({ id: uid(), kind: "vecDelete", layer: S.vecSel.layer, stroke: S.vecSel.stroke });
  S.vecSel = null;
};
$("btnAddFolder").onclick = () => {
  localOp({ id: uid(), kind: "addFolder", at: S.active + 1,
            layer: { id: "F" + uid(), name: "フォルダ", visible: true, opacity: 1,
                     blend: "normal", clip: false, type: "folder",
                     depth: insertDepth(), open: true } });
};
$("btnGroup").onclick = () => {
  const e = S.layers[S.active];
  if (!e) return;
  const name = e.type === "folder" ? "グループ" : (e.name + " グループ");
  localOp({ id: uid(), kind: "groupLayer", layer: e.id, folderId: "F" + uid(), name });
  toast("フォルダにまとめました");
};
$("btnIndent").onclick = () => {
  const e = S.layers[S.active];
  if (!e) return;

  let host = null;
  for (let j = S.active - 1; j >= 0; j--) {
    if (S.layers[j].depth < e.depth) break;
    if (S.layers[j].depth === e.depth) { host = S.layers[j]; break; }
  }
  if (!host) { toast("入れる先のフォルダが下にありません"); return; }

  localOp({ id: uid(), kind: "setDepth", layer: e.id, depth: e.depth + 1,
            prevDepth: e.depth });
};
$("layerSwing").onchange = (e) => {
  S.layerSwing = e.target.checked; savePrefs();
  toast(S.layerSwing ? "ドラッグを左右に振ってフォルダに出し入れ: 入" : "ドラッグを左右に振ってフォルダに出し入れ: 切");
};
$("btnOutdent").onclick = () => {
  const e = S.layers[S.active];
  if (!e || e.depth === 0) { toast("これ以上外に出せません"); return; }
  localOp({ id: uid(), kind: "setDepth", layer: e.id, depth: e.depth - 1,
            prevDepth: e.depth });
};
$("btnAddAdjust").onclick = () => {
  localOp({ id: uid(), kind: "addAdjust", at: S.active + 1,
            layer: { id: "A" + uid(), name: "調整", visible: true, opacity: 1,
                     blend: "normal", clip: false, type: "adjust",
                     depth: insertDepth(), filter: "hsv",

                     params: { h: 0, s: 0, v: 0, color: S.color, sub: S.sub } } });
  const lay = S.layers[S.active];
  if (lay && lay.type === "adjust") openAdjustEditor(lay);
};

function openAdjustEditor(lay) {
  const def = FILTERS[lay.filter] || FILTERS.hsv;
  S.adjSession = { id: lay.id, filter: lay.filter, params: { ...lay.params } };
  $("adjTitle").textContent = "◐ " + lay.name;
  $("adjFilter").innerHTML = "";
  for (const [k, d] of Object.entries(FILTERS)) $("adjFilter").add(new Option(d.name, k));
  $("adjFilter").value = lay.filter;
  buildAdjustParams();
  togglePanel("adjustPanel");
}
function buildAdjustParams() {
  const s = S.adjSession;
  if (!s) return;
  const def = FILTERS[s.filter];
  const box = $("adjParams");
  box.innerHTML = "";
  const applyLive = () => {
    const lay = layerById(s.id);
    if (lay) { lay.filter = s.filter; lay.params = { ...s.params }; touch(); requestRender(); }
  };
  if (def.curve) { buildCurveWidget(box, s.params, applyLive); return; }
  for (const p of def.params) {
    if (s.params[p.k] === undefined) s.params[p.k] = p.def;
    const row = document.createElement("label");
    row.className = "slider";
    const val = document.createElement("span");
    val.className = "num";
    val.textContent = s.params[p.k];
    const inp = document.createElement("input");
    inp.type = "range"; inp.min = p.min; inp.max = p.max; inp.value = s.params[p.k];
    inp.oninput = () => {
      s.params[p.k] = +inp.value;
      val.textContent = inp.value;
      const lay = layerById(s.id);
      if (lay) { lay.filter = s.filter; lay.params = { ...s.params }; touch(); requestRender(); }
    };
    row.append(document.createTextNode(p.label + " "), inp, val);
    box.appendChild(row);
  }
  if (!def.params.length)
    box.appendChild(Object.assign(document.createElement("small"),
      { className: "hint", textContent: "このフィルタに調整項目はありません" }));
}
$("adjFilter").onchange = (e) => {
  const s = S.adjSession;
  if (!s) return;
  s.filter = e.target.value;

  s.params = { color: s.params.color || S.color, sub: s.params.sub || S.sub };
  buildAdjustParams();
  const lay = layerById(s.id);
  if (lay) { lay.filter = s.filter; lay.params = { ...s.params }; touch(); requestRender(); }
};
$("adjApply").onclick = () => {
  const s = S.adjSession;
  if (!s) return;
  S.adjSession = null;
  $("adjustPanel").classList.add("hidden");
  const cur = layerById(s.id);
  sendOp({ id: uid(), kind: "setAdjust", layer: s.id, filter: s.filter, params: s.params,
           prevFilter: cur ? cur.filter : undefined,
           prevParams: cur ? cur.params : undefined });
};



function restoreMetaOf(lay) {
  const m = { id: lay.id, name: lay.name, visible: lay.visible, opacity: lay.opacity,
              blend: lay.blend, clip: !!lay.clip, alphaLock: !!lay.alphaLock,
              type: lay.type || "raster", depth: lay.depth || 0 };
  if (lay.type === "text") m.text = lay.text;
  if (lay.type === "doll") m.doll = lay.doll;
  if (lay.type === "vector") m.strokes = lay.strokes;
  if (lay.type === "adjust") { m.filter = lay.filter; m.params = lay.params; }
  if (lay.isRef) m.isRef = true;
  return m;
}
$("btnDelLayer").onclick = () => {
  if (S.layers.length <= 1) { toast("最後のレイヤーは削除できません"); return; }
  const lay = S.layers[S.active];
  if (!confirm(`「${lay.name}」を削除しますか?`)) return;
  localOp({ id: uid(), kind: "delLayer", layer: lay.id, at: S.active,
            layerMeta: restoreMetaOf(lay) });
};
$("btnDupLayer").onclick = () => {
  const lay = S.layers[S.active];
  if (!lay) return;


  if (lay.type === "folder") { toast("フォルダは複製できません(中身ごとの複製は未対応)"); return; }
  localOp({ id: uid(), kind: "dupLayer", layer: lay.id, newId: "L" + uid() });
};
$("btnMergeDown").onclick = () => {
  if (S.active <= 0) { toast("いちばん下のレイヤーです"); return; }
  const lay = S.layers[S.active], below = S.layers[S.active - 1];




  if (!below || !below.ctx || isText(below) || isDoll(below)) {
    toast(isText(below) ? "テキストレイヤーには結合できません(先に「絵に変換」を)"
        : isDoll(below) ? "デッサン人形のレイヤーには結合できません"
        : "下が絵のレイヤーではないので結合できません");
    return;
  }
  localOp({ id: uid(), kind: "mergeDown", layer: lay.id, at: S.active,
            layerMeta: restoreMetaOf(lay) });
};
$("btnClearLayer").onclick = () => {
  const lay = S.layers[S.active];
  if (lay) localOp({ id: uid(), kind: "clearLayer", layer: lay.id, target: activeTarget(),
                     sel: S.sel || undefined });
};
$("btnFlipH").onclick = () => {
  const lay = S.layers[S.active];
  if (lay) localOp({ id: uid(), kind: "flipLayer", layer: lay.id, target: activeTarget(), axis: "h" });
};
$("btnFlipV").onclick = () => {
  const lay = S.layers[S.active];
  if (lay) localOp({ id: uid(), kind: "flipLayer", layer: lay.id, target: activeTarget(), axis: "v" });
};
$("btnMask").onclick = () => {
  const lay = S.layers[S.active];
  if (!lay) return;
  localOp({ id: uid(), kind: "setMask", layer: lay.id, on: !lay.hasMask });
  if (lay.hasMask === false) S.maskEdit = false;
};
$("btnLayerUp").onclick = () => moveActive(1);
$("btnLayerDown").onclick = () => moveActive(-1);

function moveActive(d) {
  const i = S.active;
  const e = S.layers[i];
  if (!e) return;
  const dep = e.depth;
  if (d > 0) {
    const nxt = skipSubtree(i);
    if (nxt >= S.layers.length || S.layers[nxt].depth < dep) {
      toast("この階層ではいちばん上です"); return;
    }
    const to = skipSubtree(nxt);
    localOp({ id: uid(), kind: "moveLayer", layer: e.id, to, from: i, depth: dep });
  } else {
    let p = -1;
    for (let j = i - 1; j >= 0; j--) {
      if (S.layers[j].depth < dep) break;
      if (S.layers[j].depth === dep) { p = j; break; }
    }
    if (p < 0) { toast("この階層ではいちばん下です"); return; }
    localOp({ id: uid(), kind: "moveLayer", layer: e.id, to: p, from: i, depth: dep });
  }
}
let opSliderPrev = null;
$("layerOpacity").onpointerdown = () => { opSliderPrev = S.layers[S.active]?.opacity ?? null; };
$("layerOpacity").oninput = (e) => {
  const lay = S.layers[S.active];
  $("layerOpacityVal").textContent = e.target.value;
  if (lay) { lay.opacity = e.target.value / 100; touch(); requestRender(); }
};
$("layerOpacity").onchange = (e) => {
  const lay = S.layers[S.active];
  if (!lay) return;
  const prev = opSliderPrev ?? lay.opacity;
  opSliderPrev = null;
  const op = { id: uid(), kind: "setLayer", layer: lay.id,
               props: { opacity: e.target.value / 100 }, prev: { opacity: prev } };
  lay.opacity = op.props.opacity;
  pushHistory(op.id, "不透明度", () => { lay.opacity = prev; rebuildLayerList(); requestRender(); });
  sendOp(op);
  requestRender();
};
$("layerBlend").onchange = (e) => {
  const lay = S.layers[S.active];
  if (lay) localOp({ id: uid(), kind: "setLayer", layer: lay.id,
                     props: { blend: e.target.value }, prev: { blend: lay.blend } });
};
$("layerClip").onchange = (e) => {
  const lay = S.layers[S.active];
  if (!lay) return;
  if (layerIndex(lay.id) === 0 && e.target.checked) {
    e.target.checked = false; toast("いちばん下のレイヤーはクリップできません"); return;
  }
  localOp({ id: uid(), kind: "setLayer", layer: lay.id,
            props: { clip: e.target.checked }, prev: { clip: lay.clip } });
};
$("layerLock").onchange = (e) => {
  const lay = S.layers[S.active];
  if (lay) localOp({ id: uid(), kind: "setLayer", layer: lay.id,
                     props: { alphaLock: e.target.checked }, prev: { alphaLock: lay.alphaLock } });
};
$("layerRef").onchange = (e) => {
  const lay = S.layers[S.active];
  if (!lay) return;
  localOp({ id: uid(), kind: "setLayer", layer: lay.id,
            props: { isRef: e.target.checked }, prev: { isRef: !!lay.isRef } });
  if (e.target.checked && S.fillRef !== "ref") {
    S.fillRef = "ref"; $("fillRef").value = "ref"; savePrefs();
    toast("塗りつぶしの参照を「参照レイヤー」に切り替えました");
  }
};


function selectAll() { setSel({ type: "rect", x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h }); }
function invertSel() {
  if (!S.sel) { selectAll(); return; }
  setSel({ ...S.sel, invert: !S.sel.invert });
}
$("selModeUI").onchange = (e) => { S.selModeUI = e.target.value; savePrefs(); };
$("selFeather").oninput = (e) => {
  S.selFeather = +e.target.value; $("selFeatherVal").textContent = e.target.value;
  refreshSelEdge();
};
$("selGrow").oninput = (e) => {
  S.selGrow = +e.target.value; $("selGrowVal").textContent = e.target.value;
  refreshSelEdge();
};
$("btnSelAll").onclick = selectAll;
$("btnSelInv").onclick = invertSel;
$("btnDesel").onclick = () => setSel(null);
$("btnSelNone").onclick = () => setSel(null);


function openFilter(key, isGen) {
  const lay = S.layers[S.active];
  if (!lay) return;
  const def = (isGen ? GENERATORS : FILTERS)[key];
  const ctx = targetCtxOf(lay, activeTarget());


  if (!ctx) {
    toast(lay.type === "folder" ? "フォルダには使えません。絵のレイヤーを選んでください"
        : lay.type === "adjust" ? "調整レイヤーには使えません。絵のレイヤーを選んでください"
        : "このレイヤーには使えません");
    return;
  }

  const box = (!isGen && S.sel) ? selBBox(S.sel) : { x0: 0, y0: 0, x1: S.doc.w, y1: S.doc.h };


  S.fxSession = { key, isGen, ctx, snap: grabSnap(ctx, box), params: {},
                  target: activeTarget(), opId: uid() };
  for (const p of def.params) S.fxSession.params[p.k] = p.def;

  S.fxSession.params.color = S.color;
  S.fxSession.params.sub = S.sub;
  const box2 = $("fxParams");
  box2.innerHTML = "";
  $("fxTitle").textContent = def.name;
  if (def.curve) {
    buildCurveWidget(box2, S.fxSession.params, previewFilter);
    togglePanel("fxPanel");
    previewFilter();
    return;
  }
  for (const p of def.params) {
    const row = document.createElement("label");
    row.className = "slider";
    const val = document.createElement("span");
    val.className = "num";
    val.textContent = p.def;
    const inp = document.createElement("input");
    inp.type = "range"; inp.min = p.min; inp.max = p.max; inp.value = p.def;
    inp.oninput = () => {
      S.fxSession.params[p.k] = +inp.value;
      val.textContent = inp.value;
      previewFilter();
    };
    row.append(document.createTextNode(p.label + " "), inp, val);
    box2.appendChild(row);
  }
  const note = { gradmap: "描画色→サブ色のランプを適用します(🎨で色を変更)",
                 lum2alpha: "線は現在の描画色になります",
                 halftone: "描画色のドットになります",
                 speed: "描画色で描かれます。中心はキャンバス中央(あとで⤢変形で動かせます)",
                 outline: "このレイヤーの絵の外側に描画色のフチを付けます",
                 frame: "描画色で外枠を描きます" }[key];
  if (note) box2.appendChild(Object.assign(document.createElement("small"),
    { className: "hint", textContent: note }));
  togglePanel("fxPanel");
  previewFilter();
}


function buildCurveWidget(container, params, onChange) {
  if (!params.pts) params.pts = [[0, 0], [255, 255]];
  if (!params.ch) params.ch = "rgb";
  const wrap = document.createElement("div");
  const chRow = document.createElement("div");
  chRow.className = "row btnRow";
  for (const [k, label] of [["rgb", "RGB"], ["r", "R"], ["g", "G"], ["b", "B"]]) {
    const b = document.createElement("button");
    b.textContent = label;
    b.className = params.ch === k ? "active" : "";
    b.onclick = () => {
      params.ch = k;
      for (const x of chRow.children) x.className = "";
      b.className = "active";
      onChange();
    };
    chRow.appendChild(b);
  }
  const cv = document.createElement("canvas");
  cv.width = cv.height = 220;
  cv.className = "curveBox";
  const cx = cv.getContext("2d");
  const draw = () => {
    cx.fillStyle = "#22242b"; cx.fillRect(0, 0, 220, 220);
    cx.strokeStyle = "#3d4048"; cx.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      cx.beginPath(); cx.moveTo(i * 55, 0); cx.lineTo(i * 55, 220); cx.stroke();
      cx.beginPath(); cx.moveTo(0, i * 55); cx.lineTo(220, i * 55); cx.stroke();
    }
    cx.strokeStyle = "#555"; cx.beginPath(); cx.moveTo(0, 220); cx.lineTo(220, 0); cx.stroke();

    const probe = new Uint8ClampedArray(256 * 4);
    for (let v = 0; v < 256; v++) { probe[v * 4] = v; probe[v * 4 + 3] = 255; }
    FX.curve(probe, params.pts, "r");
    cx.strokeStyle = params.ch === "r" ? "#e94f4f" : params.ch === "g" ? "#7ed321"
                    : params.ch === "b" ? "#4a90d9" : "#fff";
    cx.lineWidth = 2;
    cx.beginPath();
    for (let v = 0; v < 256; v++) {
      const x = v / 255 * 220, y = 220 - probe[v * 4] / 255 * 220;
      v ? cx.lineTo(x, y) : cx.moveTo(x, y);
    }
    cx.stroke();
    for (const p of params.pts) {
      cx.beginPath();
      cx.arc(p[0] / 255 * 220, 220 - p[1] / 255 * 220, 5, 0, 7);
      cx.fillStyle = "#fff"; cx.fill();
      cx.strokeStyle = "#222"; cx.lineWidth = 1; cx.stroke();
    }
  };
  let drag = null;
  const toVal = (e) => {
    const r = cv.getBoundingClientRect();
    return [clamp(Math.round((e.clientX - r.left) / r.width * 255), 0, 255),
            clamp(Math.round(255 - (e.clientY - r.top) / r.height * 255), 0, 255)];
  };
  cv.addEventListener("pointerdown", (e) => {
    try { cv.setPointerCapture(e.pointerId); } catch (err) {}
    const [vx, vy] = toVal(e);
    let hit = -1;
    params.pts.forEach((p, i) => {
      if (Math.abs(p[0] - vx) < 14 && Math.abs(p[1] - vy) < 20) hit = i;
    });
    if (e.shiftKey && hit >= 0 && params.pts.length > 2) {
      params.pts.splice(hit, 1); draw(); onChange(); return;
    }
    if (hit < 0) { params.pts.push([vx, vy]); params.pts.sort((a, b) => a[0] - b[0]);
                   hit = params.pts.findIndex((p) => p[0] === vx && p[1] === vy); }
    drag = hit;
    draw(); onChange();
  });
  cv.addEventListener("pointermove", (e) => {
    if (drag === null) return;
    const [vx, vy] = toVal(e);
    const isEnd = drag === 0 || drag === params.pts.length - 1;
    params.pts[drag] = [isEnd ? params.pts[drag][0] : vx, vy];
    draw(); onChange();
  });
  const up = () => { drag = null; };
  cv.addEventListener("pointerup", up);
  cv.addEventListener("pointercancel", up);
  const reset = document.createElement("button");
  reset.textContent = "カーブをリセット";
  reset.onclick = () => { params.pts = [[0, 0], [255, 255]]; draw(); onChange(); };
  wrap.append(chRow, cv, reset);
  container.appendChild(wrap);
  draw();
  const note = document.createElement("small");
  note.className = "hint";
  note.textContent = "クリックで制御点を追加、ドラッグで移動、Shift+クリックで削除。" +
                     "左下を上げると暗部が明るく、右上を下げると明部が暗くなります。";
  container.appendChild(note);
}
function previewFilter() {
  const s = S.fxSession;
  if (!s) return;
  putSnap(s.ctx, s.snap);
  const seed = hashSeed(s.opId);
  if (s.isGen) runGen(s.ctx, s.key, s.params, S.sel, seed);
  else {
    const res = runFilter(s.ctx, s.key, s.params, S.sel, seed);
    if (res) writeFiltered(s.ctx, res, S.sel);
  }
  touch();
  requestRender();
}
$("fxApply").onclick = () => {
  const s = S.fxSession;
  if (!s) return;
  putSnap(s.ctx, s.snap);
  S.fxSession = null;
  $("fxPanel").classList.add("hidden");
  const base = { id: s.opId, layer: S.layers[S.active].id, target: s.target,
                 params: s.params, sel: S.sel || undefined };
  localOp(s.isGen ? { ...base, kind: "gen", gen: s.key }
                  : { ...base, kind: "filter", filter: s.key });
};
$("fxCancel").onclick = () => {
  const s = S.fxSession;
  if (!s) return;
  putSnap(s.ctx, s.snap);
  S.fxSession = null;
  $("fxPanel").classList.add("hidden");
  requestRender();
};
function buildFilterMenu() {
  const box = $("filterList");
  box.innerHTML = "";
  for (const [key, def] of Object.entries(FILTERS)) {
    const b = document.createElement("button");
    b.textContent = def.name;
    b.onclick = () => openFilter(key, false);
    box.appendChild(b);
  }
  const gbox = $("genList");
  gbox.innerHTML = "";
  for (const [key, def] of Object.entries(GENERATORS)) {
    const b = document.createElement("button");
    b.textContent = def.name;
    b.onclick = () => openFilter(key, true);
    gbox.appendChild(b);
  }
}



function layerPayload(l, dataCanvas) {
  const o = { id: l.id, name: l.name, visible: l.visible, opacity: l.opacity,
              blend: l.blend, clip: !!l.clip, type: l.type || "raster",
              depth: l.depth || 0, open: l.open !== false, isRef: !!l.isRef,
              alphaLock: !!l.alphaLock };







  if (l.type === "vector") o.strokes = l.strokes;
  if (l.type === "text") o.text = l.text;
  if (l.type === "doll") o.doll = l.doll;
  if (l.type === "adjust") { o.filter = l.filter; o.params = l.params; }


  if (l.hasMask && l.mask) o.maskData = l.mask.toDataURL("image/png");
  if (dataCanvas) o.data = dataCanvas.toDataURL("image/png");
  return o;
}


async function commitDoc(newW, newH, transform, label, extra, ptMap, sizeScale) {
  toast(label + "…");
  const layers = [];
  for (const l of S.layers) {
    if (!isRaster(l)) { layers.push(layerPayload(l, null)); continue; }
    const c = makeCanvas(newW, newH), cx = c.getContext("2d");
    transform(cx, l, l.canvas);
    const p = layerPayload(l, c);


    if (l.hasMask && l.mask) {
      const mc = makeCanvas(newW, newH);
      transform(mc.getContext("2d"), l, l.mask);
      p.maskData = mc.toDataURL("image/png");
    }
    if (isVector(l) && (ptMap || sizeScale)) {
      const k = sizeScale || 1;
      p.strokes = l.strokes.map((s) => ({
        ...s, size: s.size * k,
        pts: s.pts.map((q) => {
          const r = ptMap ? ptMap(q[0], q[1]) : [q[0], q[1]];

          return [Math.round(r[0] * 100) / 100, Math.round(r[1] * 100) / 100, q[2], ...q.slice(3)];
        }),
      }));
    }
    layers.push(p);
  }
  if (extra) layers.push(...[].concat(extra));
  const r = await fetch("/api/commit", { method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ w: newW, h: newH, layers, label }) });
  if (!r.ok) { toast("失敗: " + (await r.json()).error); return; }
  toast(label + " 完了");
}
$("btnResize").onclick = async () => {
  const w = parseInt($("cvW").value, 10), h = parseInt($("cvH").value, 10);
  if (!(w > 0 && h > 0 && w <= 8000 && h <= 8000)) { toast("サイズが不正です"); return; }
  const fit = $("cvFit").checked;
  const k = fit ? Math.min(w / S.doc.w, h / S.doc.h) : 1;

  const mid = fit || $("cvAnchor").value === "c";
  const ox = mid ? (w - S.doc.w * k) / 2 : 0, oy = mid ? (h - S.doc.h * k) / 2 : 0;
  await commitDoc(w, h, (cx, l, src) => {
    cx.imageSmoothingQuality = "high";
    cx.drawImage(src, ox, oy, S.doc.w * k, S.doc.h * k);
  }, fit ? "拡大縮小" : "キャンバスサイズ変更",
     null, (x, y) => [x * k + ox, y * k + oy], k);
};
$("btnCrop").onclick = async () => {
  if (!S.sel) { toast("先に選択範囲を作ってください"); return; }
  const b = selBBox(S.sel);
  const w = b.x1 - b.x0, h = b.y1 - b.y0;
  if (w < 8 || h < 8) { toast("選択範囲が小さすぎます"); return; }
  await commitDoc(w, h, (cx, l, src) => cx.drawImage(src, -b.x0, -b.y0), "トリミング",
                  null, (x, y) => [x - b.x0, y - b.y0], 1);
};

$("cvSwap").onclick = () => { const w = $("cvW").value; $("cvW").value = $("cvH").value; $("cvH").value = w; };
$("cvPreset").onchange = (e) => {
  const m = /^(\d+)x(\d+)$/.exec(e.target.value);
  if (m) { $("cvW").value = m[1]; $("cvH").value = m[2]; }
  e.target.value = "";
};
$("cvW").addEventListener("input", () => {
  const w = parseInt($("cvW").value, 10);
  if ($("cvKeepAspect").checked && w > 0) $("cvH").value = Math.max(1, Math.round(w * S.doc.h / S.doc.w));
});
$("cvH").addEventListener("input", () => {
  const h = parseInt($("cvH").value, 10);
  if ($("cvKeepAspect").checked && h > 0) $("cvW").value = Math.max(1, Math.round(h * S.doc.w / S.doc.h));
});
$("btnFitContent").onclick = async () => {
  compositeInto(scratchCtx);
  const b = contentBBox(scratchCtx);
  if (!b) { toast("見えている絵がありません"); return; }
  const w = b.x1 - b.x0, h = b.y1 - b.y0;
  if (w === S.doc.w && h === S.doc.h) { toast("もう絵のある所ぴったりです"); return; }
  await commitDoc(w, h, (cx, l, src) => cx.drawImage(src, -b.x0, -b.y0), "絵のある所に合わせる",
                  null, (x, y) => [x - b.x0, y - b.y0], 1);
};
$("btnFlatten").onclick = async () => {
  if (!confirm("すべてのレイヤーを1枚に統合しますか?")) return;
  compositeInto(scratchCtx);
  const flat = makeCanvas();
  flat.getContext("2d").drawImage(scratch, 0, 0);
  const r = await fetch("/api/commit", { method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ w: S.doc.w, h: S.doc.h, label: "統合", layers: [
      { id: "p0", name: "統合", visible: true, opacity: 1, blend: "normal",
        clip: false, data: flat.toDataURL("image/png") }] }) });
  toast(r.ok ? "統合しました" : "統合に失敗");
};


let hue = 0, sat = 0.85, val = 0.25;
let colorTargetSub = false;
function setColor(hex, skipHsv) {
  if (colorTargetSub) {
    S.sub = hex;
    $("subChip").style.background = hex;
  } else {
    S.color = hex;
    $("colorChip").style.background = hex;
    const qc = $("quickCur"); if (qc) qc.style.background = hex;
    const qh = $("quickHex"); if (qh) qh.textContent = hex;
  }
  if (!skipHsv) [hue, sat, val] = rgbToHsv(...hexRgb(hex));
  const hx = $("hexInput");
  if (hx && document.activeElement !== hx) hx.value = hex;
  drawSv(); drawHue();
  drawQuickPicker();
}
function drawSv() {
  const c = $("svBox").getContext("2d");
  const w = 220, h = 160;
  const [r, g, b] = hsvToRgb(hue, 1, 1);
  const gx = c.createLinearGradient(0, 0, w, 0);
  gx.addColorStop(0, "#fff"); gx.addColorStop(1, rgbHex(r, g, b));
  c.fillStyle = gx; c.fillRect(0, 0, w, h);
  const gy = c.createLinearGradient(0, 0, 0, h);
  gy.addColorStop(0, "rgba(0,0,0,0)"); gy.addColorStop(1, "#000");
  c.fillStyle = gy; c.fillRect(0, 0, w, h);
  c.strokeStyle = val > 0.5 ? "#000" : "#fff";
  c.lineWidth = 2;
  c.beginPath(); c.arc(sat * w, (1 - val) * h, 7, 0, 7); c.stroke();
}
function drawHue() {
  const c = $("hueBar").getContext("2d");
  const w = 220, h = 18;
  const g = c.createLinearGradient(0, 0, w, 0);
  for (let i = 0; i <= 6; i++) g.addColorStop(i / 6, rgbHex(...hsvToRgb(i * 60, 1, 1)));
  c.fillStyle = g; c.fillRect(0, 0, w, h);
  c.strokeStyle = "#fff"; c.lineWidth = 2;
  c.strokeRect(hue / 360 * w - 2, 0, 4, h);
}
function bindPickerCanvas(el, fn) {
  const move = (e) => {
    const r = el.getBoundingClientRect();
    fn(clamp((e.clientX - r.left) / r.width, 0, 1), clamp((e.clientY - r.top) / r.height, 0, 1));
  };
  el.addEventListener("pointerdown", (e) => {
    try { el.setPointerCapture(e.pointerId); } catch (err) {}
    move(e);
    const mv = (ev) => move(ev);
    const up = () => { el.removeEventListener("pointermove", mv); el.removeEventListener("pointerup", up); };
    el.addEventListener("pointermove", mv);
    el.addEventListener("pointerup", up);
  });
}
bindPickerCanvas($("svBox"), (x, y) => {
  sat = x; val = 1 - y;
  setColor(rgbHex(...hsvToRgb(hue, sat, val)), true); saveRecent();
});
bindPickerCanvas($("hueBar"), (x) => {
  hue = x * 360;
  setColor(rgbHex(...hsvToRgb(hue, sat, val)), true); saveRecent();
});
$("hexInput").onchange = (e) => {
  let v = e.target.value.trim();
  if (!v.startsWith("#")) v = "#" + v;
  if (/^#[0-9a-fA-F]{6}$/.test(v)) { setColor(v.toLowerCase()); saveRecent(); }
  else e.target.value = colorTargetSub ? S.sub : S.color;
};
$("btnSwapColor").onclick = () => {
  const a = S.color; S.color = S.sub; S.sub = a;
  $("colorChip").style.background = S.color;
  $("subChip").style.background = S.sub;
  requestRender();
};
$("colorTargetMain").onclick = () => { colorTargetSub = false; markColorTarget(); };
$("colorTargetSub").onclick = () => { colorTargetSub = true; markColorTarget(); };
function markColorTarget() {
  $("colorTargetMain").classList.toggle("active", !colorTargetSub);
  $("colorTargetSub").classList.toggle("active", colorTargetSub);
  const cur = colorTargetSub ? S.sub : S.color;
  [hue, sat, val] = rgbToHsv(...hexRgb(cur));
  $("hexInput").value = cur;
  drawSv(); drawHue();
}
const PALETTE = ["#000000", "#ffffff", "#e94f4f", "#f5a623", "#f8e71c",
                 "#7ed321", "#4a90d9", "#9013fe", "#f7b8c2", "#8b572a",
                 "#f2d5b8", "#5a3d2b"];
let recent = [];
try { recent = JSON.parse(localStorage.getItem("sp_recent") || "[]"); } catch (e) {}



const HIST_MAX = 18;
let pinned = [];
try { pinned = JSON.parse(localStorage.getItem("sp_pinned") || "[]"); } catch (e) {}
if (!Array.isArray(pinned)) pinned = [];
if (!Array.isArray(recent)) recent = [];
function saveRecent() {}
function colorHistory() {
  return [...pinned, ...recent.filter((c) => !pinned.includes(c))].slice(0, HIST_MAX);
}


try {
  if (!localStorage.getItem("sp_seeded")) {
    recent = [...recent.filter((c) => !PALETTE.includes(c)), ...PALETTE].slice(0, HIST_MAX);
    localStorage.setItem("sp_seeded", "1");
    localStorage.setItem("sp_recent", JSON.stringify(recent));
  }
} catch (e) {}
function storeColors() {
  try {
    localStorage.setItem("sp_recent", JSON.stringify(recent));
    localStorage.setItem("sp_pinned", JSON.stringify(pinned));
  } catch (e) {}
}
function noteUsedColor(c) {
  if (typeof c !== "string" || !/^#[0-9a-f]{6}$/i.test(c)) return;
  c = c.toLowerCase();
  if (pinned.includes(c) || recent[0] === c) return;

  recent = [c, ...recent.filter((x) => x !== c)].slice(0, HIST_MAX);
  storeColors(); buildSwatches();
}
function setPinned(c, on) {
  c = c.toLowerCase();
  pinned = pinned.filter((x) => x !== c);
  if (on) pinned = [...pinned, c].slice(-HIST_MAX);
  storeColors(); buildSwatches();
}
function dropColor(c) {
  c = c.toLowerCase();
  pinned = pinned.filter((x) => x !== c);
  recent = recent.filter((x) => x !== c);
  storeColors(); buildSwatches();
}
function buildSwatches() {
  const box = $("swatches");
  box.innerHTML = "";
  for (const col of colorHistory()) {
    const d = document.createElement("div");
    d.className = "sw";
    d.style.background = col;
    d.onclick = () => setColor(col);
    box.appendChild(d);
  }
  syncQuick();
}


function updateHistoryPanel() {
  const box = $("historyList");
  if (!box || $("historyPanel").classList.contains("hidden")) return;
  box.innerHTML = "";

  const labels = [...(S.pastSteps || []), ...S.history.map((h) => h.label)].reverse();
  labels.forEach((label, ri) => {
    const d = document.createElement("div");
    d.className = "histItem";
    d.textContent = label || "操作";
    d.onclick = () => reqUndo(ri + 1);
    box.appendChild(d);
  });
  if (!labels.length) box.innerHTML = '<small class="hint">履歴はまだありません</small>';
}


function setTool(t) {
  if (S.xform && t !== "transform") commitTransform(true);
  S.tool = t;
  $("btnTool").textContent = TOOLS[t].icon;
  $("btnTool").title = TOOLS[t].name;
  for (const b of document.querySelectorAll("#toolGrid button"))
    b.classList.toggle("active", b.dataset.tool === t);
  $("toolPanel").classList.add("hidden");
  syncQuick();
  requestRender();
}
const TOOL_DESC = {
  brush: "ふつうに描きます。太さ・濃度は下のバー、硬さや混色は⚙️で。",
  eraser: "消します。ベクターレイヤーでは「交点まで消去」になります。",
  blur: "なぞった所をぼかします。",
  smudge: "指で伸ばしたように色を引きずります。",
  fill: "囲まれた範囲を塗ります。線画を🔎参照に指定し、隙間閉じを上げると漏れません。",
  enclose: "ドラッグで囲むと、その中の閉じた領域をまとめて塗ります。",
  gapfill: "なぞった所の塗り残しだけを埋めます。線の上と外には塗りません。",
  gradient: "ドラッグした向きにグラデーションを描きます。",
  line: "まっすぐな線を引きます。", rect: "四角い枠を描きます。",
  ellipse: "楕円の枠を描きます。",
  text: "文字を置きます。あとから何度でも書き直せるテキストレイヤーになります。",
  stamp: "✨素材パネルで選んだ形を置きます。中心から引っぱると大きさと向きが決まります。",
  doll: "デッサン人形の関節(白い丸)をつまんで動かします。動かした先も一緒に付いてきます。",
  balloon: "しっぽ付きのフキダシを描きます。",
  transform: "選択範囲(なければ絵全体)を動かす・拡大・回転します。",
  move: "レイヤーの絵をまるごと動かします。",
  grab: "つかんで動かします。選んでいるレイヤーの絵の上をつかむと、そのレイヤーだけが動きます。絵の外をつかんだ時と、レイヤーを選んでいない時は、画面が動きます。",
  picker: "画面の色を拾います。長押しでも同じことができます。",
  vecedit: "ベクターの線をタップして選び、白丸をドラッグで形を変えます。",
  selrect: "四角く選択します。Shiftで追加、Altで削除。",
  lasso: "囲んで選択します。Shiftで追加、Altで削除。",
  wand: "クリックした色の範囲を自動で選択します。",
  hand: "画面を動かします(拡大位置の変更)。",
};
function buildToolGrid() {
  const grid = $("toolGrid");
  grid.innerHTML = "";
  for (const [key, def] of Object.entries(TOOLS)) {
    const b = document.createElement("button");
    b.dataset.tool = key;
    b.innerHTML = `<span>${def.icon}</span><small>${def.name}</small>`;
    b.dataset.tipHead = def.name;
    b.dataset.tip = TOOL_DESC[key] || "";
    b.onclick = () => {
      setTool(key);
      if (key === "transform") beginTransform();

      if (key === "stamp") $("matPanel").classList.remove("hidden");
    };
    grid.appendChild(b);
  }
}
const PRESET_DESC = {
  pen: "均一で硬い線。線画の基本。",
  gpen: "描き始めが細く入り、抜きが長い。漫画の主線の定番。",
  mapen: "細くて硬い。まつげ・髪の毛など細部用。",
  pencil: "紙の目が出るざらついた線。ラフ・下描き向き。",
  brush: "下の色を拾って混ぜる水彩。にじませる塗り。",
  opaque: "少しだけ混ざる厚塗り用。塗り重ねが効く。",
  flat: "平たい筆。角度がついているので、向きで太さが変わる。",
  chalk: "強い紙の目とゆらぎ。パステル・質感づけに。",
  air: "ふんわり。影・グラデーション向き。",
  marker: "重ねると濃くなる半透明。カラーラフに。",
  dots: "点が散る。ハイライトや質感の点描に。",
  kabura: "強弱が出にくい均一な線。デフォルメ絵・枠線に。",
  milli: "筆圧で太さが変わらない線。背景・小物・図の線に。",
  smooth: "入り抜きがなめらか。髪や服の長い曲線の主線に。",
  fude: "軽い筆圧でも太くなり、抜きが長い。勢いのある線・和風の線に。",
  hairpen: "入りも抜きも長く細い。髪の毛・まつげを 1 本ずつ引く用。",
  calli: "斜めの平たいペン先。向きで太さが変わる文字・飾り線に。",
  kasure: "かすれた墨の線。筆の荒さを残したい線画に。",
  pencilD: "軽い筆圧でも濃く出る鉛筆。そのまま線画にも使える。",
  pencil6: "やわらかく太い芯。紙の目が強く出る。ラフ・陰影のあたりに。",
  sharp: "細く硬い芯。細かい下描き・設計図的なラフに。",
  colorp: "重ねて色を作る色鉛筆。紙の目が残るやさしい塗り。",
  charcoal: "寝かせた木炭。広い面をざっと暗くするデッサン向き。",
  crayon: "太さ一定でざらつく。子どもの絵・絵本風の塗りに。",
  pastel: "粉っぽくやわらかい面塗り。ふんわりした色のせに。",
  anime: "縁がくっきりで濃さ一定。アニメ塗りの影・下塗りの塗り残し埋めに。",
  roundH: "硬い丸ブラシ。筆圧で濃さが変わる、厚塗りの基本の 1 本。",
  roundS: "やわらかい丸ブラシ。なじませながら面を作る。",
  wash: "水を多く含んだにじみ。下の色とよく混ざる淡い重ね塗り。",
  flatW: "進む向きに穂先が向く水彩の平筆。広い面・空・布に。",
  gouache: "こってり不透明。少し混ざり、筆跡が残る厚塗り。",
  thick: "軽い筆圧で太く、下の色を拾って混ぜる。肌・髪の厚塗りに。",
  knife: "薄い刃で絵の具をのばす。岩・金属・布の面を切るように塗る。",
  alcohol: "重ねるほど濃くなる薄い色。コピック風の重ね塗り。",
  airH: "芯のあるエアブラシ。濃いめの影・発光の芯に。",
  airN: "粒の出るエアブラシ。肌や背景のざらっとした質感に。",
  blend: "下の色だけを引きずって混ぜる。塗りの境目をなじませる用。",
  dry: "絵の具の切れた筆。かすれた筆跡で質感を足す。",
  stipple: "小さな点を置いていく。肌理・砂・ハイライトの粒に。",
  glitter: "大小の点が広く散る。きらめき・雪・ほこりに。",
  square: "四角い穂先。建物・硬い物の面をかっちり塗る。",
};
function buildPresets() {
  const box = $("presetRow");
  box.innerHTML = "";
  let lastCat = null;
  for (const [key, p] of Object.entries(PRESETS)) {
    if (p.cat !== lastCat) {
      lastCat = p.cat;
      const h = document.createElement("div");
      h.className = "presetCat";
      h.textContent = PRESET_CATS[p.cat] || "";
      box.appendChild(h);
    }
    const b = document.createElement("button");
    b.textContent = p.name;
    b.dataset.tipHead = p.name;
    b.dataset.tip = PRESET_DESC[key] || "";
    b.onclick = () => applyPreset(key);
    box.appendChild(b);
  }
}
function applyPreset(key) {
  const p = PRESETS[key];
  if (!p) return;


  for (const k of PRESET_KEYS) S[k] = (k in p) ? p[k] : PRESET_DEFAULTS[k];
  const tu = S.taperUnitBy && S.taperUnitBy[key];
  if (tu === "px" || tu === "pct") S.taperUnit = tu;
  S.brushPreset = key;
  if (!["brush", "eraser"].includes(S.tool)) setTool("brush");
  syncBrushUI();
  savePrefs();
  toast("ブラシ: " + p.name);
}



const QUICK_COLOR_TOOLS = ["brush", "fill", "enclose", "gapfill", "gradient", "line", "rect",
                           "ellipse", "balloon", "text"];
const QUICK_TIPS = {
  eraser: [["かたい", { hard: 0.95, brushShape: "round" }], ["ふつう", { hard: 0.6, brushShape: "round" }],
           ["やわらか", { hard: 0.15, brushShape: "round" }], ["ざらざら", { hard: 0.6, brushShape: "texture" }]],
  blur:   [["やわらか", { hard: 0.1, brushShape: "round" }], ["ふつう", { hard: 0.5, brushShape: "round" }],
           ["かため", { hard: 0.9, brushShape: "round" }]],
  smudge: [["やわらか", { hard: 0.1, brushShape: "round" }], ["ふつう", { hard: 0.5, brushShape: "round" }],
           ["かため", { hard: 0.9, brushShape: "round" }]],
};




const QUICK_TOOLS = ["brush", "eraser", "blur", "grab", "fill", "picker"];
let quickDrag = false, quickDirty = false;
let quickPenScroll = { cat: null, top: 0 };
function drawSvOn(cv) {
  const c = cv.getContext("2d"), w = cv.width, h = cv.height;
  const [r, g, b] = hsvToRgb(hue, 1, 1);
  const gx = c.createLinearGradient(0, 0, w, 0);
  gx.addColorStop(0, "#fff"); gx.addColorStop(1, rgbHex(r, g, b));
  c.fillStyle = gx; c.fillRect(0, 0, w, h);
  const gy = c.createLinearGradient(0, 0, 0, h);
  gy.addColorStop(0, "rgba(0,0,0,0)"); gy.addColorStop(1, "#000");
  c.fillStyle = gy; c.fillRect(0, 0, w, h);
  c.strokeStyle = val > 0.5 ? "#000" : "#fff";
  c.lineWidth = 2;
  c.beginPath(); c.arc(sat * w, (1 - val) * h, 6, 0, 7); c.stroke();
}
function drawHueOn(cv) {
  const c = cv.getContext("2d"), w = cv.width, h = cv.height;
  const g = c.createLinearGradient(0, 0, w, 0);
  for (let i = 0; i <= 6; i++) g.addColorStop(i / 6, rgbHex(...hsvToRgb(i * 60, 1, 1)));
  c.fillStyle = g; c.fillRect(0, 0, w, h);
  c.strokeStyle = "#fff"; c.lineWidth = 2;
  c.strokeRect(hue / 360 * w - 2, 0, 4, h);
}
function drawQuickPicker() {
  const sv = $("qSv"), hb = $("qHue");
  if (sv) drawSvOn(sv);
  if (hb) drawHueOn(hb);
}

function quickVals() {
  const a = $("qSize"), b = $("qOp");
  if (a) { a.value = Math.round(S.size); $("qSizeVal").textContent = Math.round(S.size); }
  if (b) { b.value = Math.round(S.opacity * 100); $("qOpVal").textContent = Math.round(S.opacity * 100); }
  for (const [q, k] of [["qTaperIn", "taperIn"], ["qTaperOut", "taperOut"]]) {
    const el = $(q);
    if (el) { el.value = S[k] || 0; $(q + "Val").textContent = S[k] || 0; }
  }
}
function syncQuick() {
  const box = $("quickBox");
  if (!box) return;
  if (quickDrag) { quickDirty = true; return; }
  const t = S.tool, tips = QUICK_TIPS[t], cols = QUICK_COLOR_TOOLS.includes(t);
  const keep = box.scrollTop;
  box.classList.remove("hidden");
  box.classList.toggle("fold", !S.quickOn);
  box.innerHTML = "";
  const head = document.createElement("div");
  head.className = "qHead";
  if (S.quickOn) {
    const sp = document.createElement("span");
    sp.textContent = TOOLS[t] ? TOOLS[t].icon + " " + TOOLS[t].name : "";
    head.appendChild(sp);
  }
  const fb = document.createElement("button");
  fb.textContent = S.quickOn ? "◀" : "▶";
  fb.title = S.quickOn ? "たたむ（道具の列だけにする）" : "ペンの種類・色・太さをひらく";
  fb.onclick = () => { S.quickOn = !S.quickOn; savePrefs(); syncQuick(); };
  head.appendChild(fb);
  box.appendChild(head);

  const tools = document.createElement("div");
  tools.className = "qTools";
  for (const k of QUICK_TOOLS) {
    const b = document.createElement("button");
    b.textContent = TOOLS[k].icon;
    b.title = TOOLS[k].name + (TOOL_DESC[k] ? " — " + TOOL_DESC[k] : "");
    b.classList.toggle("hi", t === k);
    b.onclick = () => setTool(k);
    tools.appendChild(b);
  }
  box.appendChild(tools);

  if (t === "brush" || t === "eraser" || ["line", "rect", "ellipse"].includes(t)) {
    const row = document.createElement("div");
    row.className = "qRow2";
    if (t === "brush" || t === "eraser") {
      const sb = document.createElement("button");
      sb.className = "qSpread" + (S.spread ? " hi" : "");
      sb.textContent = S.quickOn ? "🧩 全体塗り" : "🧩";
      sb.title = "全体塗り（今は" + (S.spread ? "入" : "切") + "）: 入にすると、上から塗った線が、その場所で見えているパーツ(レイヤー)へ" +
                 "自動で振り分けられます。レイヤーを選ばなくても塗れます。隠れている部分には塗りません。消しゴムも同じです。" +
                 "ミニビューの中では、いつもそのパーツだけを塗ります。";
      sb.onclick = () => {
        S.spread = !S.spread; savePrefs(); syncQuick();
        toast(S.spread ? "全体塗り: 入（見えているパーツへ振り分けます）" : "全体塗り: 切（選んだレイヤーだけに塗ります）");
      };
      row.appendChild(sb);
    }

    const cb = document.createElement("button");
    cb.className = "qSpread" + (S.clipAll ? " hi" : "");
    cb.textContent = S.quickOn ? "✂️ 全体クリップ" : "✂️";
    cb.title = "全体クリッピング（今は" + (S.clipAll ? "入" : "切") + "）: 入にすると、選んだレイヤーに塗る線が、全体の絵の形" +
               "（見えているパーツ全部を重ねた輪郭）で切られます。選んだレイヤーの透明な所にも塗れますが、" +
               "キャラクターの外へははみ出しません。影やハイライト用のレイヤーを上に足して塗る時に使います。";
    cb.onclick = () => {
      S.clipAll = !S.clipAll; savePrefs(); syncQuick();
      toast(S.clipAll ? "全体クリッピング: 入（全体の絵の形の外には塗りません）" : "全体クリッピング: 切");
    };
    row.appendChild(cb);
    box.appendChild(row);
  }
  if (!S.quickOn) return;
  const hold = (el) => {
    el.addEventListener("pointerdown", () => { quickDrag = true; });
    const end = () => { quickDrag = false; if (quickDirty) { quickDirty = false; syncQuick(); } };
    el.addEventListener("pointerup", end);
    el.addEventListener("pointercancel", end);
  };
  const toMain = () => { if (colorTargetSub) { colorTargetSub = false; markColorTarget(); } };

  const sized = t === "brush" || tips || ["gapfill", "line", "rect", "ellipse", "balloon"].includes(t);
  const slider = (label, id, min, max, value, onIn) => {
    const l = document.createElement("label");
    l.className = "qSlider";
    const nm = document.createElement("span"); nm.textContent = label;
    const inp = document.createElement("input");
    inp.type = "range"; inp.id = id; inp.min = min; inp.max = max; inp.value = value;
    const num = document.createElement("span"); num.className = "num"; num.id = id + "Val"; num.textContent = value;
    inp.oninput = () => { num.textContent = inp.value; onIn(+inp.value); };
    inp.onchange = () => savePrefs();
    hold(inp);
    l.append(nm, inp, num);
    box.appendChild(l);
  };
  if (sized)
    slider("太さ", "qSize", 1, 400, Math.round(S.size), (v) => {
      S.size = v; $("size").value = v; $("sizeVal").textContent = v; requestRender();
    });
  if (sized || cols)
    slider("不透明度", "qOp", 1, 100, Math.round(S.opacity * 100), (v) => {
      S.opacity = v / 100; $("opacity").value = v; $("opacityVal").textContent = v;
    });

  if (t === "brush") {
    const px = S.taperUnit === "px", mx = px ? 300 : 60, u = px ? "(px)" : "(%)";
    slider("入り" + u, "qTaperIn", 0, mx, S.taperIn || 0, (v) => {
      S.taperIn = v; $("taperIn").value = v; $("taperInVal").textContent = v;
    });
    slider("抜き" + u, "qTaperOut", 0, mx, S.taperOut || 0, (v) => {
      S.taperOut = v; $("taperOut").value = v; $("taperOutVal").textContent = v;
    });

    const ul = document.createElement("label");
    ul.className = "chk qTaperPx";
    ul.title = "入り抜きの長さを px で決める（線の長さによらず同じ長さで抜ける＝まつげ・毛先向き）。このペンに覚えます";
    const uc = document.createElement("input");
    uc.type = "checkbox"; uc.id = "qTaperPx"; uc.checked = px;
    uc.onchange = () => setTaperUnit(uc.checked);
    ul.append(uc, document.createTextNode("長さを px で"));
    box.appendChild(ul);
  }
  if (cols) {
    const row = document.createElement("div");
    row.className = "qColors";
    const cur = document.createElement("div");
    cur.className = "qCur"; cur.id = "quickCur";
    cur.style.background = S.color;
    cur.title = "今の描画色（押すと色のパネル＝HEX・サブ色）";
    cur.onclick = () => togglePanel("colorPanel");
    row.appendChild(cur);
    const hex = document.createElement("span");
    hex.className = "qHex"; hex.id = "quickHex"; hex.textContent = S.color;
    row.appendChild(hex);
    box.appendChild(row);

    const sv = document.createElement("canvas");
    sv.id = "qSv"; sv.width = 160; sv.height = 120;
    const hb = document.createElement("canvas");
    hb.id = "qHue"; hb.width = 160; hb.height = 16;
    box.appendChild(sv); box.appendChild(hb);
    bindPickerCanvas(sv, (x, y) => {
      toMain(); sat = x; val = 1 - y;
      setColor(rgbHex(...hsvToRgb(hue, sat, val)), true); saveRecent();
    });
    bindPickerCanvas(hb, (x) => {
      toMain(); hue = x * 360;
      setColor(rgbHex(...hsvToRgb(hue, sat, val)), true); saveRecent();
    });
    hold(sv); hold(hb);

    const swatch = (wrap, col, isHist) => {
      const d = document.createElement("div");
      const pin = pinned.includes(col.toLowerCase());
      d.className = "sw" + (pin ? " pin" : "");
      d.style.background = col;
      d.title = col + (pin ? "（固定中）" : "") + " — 右クリックで固定／解除";
      d.onclick = () => { toMain(); setColor(col); };
      d.oncontextmenu = (ev) => {
        ev.preventDefault();
        const items = [pin ? { label: "📌 固定を外す", fn: () => setPinned(col, false) }
                           : { label: "📌 この色を固定する", fn: () => setPinned(col, true) }];
        if (isHist) items.push({ label: "✖ 履歴から消す", fn: () => dropColor(col) });
        showMenu(ev.clientX, ev.clientY, items);
      };
      wrap.appendChild(d);
    };


    if (pinned.length) {
      const pw = document.createElement("div");
      pw.className = "qColors qPinRow";
      for (const col of pinned) swatch(pw, col, true);
      box.appendChild(pw);
    }
    const hist = recent.filter((c) => !pinned.includes(c)).slice(0, HIST_MAX);
    if (hist.length) {
      const hw = document.createElement("div");
      hw.className = "qColors";
      for (const col of hist) swatch(hw, col, true);
      box.appendChild(hw);
    }
    drawQuickPicker();
  }
  if (t === "brush") {

    const curCat = (PRESETS[S.brushPreset] || {}).cat;
    if (!PRESET_CATS[S.quickCat]) S.quickCat = curCat || "line";
    const tabs = document.createElement("div");
    tabs.className = "qTabs";
    for (const [ck, cn] of Object.entries(PRESET_CATS)) {
      const b = document.createElement("button");
      b.textContent = cn.split(" ")[0];
      b.title = cn;
      b.classList.toggle("hi", S.quickCat === ck);
      b.onclick = () => { S.quickCat = ck; syncQuick(); };
      tabs.appendChild(b);
    }
    box.appendChild(tabs);
    const h = document.createElement("div");
    h.className = "qCat"; h.textContent = PRESET_CATS[S.quickCat];
    box.appendChild(h);

    const wrap = document.createElement("div"); wrap.className = "qPens one scroll"; wrap.id = "qPenList";
    for (const [key, p] of Object.entries(PRESETS)) {
      if (p.cat !== S.quickCat) continue;
      const b = document.createElement("button");
      b.textContent = p.name;
      b.title = PRESET_DESC[key] || p.name;
      b.classList.toggle("hi", S.brushPreset === key);
      b.onclick = () => applyPreset(key);
      wrap.appendChild(b);
    }
    box.appendChild(wrap);
    wrap.scrollTop = (quickPenScroll.cat === S.quickCat) ? quickPenScroll.top : 0;
    wrap.onscroll = () => { quickPenScroll = { cat: S.quickCat, top: wrap.scrollTop }; };
  } else if (tips) {
    const h = document.createElement("div");
    h.className = "qCat"; h.textContent = "先の種類";
    box.appendChild(h);
    const wrap = document.createElement("div"); wrap.className = "qPens";
    for (const [name, v] of tips) {
      const b = document.createElement("button");
      b.textContent = name;
      b.classList.toggle("hi", Math.abs(S.hard - v.hard) < 0.01 && (S.brushShape || "round") === v.brushShape);
      b.onclick = () => {
        S.hard = v.hard; S.brushShape = v.brushShape; S.brushPreset = null;
        syncBrushUI(); savePrefs();
        toast(TOOLS[t].name + ": " + name);
      };
      wrap.appendChild(b);
    }
    box.appendChild(wrap);
  }
  box.scrollTop = keep;
}
function buildSelects() {
  const r = $("rulerSel"), s = $("symSel"), b = $("layerBlend");
  r.innerHTML = ""; s.innerHTML = ""; b.innerHTML = "";
  for (const [k, v] of Object.entries(RULERS)) r.add(new Option(v, k));
  for (const [k, v] of Object.entries(SYMS)) s.add(new Option(v, k));
  for (const [k, v] of Object.entries(BLEND_NAMES)) b.add(new Option(v, k));
  const hs = $("hairStyle");
  hs.innerHTML = "";
  for (const [k, v] of Object.entries(HAIR_STYLES)) hs.add(new Option(v, k));
  hs.value = S.hairStyle;
  hs.onchange = () => { S.hairStyle = hs.value; savePrefs(); };
  const dp = $("dollPose");
  dp.innerHTML = "";
  for (const [k, v] of Object.entries(DOLL_POSES)) dp.add(new Option(v.name, k));
  r.value = S.ruler; s.value = S.sym;
  r.onchange = () => S.ruler = r.value;
  s.onchange = () => { S.sym = s.value; requestRender(); };
}
function syncBrushUI() {
  $("size").value = S.size; $("sizeVal").textContent = Math.round(S.size);
  $("opacity").value = Math.round(S.opacity * 100);
  $("opacityVal").textContent = Math.round(S.opacity * 100);
  $("hard").value = Math.round(S.hard * 100);
  $("spacing").value = Math.round(S.spacing * 100);
  $("scatter").value = Math.round(S.scatter * 100);
  $("mix").value = S.mix; $("mixVal").textContent = S.mix;
  $("pcSize").value = Math.round((S.pcSize ?? 1) * 100);
  $("pcSizeVal").textContent = (S.pcSize ?? 1).toFixed(2);
  $("pcOp").value = Math.round((S.pcOp ?? 1) * 100);
  $("pcOpVal").textContent = (S.pcOp ?? 1).toFixed(2);
  drawPcPreview();
  syncTaperUnit();
  $("taperIn").value = S.taperIn; $("taperInVal").textContent = S.taperIn;
  $("taperOut").value = S.taperOut; $("taperOutVal").textContent = S.taperOut;
  $("taperTip").value = S.taperTip ?? 8; $("taperTipVal").textContent = S.taperTip ?? 8;
  $("taperShape").value = S.taperShape || 0; $("taperShapeVal").textContent = S.taperShape || 0;
  $("taperOp").checked = !!S.taperOp;
  $("post").value = S.post; $("postVal").textContent = S.post;
  $("wash").checked = !!S.wash;
  $("flow").value = S.flow ?? 100; $("flowVal").textContent = S.flow ?? 100;
  $("flowRow").classList.toggle("hidden", !S.wash);
  $("dynSpacing").checked = S.dynSpacing !== false;
  $("stabSpeed").checked = !!S.stabSpeed;
  for (const k of ["pMinSize", "pMinOp", "speedSize", "speedOp", "pSmooth", "flick"]) {
    $(k).value = S[k] ?? 0; $(k + "Val").textContent = S[k] ?? 0;
  }
  $("gapClose").value = S.gapClose; $("gapCloseVal").textContent = S.gapClose;
  $("fillRef").value = S.fillRef;
  $("stab").value = S.stab; $("stabVal").textContent = S.stab;
  $("pSize").checked = S.pSize; $("pOp").checked = S.pOp;
  $("aspect").value = Math.round(S.aspect * 100); $("aspectVal").textContent = Math.round(S.aspect * 100);
  $("bangle").value = S.angle; $("bangleVal").textContent = S.angle;
  $("follow").checked = !!S.follow;
  $("grain").value = S.grain; $("grainVal").textContent = S.grain;
  $("jSize").value = S.jSize; $("jSizeVal").textContent = S.jSize;
  $("jAngle").value = S.jAngle; $("jAngleVal").textContent = S.jAngle;
  $("jOpacity").value = S.jOpacity; $("jOpacityVal").textContent = S.jOpacity;
  $("tilt").checked = !!S.tilt;
  if ($("brushShape")) $("brushShape").value = S.brushShape || "round";

  for (const b of $("presetRow").children)
    b.classList.toggle("hi", b.textContent === (PRESETS[S.brushPreset] || {}).name);
  syncQuick();
  requestRender();
}
$("btnUndo").onclick = reqUndo;
$("btnRedo").onclick = reqRedo;
$("size").oninput = (e) => { S.size = +e.target.value; $("sizeVal").textContent = e.target.value; quickVals(); requestRender(); };
$("opacity").oninput = (e) => { S.opacity = e.target.value / 100; $("opacityVal").textContent = e.target.value; quickVals(); };
$("hard").oninput = (e) => S.hard = e.target.value / 100;
$("mix").oninput = (e) => { S.mix = +e.target.value; $("mixVal").textContent = e.target.value; };
$("spacing").oninput = (e) => S.spacing = Math.max(0.02, e.target.value / 100);
$("scatter").oninput = (e) => S.scatter = e.target.value / 100;
$("stab").oninput = (e) => { S.stab = +e.target.value; $("stabVal").textContent = e.target.value; };
$("pSize").onchange = (e) => S.pSize = e.target.checked;
$("pOp").onchange = (e) => S.pOp = e.target.checked;
$("fingerDraw").onchange = (e) => S.fingerDraw = e.target.checked;
$("fillTol").oninput = (e) => { S.fillTol = +e.target.value; $("fillTolVal").textContent = e.target.value; };
$("fillGrow").oninput = (e) => { S.fillGrow = +e.target.value; $("fillGrowVal").textContent = e.target.value; };
$("fillRef").onchange = (e) => { S.fillRef = e.target.value; savePrefs(); };
$("gapClose").oninput = (e) => { S.gapClose = +e.target.value; $("gapCloseVal").textContent = e.target.value; };


function drawPcPreview() {
  const cv = $("pcPreview"); if (!cv) return;
  const g = cv.getContext("2d"), W = cv.width, H = cv.height;
  g.clearRect(0, 0, W, H);
  g.strokeStyle = "rgba(128,128,128,.35)"; g.lineWidth = 1;
  g.beginPath(); g.moveTo(0, H - 0.5); g.lineTo(W, H - 0.5);
  g.moveTo(0.5, 0); g.lineTo(0.5, H); g.stroke();
  g.setLineDash([3, 3]); g.beginPath(); g.moveTo(0, H); g.lineTo(W, 0); g.stroke();
  g.setLineDash([]);
  const curves = [["#6aa9ff", S.pcSize ?? 1], ["#ff9f6a", S.pcOp ?? 1]];
  for (const [col, gam] of curves) {
    g.strokeStyle = col; g.lineWidth = 2; g.beginPath();
    for (let i = 0; i <= W; i++) {
      const p = i / W, y = H - pcurve(p, gam) * H;
      i ? g.lineTo(i, y) : g.moveTo(i, y);
    }
    g.stroke();
  }
}
$("pcSize").oninput = (e) => {
  S.pcSize = +e.target.value / 100; $("pcSizeVal").textContent = S.pcSize.toFixed(2); drawPcPreview();
};
$("pcOp").oninput = (e) => {
  S.pcOp = +e.target.value / 100; $("pcOpVal").textContent = S.pcOp.toFixed(2); drawPcPreview();
};
$("taperIn").oninput = (e) => { S.taperIn = +e.target.value; $("taperInVal").textContent = e.target.value; quickVals(); };
$("taperOut").oninput = (e) => { S.taperOut = +e.target.value; $("taperOutVal").textContent = e.target.value; quickVals(); };
$("post").oninput = (e) => { S.post = +e.target.value; $("postVal").textContent = e.target.value; };

function syncTaperUnit() {
  const px = S.taperUnit === "px", mx = px ? 300 : 60;
  $("taperPx").checked = px;
  for (const k of ["taperIn", "taperOut"]) {
    $(k).max = mx;
    if (S[k] > mx) S[k] = mx;
    $(k + "Unit").textContent = px ? "px" : "%";
  }
}

function setTaperUnit(px) {
  S.taperUnit = px ? "px" : "pct";
  syncTaperUnit();
  $("taperIn").value = S.taperIn; $("taperInVal").textContent = S.taperIn;
  $("taperOut").value = S.taperOut; $("taperOutVal").textContent = S.taperOut;
  if (S.brushPreset && PRESETS[S.brushPreset]) {
    if (!S.taperUnitBy || typeof S.taperUnitBy !== "object") S.taperUnitBy = {};
    S.taperUnitBy[S.brushPreset] = S.taperUnit;
  }
  syncQuick();
  savePrefs();
}
$("taperPx").onchange = (e) => setTaperUnit(e.target.checked);
$("taperOp").onchange = (e) => {
  S.taperOp = e.target.checked;
  S.brushPreset = null;
  for (const b of $("presetRow").children) b.classList.remove("hi");
  savePrefs();
};

function tweak(id, key, conv) {
  const el = $(id), lab = $(id + "Val");
  el.oninput = (e) => {
    S[key] = conv ? conv(+e.target.value) : +e.target.value;
    if (lab) lab.textContent = e.target.value;
    S.brushPreset = null;
    for (const b of $("presetRow").children) b.classList.remove("hi");
    savePrefs();
  };
}
tweak("aspect", "aspect", (v) => v / 100);
tweak("bangle", "angle");
tweak("grain", "grain");
tweak("jSize", "jSize");
tweak("jAngle", "jAngle");
tweak("jOpacity", "jOpacity");
tweak("flow", "flow");
tweak("pMinSize", "pMinSize");
tweak("pMinOp", "pMinOp");
tweak("speedSize", "speedSize");
tweak("speedOp", "speedOp");
tweak("taperTip", "taperTip");
tweak("taperShape", "taperShape");

$("pSmooth").oninput = (e) => { S.pSmooth = +e.target.value; $("pSmoothVal").textContent = e.target.value; savePrefs(); };
$("flick").oninput = (e) => { S.flick = +e.target.value; $("flickVal").textContent = e.target.value; savePrefs(); };
$("dynSpacing").onchange = (e) => { S.dynSpacing = e.target.checked; savePrefs(); };
$("stabSpeed").onchange = (e) => { S.stabSpeed = e.target.checked; savePrefs(); };
$("wash").onchange = (e) => {
  S.wash = e.target.checked;
  $("flowRow").classList.toggle("hidden", !S.wash);
  S.brushPreset = null;
  for (const b of $("presetRow").children) b.classList.remove("hi");
  savePrefs();
};
$("follow").onchange = (e) => { S.follow = e.target.checked; savePrefs(); };
$("tilt").onchange = (e) => { S.tilt = e.target.checked; savePrefs(); };
$("gradType").onchange = (e) => S.gradType = e.target.value;
$("gradMode").onchange = (e) => S.gradMode = e.target.value;
$("xformOk").onclick = () => commitTransform(true);
$("xformCancel").onclick = () => commitTransform(false);

function updateViewPanel() {
  const rl = $("rotVal");
  if (rl) rl.textContent = Math.round(S.view.rot * 180 / Math.PI) + "°";
  const zl = $("zoomVal");
  if (zl) zl.textContent = Math.round(S.view.scale * 100) + "%";
}
$("btnFit").onclick = fitView;
$("btnZoom100").onclick = () => viewCenterOp(() => { S.view.scale = 1; });
$("btnRotL").onclick = () => viewCenterOp(() => { S.view.rot -= Math.PI / 12; });
$("btnRotR").onclick = () => viewCenterOp(() => { S.view.rot += Math.PI / 12; });
$("btnRot0").onclick = () => viewCenterOp(() => { S.view.rot = 0; });
$("btnFlipView").onclick = () => viewCenterOp(() => { S.view.flip = !S.view.flip; });


for (const btn of document.querySelectorAll(".close"))
  btn.onclick = () => $(btn.dataset.close).classList.add("hidden");
function isDocked() { return window.innerWidth >= 900; }
function togglePanel(id) {
  const el = $(id);
  const show = el.classList.contains("hidden");
  for (const p of document.querySelectorAll(".panel")) {
    if (p.id === "layersPanel" && isDocked() && id !== "layersPanel") continue;
    p.classList.add("hidden");
  }
  if (show) el.classList.remove("hidden");
  return show;
}
function syncDock() {
  const el = $("layersPanel");
  if (isDocked()) { el.classList.remove("hidden"); rebuildLayerList(); }
  else el.classList.add("hidden");
  setTimeout(() => { resize(); requestRender(); }, 30);
}
window.addEventListener("resize", () => { if (isDocked()) $("layersPanel").classList.remove("hidden"); });
$("btnTool").onclick = () => togglePanel("toolPanel");
$("btnBrushSet").onclick = () => { if (togglePanel("brushPanel")) syncBrushUI(); };
$("btnView").onclick = () => { if (togglePanel("viewPanel")) updateViewPanel(); };
$("btnFilter").onclick = () => { if (togglePanel("filterPanel")) buildFilterMenu(); };
$("btnHistory").onclick = () => { if (togglePanel("historyPanel")) updateHistoryPanel(); };
$("btnCanvas").onclick = () => {
  if (togglePanel("canvasPanel")) { $("cvW").value = S.doc.w; $("cvH").value = S.doc.h; }
};
$("btnFile").onclick = async () => {
  if (!togglePanel("filePanel")) return;
  try {
    const info = await (await fetch("/api/info")).json();
    $("lanUrl").textContent = info.url;
    $("qrImg").src = "/qr.png?" + info.port;

    $("pinBox").classList.toggle("hidden", !info.requirePin);
    $("pinShow").textContent = info.pin || "------";
  } catch (e) {}
  refreshList();
};
$("btnLayers").onclick = () => {
  const el = $("layersPanel");
  const show = el.classList.contains("hidden");
  if (isDocked()) {
    el.classList.toggle("hidden", !show);
    if (show) rebuildLayerList();
    setTimeout(() => { resize(); requestRender(); }, 30);
    return;
  }
  if (togglePanel("layersPanel")) rebuildLayerList();
};
$("btnColor").onclick = () => {
  if (togglePanel("colorPanel")) { markColorTarget(); buildSwatches(); }
};

async function refreshList() {
  const box = $("fileList");
  box.textContent = "読込中…";
  try {
    const j = await (await fetch("/api/list")).json();
    box.innerHTML = "";
    if (!j.items.length) box.textContent = "ファイルが見つかりません";
    for (const it of j.items) {
      const d = document.createElement("div");
      d.className = "fileItem";
      d.innerHTML = `${it.native ? "💾 " : it.kind === "image" ? "🖼️ " : "📄 "}${it.name}` +
                    `<br><small>${it.mb}MB — ${it.dir}</small>`;
      d.onclick = async () => {
        toast("読み込み中… " + it.name);
        const r = await fetch("/api/open", { method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ path: it.path }) });
        if (!r.ok) toast("読み込み失敗: " + (await r.json()).error);
        $("filePanel").classList.add("hidden");
      };

      d.oncontextmenu = (ev) => {
        ev.preventDefault();
        const fileOp = async (op, extra, okMsg) => {
          try {
            const r = await fetch("/api/file", { method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ op, path: it.path, ...extra }) });
            const j = await r.json();
            toast(r.ok ? okMsg(j) : "できませんでした: " + j.error);
          } catch (e) { toast("できませんでした: " + e); }
          refreshList();
        };
        showMenu(ev.clientX, ev.clientY, [
          { label: "📂 開く", fn: () => d.onclick() },
          { label: "📄 コピーを作る", fn: () => fileOp("copy", {}, (j) => "コピーしました: " + j.name) },
          { label: "✏️ 名前を変更", fn: () => {
              const v = prompt("ファイル名", it.name);
              if (v && v !== it.name) fileOp("rename", { name: v }, (j) => "名前を変えました: " + j.name);
            } },
          { sep: true },
          { label: "🗑️ 消去（ゴミ箱へ）", danger: true, fn: () => {
              if (confirm(`「${it.name}」をゴミ箱へ送りますか?（ゴミ箱から戻せます）`))
                fileOp("trash", {}, () => "ゴミ箱へ送りました: " + it.name);
            } },
        ]);
      };
      box.appendChild(d);
    }
  } catch (e) { box.textContent = "一覧取得失敗"; }
}
$("btnRefreshList").onclick = refreshList;
$("btnRevealOut").onclick = async () => {
  try {
    const r = await fetch("/api/reveal", { method: "POST" });
    const j = await r.json();
    toast(r.ok ? "PCで開きました: " + j.path : "開けませんでした: " + j.error);
  } catch (e) { toast("開けませんでした: " + e); }
};
$("btnNew").onclick = async () => {
  const [w, h] = $("newSize").value.split("x").map(Number);
  if (!confirm(`新規キャンバス ${w}×${h} を作成しますか?(現在の未保存内容は消えます)`)) return;
  await fetch("/api/new", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ w, h }) });
  $("filePanel").classList.add("hidden");
};






function adjustsFor(idx) {
  const out = [];
  const n = S.layers.length;
  const d = S.layers[idx].depth || 0;
  let j = idx + 1;

  while (j < n && (S.layers[j].depth || 0) === d && S.layers[j].clip) {
    const e = S.layers[j];
    if (e.type === "adjust" && e.visible) out.push(e);
    j++;
  }

  let k = j, cur = d;
  while (k < n) {
    const e = S.layers[k], ed = e.depth || 0;
    if (ed < cur) { cur = ed; continue; }
    if (ed === cur && e.type === "adjust" && e.visible && !e.clip) out.push(e);
    k++;
  }
  return out;
}
function bakedCanvasFor(lay, idx) {
  const adjs = adjustsFor(idx);
  if (!adjs.length) return lay.canvas;
  const c = makeCanvas(), cx = c.getContext("2d", { willReadFrequently: true });
  cx.drawImage(lay.canvas, 0, 0);
  const img = cx.getImageData(0, 0, S.doc.w, S.doc.h);
  for (const a of adjs)
    applyFilterData(img.data, S.doc.w, S.doc.h, a.filter, a.params || {}, hashSeed(a.id));
  cx.putImageData(img, 0, 0);
  return c;
}

async function doSave(fmt) {
  if (S.saving) return;
  S.saving = true;
  toast({ spaint: "保存中…", psd: "PSD保存中…", png: "PNG書き出し中…",
          jpg: "JPEG書き出し中…", layers: "レイヤーを個別に書き出し中…" }[fmt] || "保存中…");
  try {
    const body = buildSaveBody(fmt);
    const r = await fetch("/api/save", { method: "POST",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await r.json();
    toast(r.ok ? "✅ 保存: " + j.path : "保存失敗: " + j.error);
  } catch (e) { toast("保存失敗: " + e); }
  S.saving = false;
}
function buildSaveBody(fmt) {
    let body;
    if (fmt === "png" || fmt === "jpg") {
      compositeInto(scratchCtx);
      if (fmt === "jpg") {
        scratchCtx.globalCompositeOperation = "destination-over";
        scratchCtx.fillStyle = "#ffffff";
        scratchCtx.fillRect(0, 0, S.doc.w, S.doc.h);
        scratchCtx.globalCompositeOperation = "source-over";
      }
      body = { fmt, flat: scratch.toDataURL(fmt === "jpg" ? "image/jpeg" : "image/png", 0.92) };
    } else if (fmt === "layers") {
      body = { fmt, layers: S.layers.filter(isRaster).map((l) => ({
        name: l.name, data: (l.hasMask ? maskedCanvas(l) : l.canvas).toDataURL("image/png") })) };
    } else if (fmt === "spaint") {

      body = { fmt, layers: S.layers.map((l) => layerPayload(l, isRaster(l) ? l.canvas : null)) };
    } else {

      const nAdj = S.layers.filter((l) => l.type === "adjust" && l.visible).length;
      const items = [];
      S.layers.forEach((l, i) => {
        if (l.type === "adjust") return;
        items.push(layerPayload(l, isRaster(l) ? bakedCanvasFor(l, i) : null));
      });
      body = { fmt, layers: items };
      if (nAdj) toast(`調整レイヤー${nAdj}枚を焼き込んで保存します(非破壊で残すなら .spaint)`);
    }
    return body;
}




const EXT_FMT = { spaint: "spaint", psd: "psd", png: "png", jpg: "jpg", jpeg: "jpg" };
const FMT_LABEL = { spaint: "SmartPaint形式", psd: "PSD", png: "PNG", jpg: "JPEG" };
function srcFmt() {
  const m = /\.([^.\\/]+)$/.exec(S.doc.src || "");
  return m ? EXT_FMT[m[1].toLowerCase()] || null : null;
}
async function postSaveTo(fmt, extra) {
  const body = { ...buildSaveBody(fmt), ...extra };
  const r = await fetch("/api/save_to", { method: "POST",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return { r, j: await r.json() };
}
function adoptSavedSrc(j) {
  S.doc.src = j.src; S.doc.name = j.name;
}
async function doSaveOver() {
  if (S.saving) return;
  const fmt = srcFmt();
  if (!S.doc.src || !fmt || /[\\/]_autosave[\\/]/i.test(S.doc.src)) {
    toast("元のファイルが無いので、別名で保存します");
    openSaveAs();
    return;
  }
  S.saving = true;
  toast(`上書き保存中…(${FMT_LABEL[fmt]})`);
  try {
    const { r, j } = await postSaveTo(fmt, { mode: "over" });
    if (r.ok) {
      adoptSavedSrc(j);
      toast("✅ 上書き保存: " + j.path + ((fmt === "png" || fmt === "jpg") && S.layers.length > 1
        ? "(1 枚にまとめました。レイヤーを残すなら別名保存で SmartPaint形式)" : ""));
    } else if (j.needAs) {
      toast(j.error + " — 別名で保存します");
      S.saving = false;
      openSaveAs();
      return;
    } else toast("上書き保存できませんでした: " + j.error);
  } catch (e) { toast("上書き保存できませんでした: " + e); }
  S.saving = false;
}
async function openSaveAs() {
  if (!togglePanel("saveAsPanel")) return;
  let info = null;
  try { info = await (await fetch("/api/save_dirs")).json(); } catch (e) {}
  const sel = $("saName"), dsel = $("saDir");
  sel.value = S.doc.name || "untitled";
  $("saFmt").value = srcFmt() || "spaint";
  dsel.innerHTML = "";
  for (const d of (info && info.dirs) || []) {
    const o = document.createElement("option");
    o.value = d.i; o.textContent = d.path;
    dsel.appendChild(o);
  }
  if (info) dsel.value = String(info.cur || 0);
  saFmtHint();
  setTimeout(() => { sel.focus(); sel.select(); }, 30);
}
function saFmtHint() {
  const f = $("saFmt").value;
  $("saHint").textContent = f === "spaint" ? "全部そのまま戻せる形式(続きを描くならこれ)"
    : f === "psd" ? "他のソフトへ渡す用。調整レイヤーは焼き込み、テキスト・ベクターは絵になります"
    : "1 枚の絵にまとめます。レイヤーは残りません";
}
async function doSaveAs(replace) {
  if (S.saving) return;
  const fmt = $("saFmt").value;
  const name = $("saName").value.trim();
  if (!name) { toast("名前を入れてください"); return; }
  S.saving = true;
  toast(`別名で保存中…(${FMT_LABEL[fmt]})`);
  let again = false;
  try {
    const { r, j } = await postSaveTo(fmt, { mode: "as", name, dir: +$("saDir").value, replace: !!replace });
    if (r.ok) {
      adoptSavedSrc(j);
      $("saveAsPanel").classList.add("hidden");
      toast("✅ 別名で保存: " + j.path);
    } else if (j.exists) {
      again = confirm(`同じ名前のファイルがあります。\n${j.path}\n\n置き換えますか？(今のファイルは out\\_backup に控えます)`);
    } else toast("保存できませんでした: " + j.error);
  } catch (e) { toast("保存できませんでした: " + e); }
  S.saving = false;
  if (again) doSaveAs(true);
}
$("btnSaveOver").onclick = () => doSaveOver();
$("btnSaveAs").onclick = () => openSaveAs();
$("saFmt").onchange = () => saFmtHint();
$("saOk").onclick = () => doSaveAs(false);
$("saCancel").onclick = () => $("saveAsPanel").classList.add("hidden");
$("saName").onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); doSaveAs(false); } };

function buildMaterialList() {
  const box = $("matList");
  box.innerHTML = "";
  for (const [cat, label] of Object.entries(MAT_CATS)) {
    const h = document.createElement("div");
    h.className = "secLabel";
    h.textContent = label;
    box.appendChild(h);
    const row = document.createElement("div");
    row.className = "iconRow";
    for (const [key, m] of Object.entries(MATERIALS)) {
      if (m.cat !== cat) continue;
      const b = document.createElement("button");
      b.dataset.mat = key;

      const cv = document.createElement("canvas");
      cv.width = cv.height = 34;
      const cc = cv.getContext("2d");
      cc.translate(17, 17); cc.scale(13, 13);
      m.draw(cc, { color: "#e6e6e6", sub: "#8ab4f8", seed: 1 });
      b.appendChild(cv);
      const s = document.createElement("small");
      s.textContent = m.name;
      b.appendChild(s);
      b.dataset.tipHead = m.name;
      b.dataset.tip = "選んでからキャンバスをタップ/ドラッグで置きます";
      b.onclick = () => {
        S.material = key;
        setTool("stamp");
        markMaterial();
        savePrefs();
      };
      row.appendChild(b);
    }
    box.appendChild(row);
  }
  markMaterial();
}
function markMaterial() {
  for (const b of document.querySelectorAll("#matList button[data-mat]"))
    b.classList.toggle("hi", b.dataset.mat === S.material);
}
$("matSize").oninput = (e) => {
  S.matSize = +e.target.value; $("matSizeVal").textContent = e.target.value; savePrefs();
};
$("dollH").oninput = (e) => { $("dollHVal").textContent = e.target.value; };
function newDollData() {
  const h = +$("dollH").value;
  const pose = $("dollPose").value;
  return { pose: dollBasePose(Math.round(S.doc.w / 2), Math.round(S.doc.h / 2), h,
                              pose, $("dollFlip").checked),
           h, style: pose, color: "#8892a6" };
}
$("dollMake").onclick = () => {
  localOp({ id: uid(), kind: "addLayer", at: S.active + 1,
            layer: { id: "D" + uid(), name: "デッサン人形", visible: true,
                     opacity: 0.45, blend: "normal", clip: false, alphaLock: false,
                     type: "doll", depth: insertDepth(), doll: newDollData() } });
  setTool("doll");
  toast("関節の白い丸をつまむと動かせます");
  $("matPanel").classList.add("hidden");
};
$("dollPoseApply").onclick = () => {
  const lay = S.layers[S.active];
  if (!isDoll(lay)) { toast("デッサン人形のレイヤーを選んでください"); return; }
  localOp({ id: uid(), kind: "setDoll", layer: lay.id, doll: newDollData(),
            prevDoll: lay.doll });
};
$("hairSize").oninput = (e) => { $("hairSizeVal").textContent = e.target.value; };
$("hairMake").onclick = () => {
  const r = +$("hairSize").value;
  const style = $("hairStyle").value;
  const ids = hairParts(style).map(() => "H" + uid());
  localOp({ id: uid(), kind: "hairSet", style, ids,
            x: Math.round(S.doc.w / 2), y: Math.round(S.doc.h * 0.36), r,
            color: S.color, at: S.active + 1, depth: insertDepth() });
  toast(`髪プリセット: ${HAIR_STYLES[style]}(${ids.length}レイヤー)`);
  $("matPanel").classList.add("hidden");
};


$("btnAutoColor").onclick = () => {
  togglePanel("autoColorPanel");
  if (!S.layers.some((l) => l.isRef))
    $("acStat").textContent = "参照レイヤー(🔎)が無いので「全部のレイヤー」から線を探します。";
};
function autoColorOpts() {
  return { refMode: $("acRef").value,
           gapClose: +$("acGap").value, grow: +$("acGrow").value,
           minArea: +$("acMin").value, skipBg: $("acSkipBg").checked,
           maxCount: +$("acMax").value };
}
for (const [id, lab] of [["acGap", "acGapVal"], ["acGrow", "acGrowVal"],
                         ["acMin", "acMinVal"], ["acMax", "acMaxVal"]])
  $(id).oninput = (e) => { $(lab).textContent = e.target.value; };
$("acPreview").onclick = () => {
  $("acStat").textContent = "調べています…";
  setTimeout(() => {
    const t0 = performance.now();
    const res = computeAutoRegions(autoColorOpts());
    const ms = Math.round(performance.now() - t0);
    if (!res.regions.length) {
      $("acStat").textContent = "領域が見つかりません。隙間閉じを上げるか、最小の広さを下げてください。";
      return;
    }
    const top = res.regions.slice(0, 5).map((r) => r.size.toLocaleString()).join(" / ");
    $("acStat").innerHTML = `見つかった領域: <b>${res.regions.length}個</b>(${ms}ms)<br>` +
      `広い順の画素数: ${top}${res.regions.length > 5 ? " …" : ""}`;
  }, 30);
};
$("acRun").onclick = () => {
  const opts = autoColorOpts();
  const split = $("acSplit").value === "1";
  $("acStat").textContent = "塗っています…";
  setTimeout(() => {

    const res = computeAutoRegions(opts);
    if (!res.regions.length) {
      $("acStat").textContent = "塗れる領域がありませんでした。";
      toast("塗れる領域が見つかりませんでした");
      return;
    }
    const count = split ? res.regions.length : 1;
    const ids = Array.from({ length: count }, () => "F" + uid());
    localOp({ id: uid(), kind: "autoColor", opts, split, ids,
              at: S.active + 1, depth: insertDepth(),
              mono: $("acMono").value === "1", color: S.color });
    $("acStat").textContent = `${res.regions.length}個の領域を塗りました。`;
    $("autoColorPanel").classList.add("hidden");
  }, 30);
};

$("btnSaveNative").onclick = () => doSave("spaint");
$("btnSavePsd").onclick = () => doSave("psd");
$("btnSavePng").onclick = () => doSave("png");
$("btnSaveJpg").onclick = () => doSave("jpg");
$("btnSaveLayers").onclick = () => doSave("layers");




const tipEl = document.createElement("div");
tipEl.id = "tooltip";
tipEl.style.display = "none";
document.body.appendChild(tipEl);
let tipTimer = null, tipFor = null;
function harvestTitles(root) {
  for (const el of (root || document).querySelectorAll("[title]")) {
    el.dataset.tip = el.getAttribute("title");
    el.removeAttribute("title");
  }
}
function tipLabelOf(el) {

  const cap = el.querySelector && el.querySelector("small");
  const head = el.dataset.tipHead || (cap ? cap.textContent.trim() : "");
  const body = el.dataset.tip || "";
  if (!head && !body) return "";
  return (head ? `<b>${head}</b>` : "") + body;
}
function showTip(el) {
  const html = tipLabelOf(el);
  if (!html) return;
  tipEl.innerHTML = html;
  tipEl.style.display = "block";
  const r = el.getBoundingClientRect();
  const t = tipEl.getBoundingClientRect();
  let x = r.left + r.width / 2 - t.width / 2;
  let y = r.bottom + 8;
  if (y + t.height > innerHeight - 4) y = r.top - t.height - 8;
  tipEl.style.left = clamp(x, 4, innerWidth - t.width - 4) + "px";
  tipEl.style.top = Math.max(4, y) + "px";
  tipFor = el;
}
function hideTip() {
  if (tipTimer) { clearTimeout(tipTimer); tipTimer = null; }
  tipEl.style.display = "none";
  tipFor = null;
}
document.addEventListener("pointerover", (e) => {
  if (e.pointerType === "touch") return;
  const el = e.target.closest("[data-tip],[data-tip-head]");
  if (!el || el === tipFor) return;
  hideTip();
  tipTimer = setTimeout(() => showTip(el), 320);
});
document.addEventListener("pointerout", (e) => {
  const el = e.target.closest("[data-tip],[data-tip-head]");
  if (el && el === tipFor) hideTip();
  else if (tipTimer) { clearTimeout(tipTimer); tipTimer = null; }
});
document.addEventListener("pointerdown", hideTip, true);
window.addEventListener("blur", hideTip);


let toastTimer = null;
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add("hidden"), 3500);
}
if (!Array.prototype.findLastIndex) {
  Array.prototype.findLastIndex = function (fn) {
    for (let i = this.length - 1; i >= 0; i--) if (fn(this[i], i, this)) return i;
    return -1;
  };
}
document.addEventListener("visibilitychange", () => { if (!document.hidden && !wsAlive()) connect(); });
window.addEventListener("focus", () => { if (!wsAlive()) connect(); });
window.addEventListener("online", () => { if (!wsAlive()) connect(); });


const PERSIST = ["tool", "size", "opacity", "hard", "stab", "spacing", "scatter",
                 "brushShape", "pSize", "pOp", "pcSize", "pcOp", "fingerDraw", "ruler", "sym",
                 "color", "sub", "gradType", "gradMode", "fillTol", "fillGrow",
                 "textSize", "textFont", "textVertical", "deviceName",
                 "textTrack", "textLineH", "textOutline", "textOutlineColor", "importFitCanvas",
                 "autosaveOn", "persp", "mix", "selFeather", "selGrow",
                 "taperIn", "taperOut", "post", "gapClose", "fillRef", "vecErase",
                 "aspect", "angle", "follow", "grain", "jSize", "jAngle", "jOpacity",
                 "tilt", "brushPreset", "material", "matSize", "hairStyle", "mouseBtn",
                 "soloOn", "soloRect", "quickOn", "spread", "clipAll", "wash", "flow", "keys", "wheel",
                 "pMinSize", "pMinOp", "speedSize", "speedOp", "pSmooth",
                 "taperUnit", "taperTip", "taperShape", "taperOp", "taperUnitBy", "flick", "dynSpacing", "stabSpeed",
                 "layerSwing"];
let persistTimer = null;
function savePrefs() {
  if (persistTimer) clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    const o = {};
    for (const k of PERSIST) o[k] = S[k];
    try { localStorage.setItem("sp_prefs", JSON.stringify(o)); } catch (e) {}
  }, 400);
}
function loadPrefs() {
  let o = null;
  try { o = JSON.parse(localStorage.getItem("sp_prefs") || "null"); } catch (e) {}
  if (!o) return;
  for (const k of PERSIST) if (o[k] !== undefined) S[k] = o[k];
  if (S.persp) S.persp.drag = null;


  if (!MATERIALS[S.material]) S.material = "sparkle";
  if (!HAIR_STYLES[S.hairStyle]) S.hairStyle = "straight";
  if (!PRESETS[S.brushPreset]) S.brushPreset = null;
  if (!TOOLS[S.tool]) S.tool = "brush";
  const mb0 = MOUSE_DEFAULT;
  if (!S.mouseBtn || typeof S.mouseBtn !== "object") S.mouseBtn = { ...mb0 };
  for (const k of Object.keys(mb0)) {
    const v = S.mouseBtn[k];
    if (!(v === "tool" || v === "none" || v === "undo" || v === "redo" || TOOLS[v])) S.mouseBtn[k] = mb0[k];
  }
  if (!S.keys || typeof S.keys !== "object") S.keys = {};
  for (const id of Object.keys(S.keys)) if (!KEY_ACTIONS[id] || !Array.isArray(S.keys[id])) delete S.keys[id];
  rebuildKeyIndex();
  if (!S.wheel || typeof S.wheel !== "object") S.wheel = { ...WHEEL_DEFAULT };
  for (const k of Object.keys(WHEEL_DEFAULT)) if (!WHEEL_ROLES[S.wheel[k]]) S.wheel[k] = WHEEL_DEFAULT[k];
  syncMouseBtnUI();
}


const MOUSE_ROLES = ["tool", "hand", "grab", "eraser", "brush", "picker", "move", "fill",
                     "blur", "smudge", "lasso", "selrect", "wand", "undo", "redo", "none"];
const MOUSE_SEL = { left: "mbLeft", middle: "mbMiddle", right: "mbRight", back: "mbBack", forward: "mbForward",
                    penBarrel: "mbPenBarrel", penEraser: "mbPenEraser" };
function mouseRoleName(r) {
  if (r === "tool") return "今選んでいる道具";
  if (r === "none") return "何もしない";
  if (r === "hand") return "✋ 画面を動かす";
  if (r === "undo") return "↩️ 元に戻す(押した時)";
  if (r === "redo") return "↪️ やり直す(押した時)";
  return TOOLS[r].icon + " " + TOOLS[r].name;
}
const WHEEL_SEL = { plain: "whPlain", ctrl: "whCtrl", shift: "whShift", alt: "whAlt" };
function syncMouseBtnUI() {
  for (const [k, id] of Object.entries(MOUSE_SEL)) {
    const el = $(id); if (!el) continue;
    if (!el.options.length) {
      for (const r of MOUSE_ROLES) {
        const o = document.createElement("option"); o.value = r; o.textContent = mouseRoleName(r);
        el.appendChild(o);
      }
      el.onchange = () => {
        S.mouseBtn = { ...S.mouseBtn, [k]: el.value };
        if (![S.mouseBtn.left, S.mouseBtn.middle, S.mouseBtn.right].includes("tool"))
          toast("「今選んでいる道具」のマウスのボタンがありません。道具の列で選んだ道具はペンとタッチだけで使えます");
        savePrefs();
      };
    }
    el.value = S.mouseBtn[k] ?? MOUSE_DEFAULT[k];
  }
  for (const [k, id] of Object.entries(WHEEL_SEL)) {
    const el = $(id); if (!el) continue;
    if (!el.options.length) {
      for (const [r, name] of Object.entries(WHEEL_ROLES)) {
        const o = document.createElement("option"); o.value = r; o.textContent = name; el.appendChild(o);
      }
      el.onchange = () => { S.wheel = { ...S.wheel, [k]: el.value }; savePrefs(); };
    }
    el.value = S.wheel[k] ?? WHEEL_DEFAULT[k];
  }
}
syncMouseBtnUI();
$("mbReset").onclick = () => {
  S.mouseBtn = { ...MOUSE_DEFAULT }; S.wheel = { ...WHEEL_DEFAULT };
  syncMouseBtnUI(); savePrefs(); toast("マウス・ペン・ホイールを初めの割り当てに戻しました");
};
$("btnUnselLayer").onclick = () => setUnsel(!S.unsel);


function closeMenu() { const m = $("ctxMenu"); if (m) m.remove(); }
function showMenu(x, y, items) {
  closeMenu();
  const m = document.createElement("div");
  m.id = "ctxMenu";
  for (const it of items) {
    if (it.sep) { const s = document.createElement("div"); s.className = "sep"; m.appendChild(s); continue; }
    const b = document.createElement("button");
    b.textContent = it.label;
    if (it.danger) b.classList.add("danger");
    b.onclick = () => { closeMenu(); it.fn(); };
    m.appendChild(b);
  }
  document.body.appendChild(m);
  const r = m.getBoundingClientRect();
  m.style.left = Math.max(4, Math.min(x, window.innerWidth - r.width - 4)) + "px";
  m.style.top = Math.max(4, Math.min(y, window.innerHeight - r.height - 4)) + "px";
}
window.addEventListener("pointerdown", (e) => {
  const m = $("ctxMenu");
  if (m && !m.contains(e.target)) closeMenu();
}, true);
window.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenu(); }, true);
window.addEventListener("blur", closeMenu);

function syncSoloUI() { $("btnSolo").classList.toggle("active", !!S.soloOn || !!SOLO.win); }
function setSolo(on) {
  if (!on && SOLO.win) soloDock();
  S.soloOn = !!on; syncSoloUI(); savePrefs(); requestRender();
  if (on && !soloLayer()) toast("レイヤーを 1 つ選ぶと、そのパーツだけの枠が出ます");
}
$("btnSolo").onclick = () => setSolo(!S.soloOn);
$("soloClose").onclick = () => setSolo(false);
$("soloFit").onclick = () => { const l = soloLayer(); if (l) { soloFit(l); requestRender(); } };
$("soloPop").onclick = () => soloPopout();
for (const b of [$("soloClose"), $("soloFit"), $("soloPop")]) b.addEventListener("pointerdown", (e) => e.stopPropagation());

function soloDrag(el, apply) {
  let d = null;
  el.addEventListener("pointerdown", (e) => {
    if (!S.soloRect) return;
    e.preventDefault();
    try { el.setPointerCapture(e.pointerId); } catch (err) {}
    d = { id: e.pointerId, x: e.clientX, y: e.clientY, r: { ...S.soloRect } };
  });
  el.addEventListener("pointermove", (e) => {
    if (!d || d.id !== e.pointerId) return;
    if (apply(S.soloRect, d.r, e.clientX - d.x, e.clientY - d.y, e, d) === "stop") {
      try { el.releasePointerCapture(e.pointerId); } catch (err) {}
      d = null; savePrefs();
    }
    requestRender();
  });
  const end = (e) => { if (d && d.id === e.pointerId) { d = null; savePrefs(); } };
  el.addEventListener("pointerup", end);
  el.addEventListener("pointercancel", end);
}



soloDrag($("soloHead"), (q, r0, dx, dy, e, d) => {
  q.x = r0.x + dx; q.y = r0.y + dy;



  const W = window.innerWidth, H = window.innerHeight, edge = 3;
  if (e.clientX <= edge || e.clientY <= edge || e.clientX >= W - 1 - edge || e.clientY >= H - 1 - edge) {
    const gx = d.x - r0.x, gy = d.y - r0.y;
    const outside = e.clientX < -14 || e.clientY < -14 || e.clientX > W + 14 || e.clientY > H + 14;
    q.x = r0.x; q.y = r0.y;
    let left = Math.round(e.screenX - gx), top = Math.round(e.screenY - gy - 30);
    if (!outside) {

      const sc = window.screen, sl = sc.availLeft || 0, st = sc.availTop || 0;
      left = clamp(left, sl, Math.max(sl, sl + sc.availWidth - q.w - 16));
      top = clamp(top, st, Math.max(st, st + sc.availHeight - q.h - 80));
    }
    soloPopout({ left, top, width: q.w, height: q.h });
    return "stop";
  }
});
soloDrag($("soloGrip"), (q, r0, dx, dy) => { q.w = r0.w + dx; q.h = r0.h + dy; });
document.body.appendChild(SOLO.box);


function isPhone() {
  return matchMedia("(pointer: coarse)").matches && Math.min(screen.width, screen.height) < 900;
}
function defaultDeviceName() {
  if (S.deviceName) return S.deviceName;
  const ua = navigator.userAgent;
  if (/iPad/.test(ua)) return "iPad";
  if (/iPhone/.test(ua)) return "iPhone";
  if (/Android/.test(ua)) return /Mobile/.test(ua) ? "Androidスマホ" : "Androidタブレット";
  return isPhone() ? "スマホ" : "PC";
}
function sayHello() {
  if (!wsAlive()) return;
  S.ws.send(JSON.stringify({ t: "hello", name: defaultDeviceName(),
                             kind: isPhone() ? "phone" : "pc" }));
}

setInterval(() => {
  if (!wsAlive()) return;
  S.ws.send(JSON.stringify({ t: "ping", ts: Date.now() }));
}, 4000);
function renderPeers() {
  const box = $("peerList");
  if (!box) return;
  box.innerHTML = "";
  for (const p of S.peers) {
    const d = document.createElement("div");
    d.className = "peerItem" + (p.id === S.me ? " me" : "");
    d.textContent = (p.kind === "phone" ? "📱 " : "💻 ") + p.name + (p.id === S.me ? "(この端末)" : "");
    box.appendChild(d);
  }
  if (!S.peers.length) box.innerHTML = '<small class="hint">接続中の端末はありません</small>';
  const st = $("netStat");
  if (st) {
    st.innerHTML = S.rtt == null
      ? "遅延: 測定中…"
      : `遅延: <b>${S.rtt}ms</b>(最大 ${S.rttWorst}ms) — ` +
        (S.rtt < 40 ? "快適" : S.rtt < 120 ? "実用範囲" : "電波かWi-Fiを見直してください");
  }
  const n = S.peers.length;
  $("peerCount").textContent = n ? `${n}台接続中` : "";
}



let lastSentView = "";
function shareView() {
  if (!$("shareView") || !$("shareView").checked || !wsAlive()) return;
  const v = { x: Math.round(S.view.x), y: Math.round(S.view.y),
              scale: +S.view.scale.toFixed(4), rot: +S.view.rot.toFixed(4),
              flip: S.view.flip, w: Math.round(view.getBoundingClientRect().width) };
  const key = JSON.stringify(v);
  if (key === lastSentView) return;
  lastSentView = key;
  S.ws.send(JSON.stringify({ t: "view", v }));
}
setInterval(shareView, 250);
function applySharedView(v) {
  if (!S.followPeer || !v) return;

  const myW = view.getBoundingClientRect().width;
  const k = v.w ? myW / v.w : 1;
  S.view.scale = v.scale * k;
  S.view.rot = v.rot; S.view.flip = v.flip;
  S.view.x = v.x * k; S.view.y = v.y * k;
  requestRender(); updateViewPanel();
}


function setZen(on) {
  S.zen = on;
  document.body.classList.toggle("zen", on);
  $("zenExit").classList.toggle("hidden", !on);
  setTimeout(() => { resize(); requestRender(); }, 60);
}
$("btnZen").onclick = () => setZen(true);
$("zenExit").onclick = () => setZen(false);


const MINI = [
  { k: "brush", icon: "🖌️" }, { k: "eraser", icon: "🧽" },
  { k: "blur", icon: "💨" },
  { k: "grab", icon: "🤚" },
  { k: "fill", icon: "🪣" }, { k: "picker", icon: "💧" },
];
function buildMiniBar() {
  const box = $("miniBar");
  box.innerHTML = "";
  for (const m of MINI) {
    const b = document.createElement("button");
    b.textContent = m.icon;
    b.dataset.mini = m.k;
    b.dataset.tipHead = TOOLS[m.k].name;
    b.dataset.tip = TOOL_DESC[m.k] || "";
    b.onclick = () => { setTool(m.k); syncMiniBar(); };
    box.appendChild(b);
  }
  const u = document.createElement("button");
  u.textContent = "↩"; u.dataset.tipHead = "元に戻す";
  u.dataset.tip = "Ctrl+Z / スマホは2本指タップ";
  u.onclick = reqUndo; box.appendChild(u);
  const r = document.createElement("button");
  r.textContent = "↪"; r.dataset.tipHead = "やり直す";
  r.dataset.tip = "Ctrl+Y / スマホは3本指タップ";
  r.onclick = reqRedo; box.appendChild(r);
  const s = document.createElement("button");
  s.textContent = "🗂️"; s.dataset.tipHead = "レイヤー";
  s.dataset.tip = "レイヤー一覧の表示/非表示";
  s.onclick = () => { if (togglePanel("layersPanel")) rebuildLayerList(); };
  box.appendChild(s);
}
function syncMiniBar() {
  for (const b of document.querySelectorAll("#miniBar button[data-mini]"))
    b.classList.toggle("active", b.dataset.mini === S.tool);
}



async function imageFileToLayer(f, W = S.doc.w, H = S.doc.h) {
  const bmp = await createImageBitmap(f);
  const k = Math.min(W / bmp.width, H / bmp.height, 1);
  const w = Math.round(bmp.width * k), h = Math.round(bmp.height * k);
  const c = makeCanvas(W, H), cx = c.getContext("2d");
  cx.imageSmoothingQuality = "high";
  cx.drawImage(bmp, (W - w) / 2, (H - h) / 2, w, h);
  bmp.close && bmp.close();
  return { id: "L" + uid(), name: f.name.slice(0, 40) || "取り込み画像",
           visible: true, opacity: 1, blend: "normal", clip: false,
           data: c.toDataURL("image/png") };
}

async function importImageFiles(files) {
  const imgs = [...files].filter((f) => /^image\//.test(f.type));
  if (!imgs.length) { toast("画像ではないので取り込めません"); return; }
  toast("画像を配置しています…");


  let W = S.doc.w, H = S.doc.h, fitted = false;
  if (S.importFitCanvas && docIsBlank()) {
    try {
      const b = await createImageBitmap(imgs[0]);
      const k = Math.min(1, 8000 / b.width, 8000 / b.height);
      W = Math.max(1, Math.round(b.width * k)); H = Math.max(1, Math.round(b.height * k));
      b.close && b.close();
      fitted = W !== S.doc.w || H !== S.doc.h;
    } catch (e) {}
  }
  const extras = [], bad = [];
  for (const f of imgs) {
    try { extras.push(await imageFileToLayer(f, W, H)); } catch (err) { bad.push(f.name); }
  }
  if (extras.length)
    await commitDoc(W, H, (ctx2, l, src) => ctx2.drawImage(src, 0, 0),
                    (extras.length > 1 ? `画像の配置 (${extras.length}枚)` : "画像の配置")
                    + (fitted ? ` ・キャンバス ${W}×${H}` : ""), extras);
  if (bad.length) toast("画像の読み込みに失敗: " + bad.join(", "));
}

function docIsBlank() {
  return S.layers.every((l) => !l.ctx || !contentBBox(l.ctx));
}
$("imgInput").onchange = async (e) => {
  const files = [...(e.target.files || [])];
  e.target.value = "";
  if (files.length) await importImageFiles(files);
};



const hasFiles = (e) => e.dataTransfer && [...e.dataTransfer.types].includes("Files");
let dropDepth = 0;
window.addEventListener("dragenter", (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault(); dropDepth++; document.body.classList.add("fileDragOver");
});
window.addEventListener("dragover", (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault(); e.dataTransfer.dropEffect = "copy";
});
window.addEventListener("dragleave", (e) => {
  if (!hasFiles(e)) return;
  if (--dropDepth <= 0) { dropDepth = 0; document.body.classList.remove("fileDragOver"); }
});
window.addEventListener("drop", (e) => {
  if (!hasFiles(e)) return;
  e.preventDefault(); dropDepth = 0; document.body.classList.remove("fileDragOver");
  importImageFiles(e.dataTransfer.files);
});


let lastAutosave = 0;
async function autosaveTick() {
  if (!S.autosaveOn || !S.dirty || S.saving) return;
  if (Date.now() - lastAutosave < 5 * 60 * 1000) return;
  if (S.peers.length && S.peers[0].id !== S.me) return;
  lastAutosave = Date.now();
  const before = S.dirty;
  try {


    await fetch("/api/save", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fmt: "spaint", auto: true,
        layers: S.layers.map((l) => layerPayload(l, isRaster(l) ? l.canvas : null)) }) });
    S.dirty -= before;
    $("autoStat").textContent = "自動保存: " + new Date().toLocaleTimeString("ja-JP");
  } catch (e) {}
}
setInterval(autosaveTick, 30 * 1000);
$("autosaveOn").onchange = (e) => { S.autosaveOn = e.target.checked; savePrefs(); };



function maybeShowHelp() {}
$("btnHelp").onclick = () => togglePanel("helpPanel");




let SUPPORT_URL = "";
$("btnSupport").classList.add("hidden");
fetch("/api/info").then((r) => r.json()).then((j) => {
  if (j && /^https:\/\//.test(j.supportUrl || "")) {
    SUPPORT_URL = j.supportUrl;
    $("btnSupport").classList.remove("hidden");
  }
}).catch(() => {});
$("btnSupport").onclick = () => {
  if (SUPPORT_URL) window.open(SUPPORT_URL, "_blank", "noopener");
};




function openTextEditor(lay, pos) {
  const t = lay && lay.text ? lay.text : null;
  S.textEdit = { layerId: lay ? lay.id : null,
                 x: pos ? pos[0] : (t ? t.x : Math.round(S.doc.w / 2)),
                 y: pos ? pos[1] : (t ? t.y : Math.round(S.doc.h / 2)) };

  if (t) {
    $("textInput").value = t.text || "";
    S.textSize = t.size || S.textSize;
    S.textFont = t.font || S.textFont;
    S.textAlign = t.align || S.textAlign;
    S.textVertical = !!t.vertical;
    S.textTrack = t.track || 0;
    S.textLineH = t.lineH || 100;
    S.textOutline = t.outline || 0;
    S.textOutlineColor = t.outlineColor || S.textOutlineColor;
    addFontOption(S.textFont);
    syncTextExtraUI();
    if (t.color) setColor(t.color);
    $("textSize").value = S.textSize;
    $("textSizeVal").textContent = S.textSize;
    $("textFont").value = S.textFont;
    $("textAlign").value = S.textAlign;
    $("textVertical").checked = S.textVertical;
  }
  $("textHint").textContent = lay
    ? `「${lay.name}」を編集中 — 内容を変えて「更新」`
    : "確定するとテキストレイヤーが1枚できます(あとから何度でも直せます)";
  $("textApply").textContent = lay ? "✔ 更新" : "✔ 作成";
  $("textRasterize").classList.toggle("hidden", !lay);
  const p = $("textPanel");
  p.classList.remove("hidden");
  $("textInput").focus();
  $("textInput").select();
}
function textDataFromUI() {
  return { text: $("textInput").value, x: S.textEdit.x, y: S.textEdit.y,
           size: S.textSize, font: S.textFont, align: S.textAlign,
           vertical: S.textVertical, color: S.color,
           track: S.textTrack, lineH: S.textLineH,
           outline: S.textOutline, outlineColor: S.textOutlineColor };
}
function syncTextExtraUI() {
  $("textTrack").value = S.textTrack; $("textTrackVal").textContent = S.textTrack;
  $("textLineH").value = S.textLineH; $("textLineHVal").textContent = S.textLineH;
  $("textOutline").value = S.textOutline; $("textOutlineVal").textContent = S.textOutline;
  $("textOutlineColor").value = S.textOutlineColor;
}
for (const [id, key] of [["textTrack", "textTrack"], ["textLineH", "textLineH"], ["textOutline", "textOutline"]]) {
  $(id).oninput = (e) => { S[key] = +e.target.value; $(id + "Val").textContent = e.target.value; };
  $(id).addEventListener("change", savePrefs);
}
$("textOutlineColor").oninput = (e) => { S.textOutlineColor = e.target.value; };
$("textOutlineColor").addEventListener("change", savePrefs);




const LOADED_FONTS = new Set();
function addFontOption(key) {
  const sel = $("textFont");
  if (!key || FONTS[key] || [...sel.options].some((o) => o.value === key)) return;
  const m = /^(f|sys):(.+)$/.exec(key);
  if (!m) return;
  const o = document.createElement("option");
  o.value = key;
  o.textContent = (m[1] === "f" ? "📂 " : "💻 ") + m[2];
  sel.appendChild(o);
}
function redrawTextUsing(keys) {
  let n = 0;
  for (const l of S.layers) if (isText(l) && l.text && keys.has(l.text.font)) { rebuildText(l); n++; }
  if (n) requestRender();
}
async function loadServerFonts() {
  try {
    const j = await (await fetch("/api/fonts")).json();
    const fresh = new Set();
    for (const f of j.fonts || []) {
      const key = "f:" + f.name;
      addFontOption(key);
      if (LOADED_FONTS.has(key)) continue;
      try {
        const face = new FontFace(f.name, `url(/api/fonts/${encodeURIComponent(f.file)})`);
        document.fonts.add(await face.load());
        LOADED_FONTS.add(key); fresh.add(key);
      } catch (e) { console.warn("font load fail", f.file, e); }
    }
    if (fresh.size) redrawTextUsing(fresh);
  } catch (e) {}
  if ([...$("textFont").options].some((o) => o.value === S.textFont)) $("textFont").value = S.textFont;
}
$("textFontFile").onchange = async (e) => {
  const files = [...(e.target.files || [])];
  e.target.value = "";
  let last = null;
  for (const f of files) {
    const r = await fetch("/api/fonts?name=" + encodeURIComponent(f.name), { method: "POST", body: f });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { toast(`${f.name}: ${j.error || "読み込めませんでした"}`); continue; }
    last = "f:" + j.name;
  }
  await loadServerFonts();
  if (last) { S.textFont = last; $("textFont").value = last; savePrefs(); toast("書体を読み込みました"); }
};
function useSysFont(name) {
  name = String(name || "").trim();
  if (!name) { toast("書体の名前を入れてください"); return; }
  if (!document.fonts.check(`16px "${name.replace(/["\\]/g, "")}"`))
    toast("この PC では見つからない名前です(無い端末ではゴシックで出ます)");
  const key = "sys:" + name;
  addFontOption(key);
  S.textFont = key; $("textFont").value = key; savePrefs();
}
$("textSysFontUse").onclick = () => useSysFont($("textSysFont").value);
$("textSysFont").onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); useSysFont(e.target.value); } };
$("textSysFontScan").onclick = async () => {
  if (!window.queryLocalFonts) { toast("この画面では一覧を出せません。名前を入れてください"); return; }
  try {
    const names = [...new Set((await window.queryLocalFonts()).map((f) => f.family))].sort();
    const dl = $("textSysFontList");
    dl.innerHTML = "";
    for (const n of names) { const o = document.createElement("option"); o.value = n; dl.appendChild(o); }
    toast(`PC の書体 ${names.length} 個。名前の欄で選べます`);
    $("textSysFont").focus();
  } catch (e) { toast("一覧を出せませんでした(許可が要ります)。名前を入れてください"); }
};
$("textApply").onclick = () => {
  const ed = S.textEdit;
  if (!ed) { $("textPanel").classList.add("hidden"); return; }
  const data = textDataFromUI();
  if (!String(data.text).trim()) { toast("文字が入力されていません"); return; }
  if (ed.layerId) {


    const cur = layerById(ed.layerId);
    localOp({ id: uid(), kind: "setText", layer: ed.layerId, text: data, rename: true,
              prevText: cur ? cur.text : null, prevName: cur ? cur.name : undefined });
  } else {
    localOp({ id: uid(), kind: "addLayer", at: S.active + 1,
              layer: { id: "T" + uid(), name: textLayerName(data), visible: true,
                       opacity: 1, blend: "normal", clip: false, alphaLock: false,
                       type: "text", depth: insertDepth(), text: data } });
  }
  $("textPanel").classList.add("hidden");
};
$("textRasterize").onclick = () => {
  const ed = S.textEdit;
  if (!ed || !ed.layerId) return;
  if (!confirm("文字を絵に変換しますか?(以後は筆で描き込めますが、文章の編集はできなくなります)")) return;
  const cur = layerById(ed.layerId);
  localOp({ id: uid(), kind: "rasterizeText", layer: ed.layerId,
            prevText: cur ? cur.text : null });
  $("textPanel").classList.add("hidden");
};
$("textSize").oninput = (e) => { S.textSize = +e.target.value; $("textSizeVal").textContent = e.target.value; savePrefs(); };
$("textFont").onchange = (e) => { S.textFont = e.target.value; savePrefs(); };
$("textAlign").onchange = (e) => S.textAlign = e.target.value;
$("textVertical").onchange = (e) => { S.textVertical = e.target.checked; savePrefs(); };
$("perspOn").onchange = (e) => {
  S.persp.on = e.target.checked;
  if (S.persp.on) toast("パース定規ON: 丸い消失点をドラッグで移動できます");
  savePrefs(); requestRender();
};
$("perspMode").onchange = (e) => { S.persp.mode = e.target.value; savePrefs(); requestRender(); };
$("btnPerspReset").onclick = () => {
  const w = S.doc.w, h = S.doc.h;
  S.persp.vps = [[-Math.round(w * 0.4), Math.round(h * 0.45)],
                 [Math.round(w * 1.4), Math.round(h * 0.45)],
                 [Math.round(w / 2), Math.round(h * 2.2)]];
  savePrefs(); requestRender();
  toast("消失点を初期位置に戻しました");
};
$("brushShape").onchange = (e) => { S.brushShape = e.target.value; savePrefs(); requestRender(); };






async function authFromUrl() {
  const m = location.search.match(/[?&]pin=(\d+)/);
  if (!m) return false;
  try {
    const r = await fetch("/api/auth", { method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pin: m[1] }) });

    history.replaceState(null, "", location.pathname);
    return r.ok;
  } catch (e) { return false; }
}
async function needsPin() {
  try {
    const r = await fetch("/api/doc", { cache: "no-store" });
    return r.status === 401;
  } catch (e) { return false; }
}
function askPin() {
  return new Promise((resolve) => {
    const p = $("pinPanel");
    p.classList.remove("hidden");
    $("pinInput").value = "";
    $("pinInput").focus();
    $("pinMsg").textContent = "";
    const go = async () => {
      const v = $("pinInput").value.trim();
      if (!/^\d{4,8}$/.test(v)) { $("pinMsg").textContent = "数字で入力してください"; return; }
      const r = await fetch("/api/auth", { method: "POST",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pin: v }) });
      if (r.ok) { p.classList.add("hidden"); resolve(true); }
      else { $("pinMsg").textContent = "合言葉が違います"; $("pinInput").select(); }
    };
    $("pinOk").onclick = go;
    $("pinInput").onkeydown = (e) => { if (e.key === "Enter") go(); };
  });
}


loadPrefs();
if (S.soloOn === null || S.soloOn === undefined) S.soloOn = !isPhone();
if (S.quickOn === null || S.quickOn === undefined) S.quickOn = !isPhone();
syncSoloUI();
buildToolGrid();
buildPresets();
buildSelects();
buildMaterialList();
buildMiniBar();
harvestTitles();
setTool(TOOLS[S.tool] ? S.tool : "brush");
syncMiniBar();
$("subChip").style.background = S.sub;
$("colorChip").style.background = S.color;
setColor(S.color);
$("brushShape").value = S.brushShape;
$("matSize").value = S.matSize; $("matSizeVal").textContent = S.matSize;
$("textSize").value = S.textSize;
$("textSizeVal").textContent = S.textSize;
addFontOption(S.textFont);
$("textFont").value = S.textFont;
$("textVertical").checked = S.textVertical;
syncTextExtraUI();
loadServerFonts();
$("importFitCanvas").checked = S.importFitCanvas;
$("importFitCanvas").onchange = (e) => { S.importFitCanvas = e.target.checked; savePrefs(); };
$("perspOn").checked = S.persp.on;
$("perspMode").value = S.persp.mode;
$("vecErase").value = S.vecErase;
$("selModeUI").value = S.selModeUI;
$("selFeather").value = S.selFeather; $("selFeatherVal").textContent = S.selFeather;
$("selGrow").value = S.selGrow; $("selGrowVal").textContent = S.selGrow;
$("autosaveOn").checked = S.autosaveOn;
$("devName").value = S.deviceName || defaultDeviceName();
syncBrushUI();
resize();
syncDock();


(async () => {
  await authFromUrl();
  if (await needsPin()) await askPin();
  connect();
  maybeShowHelp();
  setTimeout(checkStartInfo, 1500);
})();


async function checkStartInfo() {
  let info = null;
  try { info = await (await fetch("/api/info")).json(); } catch (e) { return; }
  if (info.version && $("appVer")) $("appVer").textContent = "版 " + info.version;
  const rec = info.recover || [];
  if (!rec.length || !["localhost", "127.0.0.1", "[::1]"].includes(location.hostname)) return;
  const r = rec[0];
  const when = new Date(r.mtime * 1000).toLocaleString("ja-JP");
  const yes = confirm(`前回、SmartPaint が正しく終わりませんでした。\n\n` +
                      `自動保存「${r.name}」(${when})から復元しますか？\n` +
                      `(「キャンセル」でも、ファイルの一覧の _autosave からあとで開けます)`);
  try { await fetch("/api/recover/dismiss", { method: "POST" }); } catch (e) {}
  if (!yes) return;
  const res = await fetch("/api/open", { method: "POST", headers: { "Content-Type": "application/json" },
                                         body: JSON.stringify({ path: r.path }) });
  toast(res.ok ? "復元しました: " + r.name : "復元できませんでした: " + ((await res.json()).error || ""));
}
if (isPhone()) document.body.classList.add("phone");

$("devName").onchange = (e) => {
  S.deviceName = e.target.value.trim().slice(0, 24);
  savePrefs(); sayHello();
};
$("shareView").onchange = () => shareView();
$("followView").onchange = (e) => {
  S.followPeer = e.target.checked;
  if (S.followPeer) toast("相手の表示位置に追従します");
};


for (const id of ["size", "opacity", "hard", "spacing", "scatter", "stab", "mix",
                  "pSize", "pOp", "fingerDraw", "fillTol", "fillGrow", "fillRef",
                  "gapClose", "taperIn", "taperOut", "post", "pcSize", "pcOp",
                  "gradType", "gradMode", "rulerSel", "symSel", "brushShape",
                  "textSize", "textFont", "textVertical", "perspOn", "perspMode",
                  "selFeather", "selGrow"]) {
  const el = $(id);
  if (el) el.addEventListener("change", savePrefs);
}


if ("serviceWorker" in navigator && location.protocol !== "file:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  });
}
