



"use strict";
const FX = (() => {

  const clamp255 = (v) => v < 0 ? 0 : v > 255 ? 255 : v;


  function rng(seed) {
    let a = seed >>> 0;
    return () => {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) {
      if (mx === r) h = ((g - b) / d) % 6;
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    return [h, mx ? d / mx : 0, mx];
  }
  function hsvToRgb(h, s, v) {
    const f = (n) => {
      const k = (n + h / 60) % 6;
      return v - v * s * Math.max(0, Math.min(k, 4 - k, 1));
    };
    return [f(5) * 255, f(3) * 255, f(1) * 255];
  }




  let glCache = null;
  function glInit() {
    if (glCache !== null) return glCache;
    try {
      const cv = document.createElement("canvas");
      const gl = cv.getContext("webgl2", { premultipliedAlpha: false, antialias: false });
      if (!gl) { glCache = false; return false; }
      const vs = `#version 300 es
        in vec2 p; out vec2 uv;
        void main(){ uv = p*0.5+0.5; gl_Position = vec4(p,0.0,1.0); }`;
      const fs = `#version 300 es
        precision highp float;
        in vec2 uv; out vec4 outc;
        uniform sampler2D tex; uniform vec2 dir; uniform float sigma;
        uniform int R; uniform int mode;   // 0=横(premultiplyする) 1=縦(最後にstraightへ戻す)
        void main(){
          vec4 sum = vec4(0.0); float wsum = 0.0;
          for (int i = -R; i <= R; i++) {
            float fi = float(i);
            float wt = exp(-(fi*fi) / (2.0*sigma*sigma));
            vec4 c = texture(tex, uv + dir*fi);
            if (mode == 0) c = vec4(c.rgb * c.a, c.a);   // 事前乗算してから混ぜる
            sum += c * wt; wsum += wt;
          }
          vec4 r = sum / wsum;
          if (mode == 1) r = vec4(r.a > 0.0031 ? r.rgb / r.a : vec3(0.0), r.a);
          outc = r;
        }`;
      const mk = (type, src) => {
        const s = gl.createShader(type);
        gl.shaderSource(s, src); gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
          throw new Error(gl.getShaderInfoLog(s));
        return s;
      };
      const prog = gl.createProgram();
      gl.attachShader(prog, mk(gl.VERTEX_SHADER, vs));
      gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, fs));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS))
        throw new Error(gl.getProgramInfoLog(prog));
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 3,-1, -1,3]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(prog, "p");
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      glCache = { gl, cv, prog,
                  u: { tex: gl.getUniformLocation(prog, "tex"),
                       dir: gl.getUniformLocation(prog, "dir"),
                       sigma: gl.getUniformLocation(prog, "sigma"),
                       R: gl.getUniformLocation(prog, "R"),
                       mode: gl.getUniformLocation(prog, "mode") } };
      return glCache;
    } catch (e) { glCache = false; return false; }
  }
  function glBlur(data, w, h, radius) {
    const G = glInit();
    if (!G) return false;
    const { gl, cv, prog, u } = G;
    try {
      cv.width = w; cv.height = h;
      gl.viewport(0, 0, w, h);
      gl.useProgram(prog);
      const R = Math.max(1, Math.min(200, Math.ceil(radius * 2.5)));
      const mkTex = (src) => {
        const t = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, t);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, src);
        return t;
      };
      const texA = mkTex(new Uint8Array(data.buffer, data.byteOffset, data.length));
      const texB = mkTex(null);
      const fbo = gl.createFramebuffer();
      const pass = (srcTex, dstTex, dx, dy, mode) => {
        gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, dstTex, 0);
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, srcTex);
        gl.uniform1i(u.tex, 0);
        gl.uniform2f(u.dir, dx / w, dy / h);
        gl.uniform1f(u.sigma, Math.max(0.4, radius));
        gl.uniform1i(u.R, R);
        gl.uniform1i(u.mode, mode);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
      };
      pass(texA, texB, 1, 0, 0);
      pass(texB, texA, 0, 1, 1);
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texA, 0);
      const outBuf = new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, outBuf);
      data.set(outBuf);
      gl.deleteTexture(texA); gl.deleteTexture(texB); gl.deleteFramebuffer(fbo);
      return true;
    } catch (e) { return false; }
  }
  function blur(data, w, h, radius) {
    if (radius < 0.5) return;

    if (w * h > 250000 && glBlur(data, w, h, radius)) return;
    blurJS(data, w, h, radius);
  }












  const PIXEL_MODES = { hsv: 1 };
  const PIXEL_MODES_ALL = { hsv: 1, bc: 2, levels: 3, invert: 4, gray: 5,
                            binarize: 6, lum2alpha: 7 };
  let glpCache = null;
  function glpInit() {
    if (glpCache !== null) return glpCache;
    const G = glInit();
    if (!G) { glpCache = false; return false; }
    try {
      const { gl } = G;
      const vs = `#version 300 es
        in vec2 p; out vec2 uv;
        void main(){ uv = p*0.5+0.5; gl_Position = vec4(p,0.0,1.0); }`;
      const fs = `#version 300 es
        precision highp float;
        in vec2 uv; out vec4 outc;
        uniform sampler2D tex; uniform int mode;
        uniform vec4 a; uniform vec4 b;   // パラメータ置き場
        vec3 rgb2hsv(vec3 c){
          vec4 K = vec4(0.0, -1.0/3.0, 2.0/3.0, -1.0);
          vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
          vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
          float d = q.x - min(q.w, q.y);
          return vec3(abs(q.z + (q.w - q.y) / (6.0*d + 1e-10)), d / (q.x + 1e-10), q.x);
        }
        vec3 hsv2rgb(vec3 c){
          vec4 K = vec4(1.0, 2.0/3.0, 1.0/3.0, 3.0);
          vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
          return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
        }
        void main(){
          vec4 c = texture(tex, uv);
          if (c.a <= 0.0 && mode != 7) { outc = c; return; }
          vec3 r = c.rgb;
          if (mode == 1) {                       // 色相・彩度・明度
            vec3 hsv = rgb2hsv(r);
            hsv.x = fract(hsv.x + a.x/360.0 + 1.0);
            hsv.y = clamp(hsv.y * (1.0 + a.y/100.0), 0.0, 1.0);
            hsv.z = clamp(hsv.z * (1.0 + a.z/100.0), 0.0, 1.0);
            r = hsv2rgb(hsv);
          } else if (mode == 2) {                // 明るさ・コントラスト
            float f = ((a.y + 100.0)/100.0); f = f*f;
            r = clamp(((r + a.x/100.0) - 0.5) * f + 0.5, 0.0, 1.0);
          } else if (mode == 3) {                // レベル補正
            float lo = a.x/255.0, hi = a.y/255.0, g = a.z;
            float olo = a.w/255.0, ohi = b.x/255.0;
            vec3 t = clamp((r - lo) / max(1e-5, hi - lo), 0.0, 1.0);
            t = pow(t, vec3(1.0/max(0.01, g)));
            r = olo + t * (ohi - olo);
          } else if (mode == 4) { r = 1.0 - r; }
          else if (mode == 5) { float l = dot(r, vec3(0.299,0.587,0.114)); r = vec3(l); }
          else if (mode == 6) {
            float l = dot(r, vec3(0.299,0.587,0.114));
            r = vec3(l >= a.x/255.0 ? 1.0 : 0.0);
          } else if (mode == 7) {                // 線画抽出(輝度を透明度に)
            float l = dot(r, vec3(0.299,0.587,0.114));
            float na = (1.0 - l) * c.a;
            outc = vec4(b.w > 0.5 ? r : a.xyz, na);
            return;
          }
          outc = vec4(r, c.a);
        }`;
      const mk = (type, src) => {
        const s = gl.createShader(type);
        gl.shaderSource(s, src); gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS))
          throw new Error(gl.getShaderInfoLog(s));
        return s;
      };
      const prog = gl.createProgram();
      gl.attachShader(prog, mk(gl.VERTEX_SHADER, vs));
      gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, fs));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS))
        throw new Error(gl.getProgramInfoLog(prog));
      glpCache = { prog, u: { tex: gl.getUniformLocation(prog, "tex"),
                              mode: gl.getUniformLocation(prog, "mode"),
                              a: gl.getUniformLocation(prog, "a"),
                              b: gl.getUniformLocation(prog, "b") } };
      return glpCache;
    } catch (e) { glpCache = false; return false; }
  }
  function glPixel(data, w, h, name, p, force) {
    const mode = (force ? PIXEL_MODES_ALL : PIXEL_MODES)[name];
    if (!mode) return false;
    const G = glInit(), P = glpInit();
    if (!G || !P) return false;
    const { gl, cv } = G;
    try {
      cv.width = w; cv.height = h;
      gl.viewport(0, 0, w, h);
      gl.useProgram(P.prog);

      const loc = gl.getAttribLocation(P.prog, "p");
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      let a = [0, 0, 0, 0], b = [0, 0, 0, 0];
      if (name === "hsv") a = [p.h || 0, p.s || 0, p.v || 0, 0];
      else if (name === "bc") a = [p.b || 0, p.c || 0, 0, 0];
      else if (name === "levels") {
        a = [p.inLo ?? 0, p.inHi ?? 255, (p.gamma ?? 100) / 100, p.outLo ?? 0];
        b = [p.outHi ?? 255, 0, 0, 0];
      } else if (name === "binarize") a = [p.t ?? 128, 0, 0, 0];
      else if (name === "lum2alpha") {
        const c = p.color || [0, 0, 0];
        a = [c[0] / 255, c[1] / 255, c[2] / 255, 0];
        b = [0, 0, 0, (p.keep | 0) === 1 ? 1 : 0];
      }
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE,
                    new Uint8Array(data.buffer, data.byteOffset, data.length));
      const dst = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, dst);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      const fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, dst, 0);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.uniform1i(P.u.tex, 0);
      gl.uniform1i(P.u.mode, mode);
      gl.uniform4f(P.u.a, a[0], a[1], a[2], a[3]);
      gl.uniform4f(P.u.b, b[0], b[1], b[2], b[3]);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      const out = new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, out);
      data.set(out);
      gl.deleteTexture(tex); gl.deleteTexture(dst); gl.deleteFramebuffer(fbo);
      return true;
    } catch (e) { return false; }
  }

  function blurJS(data, w, h, radius) {
    if (radius < 0.5) return;

    const n = w * h;
    const pr = new Float32Array(n), pg = new Float32Array(n),
          pb = new Float32Array(n), pa = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const a = data[i * 4 + 3] / 255;
      pr[i] = data[i * 4] * a; pg[i] = data[i * 4 + 1] * a;
      pb[i] = data[i * 4 + 2] * a; pa[i] = data[i * 4 + 3];
    }

    const boxes = boxesForGauss(radius, 3);
    for (const bs of boxes) {
      const r = (bs - 1) / 2 | 0;
      if (r < 1) continue;
      for (const ch of [pr, pg, pb, pa]) { boxH(ch, w, h, r); boxV(ch, w, h, r); }
    }
    for (let i = 0; i < n; i++) {
      const a = pa[i];
      data[i * 4 + 3] = clamp255(Math.round(a));
      if (a < 0.5) { data[i * 4] = data[i * 4 + 1] = data[i * 4 + 2] = 0; continue; }
      const k = 255 / a;
      data[i * 4] = clamp255(Math.round(pr[i] * k));
      data[i * 4 + 1] = clamp255(Math.round(pg[i] * k));
      data[i * 4 + 2] = clamp255(Math.round(pb[i] * k));
    }
  }
  function boxesForGauss(sigma, n) {
    const wIdeal = Math.sqrt((12 * sigma * sigma / n) + 1);
    let wl = Math.floor(wIdeal); if (wl % 2 === 0) wl--;
    const wu = wl + 2;
    const mIdeal = (12 * sigma * sigma - n * wl * wl - 4 * n * wl - 3 * n) / (-4 * wl - 4);
    const m = Math.round(mIdeal);
    const out = [];
    for (let i = 0; i < n; i++) out.push(i < m ? wl : wu);
    return out;
  }
  function boxH(src, w, h, r) {
    const tmp = new Float32Array(w);
    for (let y = 0; y < h; y++) {
      const o = y * w;
      let sum = 0;
      for (let x = -r; x <= r; x++) sum += src[o + Math.min(w - 1, Math.max(0, x))];
      const inv = 1 / (2 * r + 1);
      for (let x = 0; x < w; x++) {
        tmp[x] = sum * inv;
        const add = src[o + Math.min(w - 1, x + r + 1)];
        const sub = src[o + Math.max(0, x - r)];
        sum += add - sub;
      }
      for (let x = 0; x < w; x++) src[o + x] = tmp[x];
    }
  }
  function boxV(src, w, h, r) {
    const tmp = new Float32Array(h);
    for (let x = 0; x < w; x++) {
      let sum = 0;
      for (let y = -r; y <= r; y++) sum += src[Math.min(h - 1, Math.max(0, y)) * w + x];
      const inv = 1 / (2 * r + 1);
      for (let y = 0; y < h; y++) {
        tmp[y] = sum * inv;
        const add = src[Math.min(h - 1, y + r + 1) * w + x];
        const sub = src[Math.max(0, y - r) * w + x];
        sum += add - sub;
      }
      for (let y = 0; y < h; y++) src[y * w + x] = tmp[y];
    }
  }


  function hsv(data, dh, ds, dv) {
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      let [h, s, v] = rgbToHsv(data[i], data[i + 1], data[i + 2]);
      h = (h + dh + 360) % 360;
      s = Math.max(0, Math.min(1, s * (1 + ds / 100)));
      v = Math.max(0, Math.min(1, v * (1 + dv / 100)));
      const [r, g, b] = hsvToRgb(h, s, v);
      data[i] = clamp255(r); data[i + 1] = clamp255(g); data[i + 2] = clamp255(b);
    }
  }
  function brightContrast(data, bright, contrast) {
    const c = (contrast + 100) / 100;
    const f = c * c;
    const b = bright * 2.55;
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      for (let k = 0; k < 3; k++)
        data[i + k] = clamp255(((data[i + k] + b) / 255 - 0.5) * f * 255 + 127.5);
    }
  }
  function levels(data, inLo, inHi, gamma, outLo, outHi) {
    const lut = new Uint8Array(256);
    const span = Math.max(1, inHi - inLo);
    for (let v = 0; v < 256; v++) {
      let t = (v - inLo) / span;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      t = Math.pow(t, 1 / Math.max(0.01, gamma));
      lut[v] = clamp255(outLo + t * (outHi - outLo));
    }
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      data[i] = lut[data[i]]; data[i + 1] = lut[data[i + 1]]; data[i + 2] = lut[data[i + 2]];
    }
  }
  function invert(data) {
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      data[i] = 255 - data[i]; data[i + 1] = 255 - data[i + 1]; data[i + 2] = 255 - data[i + 2];
    }
  }
  function grayscale(data) {
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      const l = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
      data[i] = data[i + 1] = data[i + 2] = clamp255(l);
    }
  }
  function binarize(data, threshold) {
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      const l = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
      const v = l >= threshold ? 255 : 0;
      data[i] = data[i + 1] = data[i + 2] = v;
    }
  }

  function lumToAlpha(data, hexColor, keepColor) {
    const cr = parseInt(hexColor.slice(1, 3), 16),
          cg = parseInt(hexColor.slice(3, 5), 16),
          cb = parseInt(hexColor.slice(5, 7), 16);
    for (let i = 0; i < data.length; i += 4) {
      const a0 = data[i + 3] / 255;
      const l = (data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114);
      const a = clamp255((255 - l) * a0);
      data[i + 3] = a;
      if (!keepColor) { data[i] = cr; data[i + 1] = cg; data[i + 2] = cb; }
    }
  }
  function noise(data, amount, seed, mono) {
    const rand = rng(seed);
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) { rand(); continue; }
      if (mono) {
        const n = (rand() - 0.5) * amount * 2.55 * 2;
        data[i] = clamp255(data[i] + n);
        data[i + 1] = clamp255(data[i + 1] + n);
        data[i + 2] = clamp255(data[i + 2] + n);
      } else {
        for (let k = 0; k < 3; k++)
          data[i + k] = clamp255(data[i + k] + (rand() - 0.5) * amount * 2.55 * 2);
      }
    }
  }
  function mosaic(data, w, h, size) {
    const s = Math.max(2, size | 0);
    for (let by = 0; by < h; by += s) {
      for (let bx = 0; bx < w; bx += s) {
        let r = 0, g = 0, b = 0, a = 0, n = 0;
        const ex = Math.min(w, bx + s), ey = Math.min(h, by + s);
        for (let y = by; y < ey; y++) for (let x = bx; x < ex; x++) {
          const i = (y * w + x) * 4;
          const al = data[i + 3] / 255;
          r += data[i] * al; g += data[i + 1] * al; b += data[i + 2] * al;
          a += data[i + 3]; n++;
        }
        if (!n) continue;
        const am = a / n;
        const k = am > 0.5 ? 255 / (am * n / 255 * 255 / n) : 0;
        const rr = am ? clamp255(r / n * 255 / am) : 0;
        const gg = am ? clamp255(g / n * 255 / am) : 0;
        const bb = am ? clamp255(b / n * 255 / am) : 0;
        for (let y = by; y < ey; y++) for (let x = bx; x < ex; x++) {
          const i = (y * w + x) * 4;
          data[i] = rr; data[i + 1] = gg; data[i + 2] = bb; data[i + 3] = clamp255(am);
        }
      }
    }
  }

  function sharpen(data, blurred, amount) {
    const k = amount / 100;
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      for (let c = 0; c < 3; c++)
        data[i + c] = clamp255(data[i + c] + (data[i + c] - blurred[i + c]) * k);
    }
  }

  function gradientMap(data, stops) {
    const lut = new Uint8Array(256 * 3);
    for (let v = 0; v < 256; v++) {
      const t = v / 255;
      let a = stops[0], b = stops[stops.length - 1];
      for (let i = 0; i < stops.length - 1; i++) {
        if (t >= stops[i][0] && t <= stops[i + 1][0]) { a = stops[i]; b = stops[i + 1]; break; }
      }
      const span = Math.max(1e-6, b[0] - a[0]);
      const u = Math.max(0, Math.min(1, (t - a[0]) / span));
      for (let c = 0; c < 3; c++) lut[v * 3 + c] = clamp255(a[1][c] + (b[1][c] - a[1][c]) * u);
    }
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      const l = Math.round(data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114);
      data[i] = lut[l * 3]; data[i + 1] = lut[l * 3 + 1]; data[i + 2] = lut[l * 3 + 2];
    }
  }



  function curve(data, points, ch) {
    const pts = points.slice().sort((a, b) => a[0] - b[0]);
    if (pts.length < 2) return;
    const lut = new Uint8Array(256);
    for (let v = 0; v < 256; v++) {
      let a = pts[0], b = pts[pts.length - 1];
      if (v <= pts[0][0]) { lut[v] = clamp255(pts[0][1]); continue; }
      if (v >= pts[pts.length - 1][0]) { lut[v] = clamp255(pts[pts.length - 1][1]); continue; }
      for (let i = 0; i < pts.length - 1; i++) {
        if (v >= pts[i][0] && v <= pts[i + 1][0]) { a = pts[i]; b = pts[i + 1]; break; }
      }
      const span = Math.max(1e-6, b[0] - a[0]);
      const t = (v - a[0]) / span;
      const s = t * t * (3 - 2 * t);
      lut[v] = clamp255(a[1] + (b[1] - a[1]) * s);
    }
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      if (ch === "r" || ch === "rgb") data[i] = lut[data[i]];
      if (ch === "g" || ch === "rgb") data[i + 1] = lut[data[i + 1]];
      if (ch === "b" || ch === "rgb") data[i + 2] = lut[data[i + 2]];
    }
  }



  function halftone(data, w, h, pitch, angleDeg, color) {
    const p = Math.max(2, pitch);
    const a = angleDeg * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
    const [cr, cg, cb] = color;
    const src = new Uint8ClampedArray(data);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        if (!src[i + 3]) { data[i + 3] = 0; continue; }

        const u = x * ca + y * sa, v = -x * sa + y * ca;
        const cu = Math.round(u / p) * p, cv = Math.round(v / p) * p;
        const du = u - cu, dv = v - cv;
        const dist = Math.hypot(du, dv);

        const bx = Math.round(cu * ca - cv * sa), by = Math.round(cu * sa + cv * ca);
        const bi = ((Math.min(h - 1, Math.max(0, by)) * w) +
                    Math.min(w - 1, Math.max(0, bx))) * 4;
        const lum = (src[bi] * 0.299 + src[bi + 1] * 0.587 + src[bi + 2] * 0.114) / 255;
        const rad = (1 - lum) * p * 0.72;
        const inside = dist <= rad;
        const edge = Math.max(0, Math.min(1, (rad - dist) + 0.5));
        data[i] = cr; data[i + 1] = cg; data[i + 2] = cb;
        data[i + 3] = inside ? src[i + 3] : Math.round(src[i + 3] * edge);
      }
    }
  }


  function maskToPolys(mask, w, h, eps = 1.2) {
    const key = (x, y) => x * (h + 1) + y;
    const edges = new Map();
    const push = (sx, sy, ex, ey) => {
      const k = key(sx, sy);
      if (!edges.has(k)) edges.set(k, []);
      edges.get(k).push([sx, sy, ex, ey]);
    };
    const at = (x, y) => (x < 0 || y < 0 || x >= w || y >= h) ? 0 : mask[y * w + x];
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if (!mask[y * w + x]) continue;
        if (!at(x, y - 1)) push(x, y, x + 1, y);
        if (!at(x + 1, y)) push(x + 1, y, x + 1, y + 1);
        if (!at(x, y + 1)) push(x + 1, y + 1, x, y + 1);
        if (!at(x - 1, y)) push(x, y + 1, x, y);
      }
    }
    const polys = [];
    for (const [k0, list] of edges) {
      while (list.length) {
        const first = list.pop();
        const pts = [[first[0], first[1]]];
        let cx = first[2], cy = first[3];
        let guard = 0;
        while (guard++ < 4000000) {
          pts.push([cx, cy]);
          const k = key(cx, cy);
          const arr = edges.get(k);
          if (!arr || !arr.length) break;
          const e = arr.pop();
          cx = e[2]; cy = e[3];
          if (cx === first[0] && cy === first[1]) break;
        }
        if (pts.length >= 4) {
          const simp = rdp(pts, eps);
          if (simp.length >= 3 && Math.abs(area(simp)) > 4) polys.push(simp);
        }
      }
    }
    return polys;
  }
  function area(p) {
    let a = 0;
    for (let i = 0, n = p.length; i < n; i++) {
      const q = p[(i + 1) % n];
      a += p[i][0] * q[1] - q[0] * p[i][1];
    }
    return a / 2;
  }
  function rdp(pts, eps) {
    if (pts.length < 3) return pts;
    const keep = new Uint8Array(pts.length);
    keep[0] = keep[pts.length - 1] = 1;
    const stack = [[0, pts.length - 1]];
    while (stack.length) {
      const [s, e] = stack.pop();
      let maxD = 0, idx = -1;
      const [x1, y1] = pts[s], [x2, y2] = pts[e];
      const dx = x2 - x1, dy = y2 - y1;
      const len = Math.hypot(dx, dy) || 1;
      for (let i = s + 1; i < e; i++) {
        const d = Math.abs((pts[i][0] - x1) * dy - (pts[i][1] - y1) * dx) / len;
        if (d > maxD) { maxD = d; idx = i; }
      }
      if (maxD > eps && idx > 0) {
        keep[idx] = 1;
        stack.push([s, idx], [idx, e]);
      }
    }
    return pts.filter((_, i) => keep[i]);
  }








  function lineart(data, w, h, p) {
    const n = w * h;
    const mode = p.mode | 0;
    const t = p.t ?? 128;
    const soft = Math.max(1, (p.soft ?? 30) * 1.28);
    const col = p.color || [0, 0, 0];
    const L = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const a = data[i * 4 + 3] / 255, k = 255 * (1 - a);
      L[i] = 0.299 * (data[i * 4] * a + k) + 0.587 * (data[i * 4 + 1] * a + k) +
             0.114 * (data[i * 4 + 2] * a + k);
    }
    const E = new Float32Array(n);
    if (mode === 1) {
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = y * w + x;
          if (x === 0 || y === 0 || x === w - 1 || y === h - 1) { E[i] = 0; continue; }
          const a0 = L[i - w - 1], a1 = L[i - w], a2 = L[i - w + 1];
          const b0 = L[i - 1], b2 = L[i + 1];
          const c0 = L[i + w - 1], c1 = L[i + w], c2 = L[i + w + 1];
          const gx = (a2 + 2 * b2 + c2) - (a0 + 2 * b0 + c0);
          const gy = (c0 + 2 * c1 + c2) - (a0 + 2 * a1 + a2);
          E[i] = Math.min(255, Math.hypot(gx, gy) * 0.55);
        }
      }
    } else {
      for (let i = 0; i < n; i++) E[i] = 255 - L[i];
    }
    let A = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      const v = (E[i] - t + soft) / (2 * soft);
      A[i] = v <= 0 ? 0 : v >= 1 ? 255 : Math.round(v * 255);
    }







    const rounds = Math.max(0, Math.min(5, p.denoise | 0));
    if (rounds > 0) A = dropSmallComponents(A, w, h, rounds * 20);

    const th = Math.max(0, Math.min(5, p.thick | 0));
    for (let r = 0; r < th; r++) A = morph(A, w, h, 1);
    for (let i = 0; i < n; i++) {
      data[i * 4] = col[0]; data[i * 4 + 1] = col[1]; data[i * 4 + 2] = col[2];
      data[i * 4 + 3] = A[i];
    }
  }

  function dropSmallComponents(A, w, h, minArea) {
    const n = w * h;
    const seen = new Uint8Array(n);
    const out = new Uint8Array(A);
    const stack = [], comp = [];
    for (let s = 0; s < n; s++) {
      if (seen[s] || A[s] < 60) continue;
      comp.length = 0;
      seen[s] = 1; stack.push(s);
      while (stack.length) {
        const i = stack.pop();
        comp.push(i);
        const x = i % w, y = (i / w) | 0;
        for (let dy = -1; dy <= 1; dy++) {
          const yy = y + dy;
          if (yy < 0 || yy >= h) continue;
          for (let dx = -1; dx <= 1; dx++) {
            const xx = x + dx;
            if (xx < 0 || xx >= w) continue;
            const k = yy * w + xx;
            if (seen[k] || A[k] < 60) continue;
            seen[k] = 1; stack.push(k);
          }
        }
      }
      if (comp.length < minArea) for (const i of comp) out[i] = 0;
    }
    return out;
  }

  function morph(A, w, h, dir) {
    const out = new Uint8Array(A.length);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        let v = A[i];
        if (x > 0) v = dir ? Math.max(v, A[i - 1]) : Math.min(v, A[i - 1]);
        if (x < w - 1) v = dir ? Math.max(v, A[i + 1]) : Math.min(v, A[i + 1]);
        if (y > 0) v = dir ? Math.max(v, A[i - w]) : Math.min(v, A[i - w]);
        if (y < h - 1) v = dir ? Math.max(v, A[i + w]) : Math.min(v, A[i + w]);
        out[i] = v;
      }
    }
    return out;
  }

  return { rng, blur, blurJS, glInit, glPixel, hsv, brightContrast, levels, invert, grayscale, binarize,
           lumToAlpha, noise, mosaic, sharpen, gradientMap, halftone, curve, maskToPolys,
           lineart, morph, dropSmallComponents };
})();
